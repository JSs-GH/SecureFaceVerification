class CompilationError(Exception):
    """Exception when an error occurs in compilation from which we can't recover"""
