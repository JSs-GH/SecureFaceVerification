import math
from math import gcd

import numpy as np


def log_reduce_pot_axis(arr, axis, func):
    """Does a reduction along axis with func, with logarithmic depth"""
    a = arr
    while a.shape[axis] != 1:
        a, b = np.split(a, 2, axis)
        a = func(a, b)
    return a


def log_reduce_non_pot_axis(arr, axis, func):
    a = arr
    while a.shape[axis] != 1:
        pot = 2 ** math.floor(math.log2(a.shape[axis]))
        first_idx = [slice(None)] * a.ndim
        first_idx[axis] = slice(0, pot)
        second_idx = [slice(None)] * a.ndim
        second_idx[axis] = slice(pot, None)
        b = log_reduce_pot_axis(a.__getitem__(tuple(first_idx)), axis, func)
        if pot != a.shape[axis]:
            a = np.concatenate((a.__getitem__(tuple(second_idx)), b), axis)
        else:
            a = b
    if a.ndim > 1:
        return np.squeeze(a, axis)
    else:
        return a


def _g(x: int, n: int):
    """evaluates the polynomial (x**2 + 1) mod n"""
    return (x ** 2 + 1) % n


def pollards_rho(num: int):
    """Performs integer factorization of num"""
    x = 2
    y = 2
    d = 1
    while d == 1:
        x = _g(x, num)
        y = _g(_g(y, num), num)
        d = gcd(abs(x - y), num)
    if d == num:
        raise ValueError(f"couldn't factorize {int}")
    else:
        return d
