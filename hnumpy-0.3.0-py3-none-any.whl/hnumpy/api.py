from functools import reduce

import numpy as np
import scipy
from numpy.core._exceptions import AxisError

from ._exceptions import CompilationError
from .arrays import ClearConstArray, EncryptedArray, clear_const_array
from .encrypted_types import EncryptedBool, etype, mix_dtypes
from .representation.intermediate import EncArray_Concatenate, EncArray_InitConstArray

bool = etype("bool")
float8 = etype("float8")
int2 = etype("int2")
int3 = etype("int3")
int4 = etype("int4")
uint2 = etype("uint2")
uint3 = etype("uint3")
uint4 = etype("uint4")


def concatenate(tup, axis=0, *args, **kwargs):
    """
    Concatenate a tuple of encrypted arrays.

    :param tup: tuple of encrypted arrays to concatenate
    :param axis: axis to use for concatenation
    :ret: concatenated encrypted arrays
    """
    if isinstance(tup, EncryptedArray):
        tup = tuple([arr for arr in tup])
    if not isinstance(tup, (tuple, list)):
        raise TypeError(f"concatenate expected tuple, got {type(tup)} instead")
    if not all([isinstance(arr, (EncryptedArray, np.ndarray)) for arr in tup]):
        bad_types = list(
            map(
                lambda x: type(x),
                filter(lambda x: not isinstance(x, EncryptedArray), tup),
            )
        )
        raise TypeError(
            f"concatenation must be between encrypted arrays. Found invalid types: {bad_types}"
        )
    base_dtype = type(tup[0].dtype)
    if not all([isinstance(e.dtype, base_dtype) for e in tup]):
        # try to find common dtype
        try:
            base_dtype = type(reduce(mix_dtypes, [e.dtype for e in tup], tup[0].dtype))
        except:
            raise TypeError(
                f"concatenating arrays of different dtype is not supported at the moment"
            )

    def nd_to_enc(arr):
        if isinstance(arr, EncryptedArray):
            return arr
        elif isinstance(arr, np.ndarray):
            # todo(Joao): not necessarily encrypted float, need to map from np
            # types
            return EncryptedArray(
                shape=arr.shape,
                computation=EncArray_InitConstArray(arr, tup[0].dtype),
                predecessors=[],
                dtype=base_dtype(),
            )

    if len(tup) == 0:
        raise ValueError("need at least one array to concatenate")
    if len(tup) == 1:
        return tup[0]
    # convert constant arrays to encrypted arrays, to be concatenated correctly
    tup = tuple(map(nd_to_enc, tup))
    ndim = tup[0].ndim
    if not all([arr.ndim == ndim for arr in tup]):
        dims = [arr.ndim for arr in tup]
        raise ValueError(
            f"all the input arrays must have same number of dimensions, but arrays have number of dimensions {dims}"
        )
    shapes = [arr.shape for arr in tup]
    for ax in range(0, ndim):
        if ax == axis:
            continue
        orc = shapes[0][ax]
        for i, shape in enumerate(shapes):
            if shape[ax] != orc:
                raise ValueError(
                    f"all the input array dimensions for the concatenation axis must match exactly,"
                    f"but along dimension {ax}, the array at index 0 has size {orc} and "
                    f"the array at index {i} has size {shape[ax]}"
                )
    newdim = sum([ax[axis] for ax in shapes])
    newshape = list(shapes[0])
    newshape[axis] = newdim
    dtype = base_dtype()
    res = EncryptedArray(
        shape=tuple(newshape),
        computation=EncArray_Concatenate(axis, dtype),
        predecessors=list(tup),
        dtype=dtype,
    )
    return res


def row_stack(tup):
    if not isinstance(tup, tuple):
        raise TypeError(
            f"hnp.row_stack() takes a tuple of arrays, received type {type(tup)} instead"
        )
    if not all([isinstance(x, EncryptedArray)] for x in tup):
        bad_types = list(filter(lambda x: not isinstance(x, EncryptedArray), tup))
        raise TypeError(
            f"hnp.row_stack() received an unrecognized type, which is not an encrypted array: "
            f"{bad_types}"
        )
    arrs = tuple(map(atleast_2d, tup))
    return np.concatenate(arrs, axis=0)


def column_stack(tup):
    if not isinstance(tup, tuple):
        raise TypeError(
            f"hnp.columns_stack() takes a tuple of arrays, received type {type(tup)} instead"
        )
    if not all([isinstance(x, EncryptedArray)] for x in tup):
        bad_types = list(filter(lambda x: not isinstance(x, EncryptedArray), tup))
        raise TypeError(
            f"hnp.column_stack() received an unrecognized type, which is not an encrypted array: "
            f"{bad_types}"
        )
    if not all([x.ndim == 1 or x.ndim == 2 for x in tup]):
        raise AxisError(f"hnp.column_stack() expects arrays which are 1-D or 2-D")

    arrs = tuple(map(lambda x: x if x.ndim == 2 else atleast_2d(x).T, tup))
    return concatenate(arrs, axis=1)


def vstack(tup):
    """
    Stack a tuple of encrypted array vertically.
    """
    return row_stack(tup)


def hstack(tup):
    """
    Stack a tuple of encrypted arrays horizontally.
    """
    arrs = list(map(atleast_1d, tup))
    if arrs[0].ndim == 1:
        return concatenate(tup, axis=0)
    else:
        return concatenate(tup, axis=1)


def stack(tup, axis=0, out=None):
    """
    Stack a tuple of encrypted arrays.
    """
    if not isinstance(axis, int):
        raise TypeError(f"expected an integer axis, received type {type(axis)} instead")
    if not np.iterable(tup):
        raise TypeError(f"Expected a tuple of arrays, received type {type(tup)} instead")
    if not all([isinstance(x, EncryptedArray)] for x in tup):
        bad_types = list(filter(lambda x: not isinstance(x, EncryptedArray), tup))
        raise TypeError(
            f"hnp.stack() received an unrecognized type, which is not an encrypted array: "
            f"{bad_types}"
        )
    tup = tuple(map(lambda x: expand_dims(x, axis), tup))
    return concatenate(tup, axis)


def dstack(tup):
    """
    Concatenation along the third axis (axis=2).
    """
    # implementation from numpy's source
    # https://github.com/numpy/numpy/blob/v1.20.0/numpy/lib/shape_base.py#L663-L723
    if not isinstance(tup, tuple):
        raise TypeError(
            f"hnp.dstack() expects a tuple of arrays, received type {type(tup)} instead"
        )
    if not all([isinstance(x, EncryptedArray)] for x in tup):
        bad_types = list(filter(lambda x: not isinstance(x, EncryptedArray), tup))
        raise TypeError(
            f"hnp.dstack() received an unrecognized type, which is not an encrypted array: "
            f"{bad_types}"
        )
    arrs = atleast_3d(*tup)
    if not isinstance(arrs, list):
        arrs = [arrs]
    return concatenate(tuple(arrs), axis=2)


def broadcast_to(array, shape, _subok=False):
    """
    Broadcast the `array` to a specific `shape`.

    :param array: array to broadcast
    :param shape: shape to broadcast to
    :ret: broadcasted array
    """
    return array._inner_broadcast_to(shape)


def dot(a, b, out=None):
    """
    Performs a dot product between `a` and `b`.
    Depending on the shape of `a` and `b` the dot is defined differently:
    - (1D, 1D): inner product
    - (1D, 2D) or (2D-1D): set of inner products
    - (2D, 2D): matrix multiplication

    :param a: left operand
    :param b: right operand
    :ret:
    """
    if out is not None:
        raise NotImplementedError(
            f"Passed non-None argument to 'out' parameter "
            f"of np.dot, which is not currently supported"
        )
    if isinstance(a, np.ndarray):
        a = clear_const_array(a)
    if isinstance(b, np.ndarray):
        b = clear_const_array(b)

    if isinstance(a, EncryptedArray) and isinstance(b, EncryptedArray):
        # deals with every case
        return np.matmul(a, b)

    if len(a.shape) == 1 and len(b.shape) == 1:
        return a._inner_dot1d(b) if isinstance(a, EncryptedArray) else b._inner_dot1d(a)
    # the VM currently requires that the clear matrix is 2d when the encrypted matrix is 2d, which means
    # that in the 2d encrypted 1d clear case, we have to do some manipulations to expand and squeeze
    elif (len(a.shape) == 1 and len(b.shape) == 2 and isinstance(b, ClearConstArray)) or (
        len(a.shape) == 2 and len(b.shape) == 1 and isinstance(a, ClearConstArray)
    ):
        return a._inner_dot2d(b)
    elif len(a.shape) == 1 and len(b.shape) == 2:
        expanded = clear_const_array(np.expand_dims(a.content, 0))
        z = matmul(expanded, b)
        return reshape(z, (z.shape[1],))
    elif len(a.shape) == 2 and len(b.shape) == 1:
        expanded = clear_const_array(np.expand_dims(b.content, 1))
        z = matmul(a, expanded)
        return reshape(z, (z.shape[0],))
    elif len(a.shape) == 2 and len(b.shape) == 2:
        return matmul(a, b)
    else:
        raise NotImplementedError(
            f"Dot product not yet implemented between arrays " f"of dimension {a.ndim} and {b.ndim}"
        )


def cross(a, b):
    if isinstance(a, np.ndarray):
        a = clear_const_array(a)
    if isinstance(b, np.ndarray):
        b = clear_const_array(b)

    return a._inner_cross(b)


def matmul(arr1, arr2, *args, **kwargs):
    if isinstance(arr1, np.ndarray):
        arr1 = clear_const_array(arr1)
    return arr1.matmul(arr2, *args, **kwargs)


def exp(arr, *args, **kwargs):
    return arr._inner_exp(*args, **kwargs)


def expm1(x, *args, **kwargs):
    return exp(x, args, kwargs) - 1


def clip(a, a_min, a_max, *args, **kwargs):
    return a._inner_clip(a_min, a_max, args, kwargs)


def dsplit(ary, indices_or_sections):
    return split(ary, indices_or_sections, axis=2)


def hsplit(ary, indices_or_sections):
    return split(ary, indices_or_sections, axis=1)


def vsplit(ary, indices_or_sections):
    return split(ary, indices_or_sections, axis=0)


def split(ary, indices_or_sections, axis=0):
    return ary._inner_split(indices_or_sections, axis)


def square(x, *args, **kwargs):
    return x ** 2


def sqrt(x, *args, **kwargs):
    return x ** 0.5


def cbrt(x, *args, **kwargs):
    return x._inner_cbrt()


# Trigonometric functions
def sin(arr, *args, **kwargs):
    return arr._inner_sin(*args, **kwargs)


def sinc(x):
    return sin(np.pi * x) / (np.pi * x)


def cos(arr, *args, **kwargs):
    return arr._inner_cos(*args, **kwargs)


def tan(arr, *args, **kwargs):
    return arr._inner_tan(*args, **kwargs)


def arcsin(arr, *args, **kwargs):
    return arr._inner_arcsin(*args, **kwargs)


def arccos(arr, *args, **kwargs):
    return arr._inner_arccos(*args, **kwargs)


def arctan(arr, *args, **kwargs):
    return arr._inner_arctan(*args, **kwargs)


def arctan2(arr, *args, **kwargs):
    return arr._inner_arctan2(*args, **kwargs)


def hypot(x1, x2, *args, **kwargs):
    return sqrt(x1 ** 2 + x2 ** 2)


def sinh(arr, *args, **kwargs):
    return arr._inner_sinh(*args, **kwargs)


def cosh(arr, *args, **kwargs):
    return arr._inner_cosh(*args, **kwargs)


def tanh(arr, *args, **kwargs):
    return arr._inner_tanh(*args, **kwargs)


def arcsinh(arr, *args, **kwargs):
    return arr._inner_arcsinh(*args, **kwargs)


def arccosh(arr, *args, **kwargs):
    return arr._inner_arccosh(*args, **kwargs)


def arctanh(arr, *args, **kwargs):
    return arr._inner_arctanh(*args, **kwargs)


def deg2rad(arr, *args, **kwargs):
    return arr._inner_deg2rad(*args, **kwargs)


def rad2deg(arr, *args, **kwargs):
    return arr._inner_rad2deg(*args, **kwargs)


def radians(arr, *args, **kwargs):
    return arr._inner_radians(*args, **kwargs)


def degrees(arr, *args, **kwargs):
    return arr._inner_degrees(*args, **kwargs)


def log(arr, *args, **kwargs):
    return arr._inner_log(*args, **kwargs)


def log2(x, *args, **kwargs):
    return x._inner_log2(*args, **kwargs)


def log10(x, *args, **kwargs):
    return x._inner_log10(args, kwargs)


def log1p(x, *args, **kwargs):
    return log(1 + x, *args, **kwargs)


def i0(x):
    return x._inner_i0()


def add(x1, x2, *args, **kwargs):
    if isinstance(x1, EncryptedArray):
        return x1.__add__(x2)
    elif isinstance(x2, EncryptedArray):
        return x2.__add__(x1)
    else:
        raise TypeError(f"neither type {type(x1)} or {type(x2)} to " f"add() is recognized")


def subtract(x1, x2, *args, **kwargs):
    if isinstance(x2, EncryptedArray) and not isinstance(x1, EncryptedArray):
        return x2.__rsub__(x1)

    return x1 - x2


def multiply(x1, x2, *args, **kwargs):
    return x1.__mul__(x2) if isinstance(x1, EncryptedArray) else x2.__mul__(x1)


def divide(x1, x2, *args, **kwargs):
    return x1 * (1 / x2)


def logaddexp(x1, x2, *args, **kwargs):
    if isinstance(x1, EncryptedArray):
        exp_x1 = exp(x1)
    else:
        exp_x1 = np.exp(x1)
    if isinstance(x2, EncryptedArray):
        exp_x2 = exp(x2)
    else:
        exp_x2 = np.exp(x2)
    return log(exp_x1 + exp_x2)


def logaddexp2(x1, x2, *args, **kwargs):
    return log2(2 ** x1 + 2 ** x2)


def round(arr, *args, **kwargs):
    return arr._inner_round(*args, **kwargs)


def fix(arr, *args, **kwargs):
    return minimum(ceil(arr), 0) + maximum(floor(arr), 0)


def maximum(x1, x2, *args, **kwargs):
    return x1._inner_maximum(x2) if isinstance(x1, EncryptedArray) else x2._inner_maximum(x1)


def minimum(x1, x2, *args, **kwargs):
    return x1._inner_minimum(x2) if isinstance(x1, EncryptedArray) else x2._inner_minimum(x1)


def absolute(x, *args, **kwargs):
    return abs(x)


def fabs(x, *args, **kwargs):
    return abs(x)


def sign(x, *args, **kwargs):
    return x._inner_sign(args, kwargs)


def swapaxes(a, axis1, axis2):
    to_transpose = list(range(0, a.ndim))
    to_transpose[axis1], to_transpose[axis2] = to_transpose[axis2], to_transpose[axis1]
    return transpose(a, tuple(to_transpose))


def transpose(a, axes=None):
    return a.transpose(axes)


def nan_to_num(x, *args, **kwargs):
    # todo(Joao): should we just add a no-op, since nan/inf doesn't exist in the
    # homomorphic encoding, or should we raise an exception for user to know that
    # she's calling something invalid?
    pass


def interp(x, xp, fp, *args, **kwargs):
    func = scipy.interpolate.interp1d(xp, fp, fill_value="extrapolate")
    return x._inner_apply(func, *args, **kwargs)


def copyto(dst, src, *args, **kwargs):
    return src._inner_copyto(dst, *args, **kwargs)


def reciprocal(x, *args, **kwargs):
    return 1 / x


def negative(x, *args, **kwargs):
    return -x


def floor(x, *args, **kwargs):
    return x._inner_floor()


def ceil(x, *args, **kwargs):
    return x._inner_ceil()


def pad(array, pad_width, mode="constant", **kwargs):
    return array._inner_pad(pad_width, mode)


def trunc(x, *args, **kwargs):
    return x._inner_trunc()


def atleast_1d(*arys):
    if len(arys) == 0:
        raise ValueError(f"hnp.atleast_1d() call without arguments")
        pass
    elif len(arys) == 1:
        x = arys[0]
        return x._inner_atleast1d()
    else:
        return list(map(lambda x: x._inner_atleast1d(), arys))


def atleast_2d(*arys):
    if len(arys) == 0:
        raise ValueError(f"hnp.atleast_2d() call without arguments")
    elif len(arys) == 1:
        x = arys[0]
        return x._inner_atleast2d()
    else:
        return list(map(lambda x: x._inner_atleast2d(), arys))


def atleast_3d(*arys):
    if len(arys) == 0:
        raise ValueError(f"hnp.atleast_3d() call without arguments")
        pass
    elif len(arys) == 1:
        x = arys[0]
        return x._inner_atleast3d()
    else:
        return list(map(lambda x: x._inner_atleast3d(), arys))


def ravel(arr, order="C"):
    # the difference between ravel and flatten is that ravel() sometimes returns a view, and flatten always
    # returns a copy; in hnp, we don't support views, and always return a new array, so in practice for us they're
    # the same
    return arr.flatten(order)


def resize(a, newshape):
    return a._inner_resize(newshape)


def shape(arr):
    return arr.shape


def reshape(a, newshape, order="C"):
    if order != "C":
        raise ValueError(
            f"hnp.reshape() has invalid order {order} - only C indexing order is supported"
        )
    return a._inner_reshape(newshape)


def expand_dims(a, axis):
    return a._inner_expand_dims(axis)


def moveaxis(a, source, destination):
    return a._inner_moveaxis(source, destination)


def rollaxis(a, axis, start=0):
    return a._inner_rollaxis(axis, start)


def squeeze(a, axis=None):
    return a.squeeze(axis)


def _sum(a, axis=None, *args, **kwargs):
    return a.sum(axis)


def mean(a, axis=None, *args, **kwargs):
    return a._inner_mean(axis)


def where(cond, x, y):
    assert isinstance(cond, (EncryptedArray, np.ndarray, bool))
    if isinstance(cond, EncryptedArray):
        assert isinstance(cond.dtype, EncryptedBool)
    elif isinstance(cond, np.ndarray):
        assert cond.dtype == np.bool
    assert isinstance(x, (EncryptedArray, np.ndarray))
    assert isinstance(y, (EncryptedArray, np.ndarray))

    # mux gate
    return cond * (x - y) + y


def trim_zeros(filt, trim="fb"):
    raise CompilationError(
        f"trim_zeros is not implemented due to HNP constraints: the size of the array would "
        f"depend on encrypted values, which is not currently supported"
    )


def greater(x1, x2, *args, **kwargs):
    return x1 > x2


def greater_equal(x1, x2, *args, **kwargs):
    return x1 >= x2


def less(x1, x2, *args, **kwargs):
    return x1 < x2


def less_equal(x1, x2, *args, **kwargs):
    return x1 <= x2


def equal(x1, x2, *args, **kwargs):
    return x1._inner_eq(x2) if isinstance(x1, EncryptedArray) else x2._inner_eq(x1)


def not_equal(x1, x2, *args, **kwargs):
    return x1 != x2


def logical_and(x1, x2, *args, **kwargs):
    return np.bitwise_and(x1, x2, *args, **kwargs)


def logical_or(x1, x2, *args, **kwargs):
    return np.bitwise_or(x1, x2, *args, **kwargs)


def logical_xor(x1, x2, *args, **kwargs):
    return np.bitwise_xor(x1, x2, *args, **kwargs)


def logical_not(x1, *args, **kwargs):
    return ~x1


def bitwise_and(x1, x2, *args, **kwargs):
    assert isinstance(x1, EncryptedArray)
    assert isinstance(x2, EncryptedArray)
    if not isinstance(x1.dtype, EncryptedBool) or not isinstance(x2.dtype, EncryptedBool):
        raise TypeError(
            f"bitwise_and must be applied between boolean arrays, however, inputs are "
            f"of types {type(x1.dtype)} and {type(x2.dtype)} respectively"
        )
    return x1._inner_bitwise_and(x2)


def bitwise_or(x1, x2, *args, **kwargs):
    assert isinstance(x1, EncryptedArray)
    assert isinstance(x2, EncryptedArray)
    if not isinstance(x1.dtype, EncryptedBool) or not isinstance(x2.dtype, EncryptedBool):
        raise TypeError(
            f"bitwise_or must be applied between boolean arrays, however, inputs are "
            f"of types {type(x1.dtype)} and {type(x2.dtype)} respectively"
        )
    return x1._inner_bitwise_or(x2)


def bitwise_xor(x1, x2, *args, **kwargs):
    assert isinstance(x1, EncryptedArray)
    assert isinstance(x2, EncryptedArray)
    if not isinstance(x1.dtype, EncryptedBool) or not isinstance(x2.dtype, EncryptedBool):
        raise TypeError(
            f"bitwise_xor must be applied between boolean arrays, however, inputs are "
            f"of types {type(x1.dtype)} and {type(x2.dtype)} respectively"
        )
    return x1._inner_bitwise_xor(x2)


def _all(a, axis=None, *args, **kwargs):
    return a._inner_all(axis)


def _any(a, axis=None, *args, **kwargs):
    return a._inner_any(axis)


def isclose(a, b, rtol=None, atol=1e-05, equal_nan=False):
    if rtol is not None:
        raise ValueError(f"np.isclose doesn't support rtol at the moment")
    res = a._inner_isclose(b, atol) if isinstance(a, EncryptedArray) else b._inner_isclose(a, atol)
    return res


def allclose(a, b, rtol=None, atol=1e-05, equal_nan=False):
    if rtol is not None:
        raise ValueError(f"np.allclose doesn't support rtol at the moment")
    if isinstance(a, (EncryptedArray, np.ndarray)):
        a = a.flatten()
    if isinstance(b, (EncryptedArray, np.ndarray)):
        b = b.flatten()
    return np.all(np.isclose(a, b, atol=atol))
