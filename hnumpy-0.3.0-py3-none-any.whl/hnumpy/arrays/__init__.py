from .clear_array_impl import ClearArray, ClearConstArray
from .encrypted_array_impl import EncryptedArray
from .encrypted_scalar_impl import EncryptedScalar


def encrypted_scalar(*args, **kwargs):
    """Constructor for the EncryptedScalar objects"""
    return EncryptedScalar(*args, **kwargs)


def encrypted_array(*args, **kwargs):
    """Constructor for the EncryptedArray objects"""
    return EncryptedArray(*args, **kwargs)


def clear_array(*args, **kwargs):
    """Constructor for the ClearArray objects"""
    raise NotImplementedError(
        f"clear variable arrays are not currently supported by "
        f"the homomorphic numpy; you may try to use a constant "
        f"array instead, defined outside of the function being "
        f"converted"
    )


def clear_const_array(contents, *args, **kwargs):
    """Constructor for the ClearConstArray objects"""
    return ClearConstArray(contents, args, kwargs)


__all__ = ["encrypted_scalar", "encrypted_array", "clear_array"]
