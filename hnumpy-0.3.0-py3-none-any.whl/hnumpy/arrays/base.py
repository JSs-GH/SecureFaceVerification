"""
BaseArray provides basic operations that an array needs to implement in order
to be able to trace function execution, and save properties about it.
"""

from abc import ABC
from functools import reduce


class BaseArray(ABC):
    def __init__(
        self,
        bounds=None,
        graph=None,
        shape=None,
        computation=None,
        predecessors=None,
        dtype=None,
        etype=None,
    ):
        self._graph = graph
        self._bounds = bounds
        self._predecessors = predecessors
        self._computation = computation
        self._shape = shape
        self._dtype = dtype
        self._etype = etype
        self._ndim = len(self._shape)
        self._size = reduce(lambda x, y: x * y, self._shape)

    # Properties will be mainly to check that attributes are set before being used
    # as the current default is None

    @property
    def etype(self):
        return self._etype

    @property
    def graph(self):
        if self._graph is None:
            raise RuntimeError("array is not linked to a graph")
        return self._graph

    @property
    def bounds(self):
        if self._bounds is None:
            raise RuntimeError("array doesn't have a range")
        return self._bounds

    @property
    def predecessors(self):
        if self._predecessors is None:
            raise RuntimeError("array doesn't have predecessors")
        return self._predecessors

    @property
    def computation(self):
        if self._computation is None:
            raise RuntimeError("array doesn't have a computation")
        return self._computation

    @property
    def shape(self):
        if self._shape is None:
            raise RuntimeError("array doesn't have a shape")
        return self._shape

    @property
    def dtype(self):
        # if self._dtype is None:
        #     raise RuntimeError("array doesn't have a dtype")
        return self._dtype

    # Setters: we might want to add some checks here later

    @property
    def size(self):
        return self._size

    @property
    def ndim(self):
        return self._ndim

    @graph.setter
    def graph(self, graph):
        self._graph = graph

    @bounds.setter
    def bounds(self, bounds):
        self._bounds = bounds

    @predecessors.setter
    def predecessors(self, predecessors):
        self._predecessors = predecessors

    @computation.setter
    def computation(self, computation):
        self._computation = computation

    @shape.setter
    def shape(self, shape):
        self._shape = shape

    @dtype.setter
    def dtype(self, dtype):
        self._dtype = dtype

    def __str__(self):
        return str(self._computation)
