import numpy

from ..checker import check_shapes_are_crossable
from ..representation.intermediate import *
from . import encrypted_array_impl
from .base import BaseArray


class ClearArray(BaseArray):
    def __init__(
        self,
        bounds=None,
        graph=None,
        shape=None,
        computation=None,
        predecessors=None,
        dtype=None,
    ):
        super().__init__(
            bounds=bounds,
            shape=shape,
            predecessors=predecessors,
            computation=computation,
            dtype=dtype,
        )


class ClearConstArray(BaseArray):
    def __init__(
        self,
        content,
        computation=None,
        predecessors=None,
        dtype=None,
    ):
        _max = numpy.amax(content)
        _min = numpy.amin(content)
        super().__init__(
            bounds=(
                _min,
                _max,
            ),
            shape=content.shape,
        )
        self.content = content

    def __matmul__(self, other):
        return self.matmul(other)

    def _inner_cross(self, other):
        if isinstance(other, encrypted_array_impl.EncryptedArray):
            resulting_shape = check_shapes_are_crossable("cross", self, other)
            res = other.__class__(
                shape=resulting_shape,
                computation=ClearConstArrayEncArray_Cross(self.content, self.dtype),
                predecessors=[other],
                dtype=other.dtype,
            )
            return res
        else:
            raise TypeError(f"Invalid cross product between clear constant array and {type(other)}")

    def _inner_dot2d(self, other):
        if isinstance(other, encrypted_array_impl.EncryptedArray):
            if len(self.shape) == 2:  # plain is the matrix
                output_shape = (self.shape[0],)
            else:  # encrypted is the matrix
                output_shape = (other.shape[1],)
            res = other.__class__(
                shape=output_shape,
                computation=ClearConstArrayEncArray_Dot2d(self.content, self.dtype),
                predecessors=[other],
                dtype=other.dtype,
            )
            return res
        else:
            raise TypeError(
                f"Invalid dot product between clear constant array" f"and {type(other)}"
            )

    def matmul(self, other):
        if isinstance(other, encrypted_array_impl.EncryptedArray):
            if len(self.shape) != 2 or self.shape[1] != other.shape[0]:
                raise ValueError(
                    f"Incompatible matrix dimensions for matrix multiplication: ({self.shape[0]},{self.shape[1]})x({other.shape[0]},{other.shape[1]}), must be (n,m)x(m,k)"
                )
            res = other.__class__(
                shape=(self.shape[0], other.shape[1]),
                computation=ClearConstArrayEncArray_Matmul(self.content, self.dtype),
                predecessors=[other],
                dtype=other.dtype,
            )
            return res
        else:
            raise TypeError(
                f"Matrix multiplication between ClearConstArray and {type(other)} is not supported"
            )
