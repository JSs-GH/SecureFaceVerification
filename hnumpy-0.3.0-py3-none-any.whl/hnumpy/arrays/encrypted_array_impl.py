import math
from copy import deepcopy
from functools import reduce
from typing import Any

import numpy as np
from loguru import logger
from numpy.core._exceptions import AxisError
from numpy.core.numeric import normalize_axis_index, normalize_axis_tuple
from zamavm import PySliceOrIndex

from .._math import log_reduce_non_pot_axis
from ..checker import (
    broadcast_shape,
    check_shapes_are_broadcastable,
    check_shapes_are_crossable,
)
from ..constants import NP_FLOAT_TYPES, NP_INT_TYPES
from ..encrypted_types import EncryptedBool, etype, find_exact_clear_dtype, mix_dtypes
from ..representation.intermediate import *
from . import clear_array_impl, encrypted_scalar_impl
from .base import BaseArray


class EncryptedArray(BaseArray):
    """
    Representation of an encrypted array, used to trace operations within functions such that we can build
    a graph to execute homomorphically
    This array doesn't actually contain any data
    """

    def __init__(
        self,
        bounds=None,
        shape=None,
        predecessors=None,
        computation=None,
        # by default, we assume to be operating on floats
        dtype=etype("float8"),
        etype=etype("float8"),
    ):
        super().__init__(
            bounds=bounds,
            shape=shape,
            predecessors=predecessors,
            computation=computation,
            dtype=dtype,
            etype=etype,
        )
        self.output_num = None

    def shape_product(self):
        shape_prod = 1
        for shape in self.shape:
            shape_prod *= shape
        return shape_prod

    @property
    def T(self):
        return self.transpose()

    ## Unsupported assignment
    def __iadd__(self, other: Any):
        raise NotImplementedError(
            "hnumpy encrypted arrays are immutable: assignment is not possible. "
            "Instead of `x += y`, use `x = x + y`"
        )

    def __isub__(self, other: Any):
        raise NotImplementedError(
            "hnumpy encrypted arrays are immutable: assignment is not possible. "
            "Instead of `x -= y`, use `x = x - y`"
        )

    def __imul__(self, other: Any):
        raise NotImplementedError(
            "hnumpy encrypted arrays are immutable: assignment is not possible. "
            "Instead of `x *= y`, use `x = x * y`"
        )

    def __imod__(self, other: Any):
        raise NotImplementedError(
            "hnumpy encrypted arrays are immutable: assignment is not possible. "
            "Instead of `x %= y`, use `x = x % y`"
        )

    ## Overloaded methods
    def __abs__(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Abs(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def __add__(self, other):
        if isinstance(other, np.ndarray):
            other = clear_array_impl.ClearConstArray(other)

        if isinstance(
            other,
            (
                int,
                float,
                NP_FLOAT_TYPES,
                NP_INT_TYPES,
            ),
        ):
            res = self.__class__(
                shape=self.shape,
                computation=EncArrayClearConstExprScalar_Add(other, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res

        if isinstance(other, self.__class__):
            resulting_shape = check_shapes_are_broadcastable("__add__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)
            broadcasted_other = other._inner_broadcast_to(resulting_shape)
            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayEncArray_Add(self.dtype),
                predecessors=[broadcasted_self, broadcasted_other],
                dtype=mix_dtypes(self.dtype, other.dtype),
            )
            return res
        elif isinstance(other, clear_array_impl.ClearArray):
            resulting_shape = check_shapes_are_broadcastable("__add__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)

            if other.shape != resulting_shape:
                raise ValueError(
                    f"Broadcasted addition between encrypted array and clear array is not supported"
                )

            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayClearArray_Add(self.dtype),
                predecessors=[broadcasted_self, other],
                dtype=self.dtype,
            )
            return res
        elif isinstance(other, clear_array_impl.ClearConstArray):
            resulting_shape = check_shapes_are_broadcastable("__add__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)

            broadcasted_other = np.broadcast_to(other.content, resulting_shape)
            if self.dtype.is_exact():
                other_dtype = find_exact_clear_dtype(other.content, "__add__")
                dtype = mix_dtypes(self.dtype, other_dtype)
            else:
                dtype = self.dtype
            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayConstClearArray_Add(
                    np.ascontiguousarray(broadcasted_other), self.dtype
                ),
                predecessors=[broadcasted_self],
                dtype=dtype,
            )
            return res
        else:
            raise ValueError(f"Undefined addition between encrypted array and {type(other)}")

    def __and__(self, other):
        if not isinstance(self.dtype, EncryptedBool) or not isinstance(other.dtype, EncryptedBool):
            raise TypeError(
                f"logical and (&) operator can be applied only between encrypted "
                f"arrays containing boolean elements"
            )
        return self._inner_bitwise_and(other)

    # todo: networkx uses __eq__ to compare/hash the type, change this to __eq__ once that's resolved
    def _inner_eq(self, other):
        if isinstance(other, EncryptedArray):
            if not self.dtype.is_exact() or not other.dtype.is_exact():
                raise TypeError(
                    f"equal (==) not supported between floating point arrays; use np.isclose instead"
                )
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_Equal(self.dtype),
                predecessors=[self, other],
                dtype=EncryptedBool(),
            )
        elif isinstance(other, (int, float, NP_INT_TYPES, NP_FLOAT_TYPES)):
            if not self.dtype.is_exact():
                raise TypeError(
                    f"equal (==) not supported between floating point arrays; use np.isclose instead"
                )
            return self.__class__(
                shape=self.shape,
                computation=EncArrayConstExprScalar_Equal(other, self.dtype),
                predecessors=[self],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(f"comparison between encrypted array and {type(other)} not supported")

    def __getitem__(self, item):
        if isinstance(item, (int, list, np.ndarray, slice)):
            item = (item,)
        orig_item = item[:]
        if isinstance(item, tuple):
            if any([isinstance(x, (list, np.ndarray)) for x in item]):
                if len(item) > len(self.shape):
                    raise IndexError(
                        f"Too many values are passed to __getitem__: "
                        f"array has {len(self.shape)} dimensions, "
                        f"but {len(item)} values were provided"
                    )

                # fancy indexing
                # buckle up, this is gonna be a bumpy ride...

                # extract fancy indexing accessors (ints, lists, and ndarrays) and their indices
                # and convert slices to corresponding lists in place (e.g., 3:1:-1 <=> [3, 2])

                accessors = []
                accessor_indices = []

                item = list(item)
                for i, accessor in enumerate(item):
                    accessor_indices.append(i)
                    if isinstance(accessor, int):
                        accessors.append(np.array([accessor]))
                    elif isinstance(accessor, list):
                        accessors.append(np.array(accessor))
                    elif isinstance(accessor, np.ndarray):
                        accessors.append(accessor)
                    else:
                        accessor_indices.pop()
                        if isinstance(accessor, slice):
                            start = accessor.start
                            stop = accessor.stop
                            step = accessor.step

                            if step is None:
                                step = 1

                            assert step != 0
                            if step > 0:
                                if start is None:
                                    start = 0
                                if stop is None:
                                    stop = self.shape[i]
                            else:
                                if stop is None:
                                    stop = -1
                                if start is None:
                                    start = self.shape[i] - 1

                            item[i] = list(range(start, stop, step))
                        else:
                            raise TypeError(
                                f"__getitem__ contains type {type(accessor)} "
                                f"which is not recognized"
                            )

                # broadcast accessors with each other to find a common ground

                accessors = [np.array(a) for a in np.broadcast_arrays(*accessors)]

                # replace accessors in item with their broadcasted variants

                for index, accessor in zip(accessor_indices, accessors):
                    item[index] = accessor

                # extend item with full slices
                # this is natural because when len(x.shape) == 4
                # x[:, [...]] == x[:, [...], :, :]

                while len(item) != len(self.shape):
                    item.append(list(range(0, self.shape[len(item)], 1)))

                # here we have a modified item which exactly have len(self.shape) items
                # and each accessor has the same broadcasted shape

                # now we need to find whether accessors are consecutive
                # this is required because it affects the resulting shape
                # check https://numpy.org/doc/stable/reference/arrays.indexing.html#combining-advanced-and-basic-indexing for details

                consecutive = True
                for i in range(len(accessor_indices) - 1):
                    if accessor_indices[i] + 1 != accessor_indices[i + 1]:
                        consecutive = False
                        break

                # and we calculate the resulting shape

                resulting_shape = []
                if consecutive:
                    for i in range(accessor_indices[0]):
                        resulting_shape.append(len(item[i]))

                    start = len(resulting_shape)
                    resulting_shape += accessors[0].shape
                    end = len(resulting_shape)
                    substitution_range = slice(start, end, 1)

                    for i in range(accessor_indices[-1] + 1, len(self.shape)):
                        resulting_shape.append(len(item[i]))
                else:
                    resulting_shape += accessors[0].shape
                    substitution_range = slice(0, len(resulting_shape), 1)
                    for i, accessor in enumerate(item):
                        if isinstance(accessor, list):
                            resulting_shape.append(len(accessor))

                # now we can create the indices that is going to be passed to vm

                indices = []
                for i in range(len(self.shape)):
                    indices.append(np.zeros(resulting_shape, dtype=np.int64))

                # finally, we can fill the indices with appropriate values

                for index in np.ndindex(*resulting_shape):
                    seen_accessors = 0
                    for i in range(len(self.shape)):
                        selector = indices[i]
                        if isinstance(item[i], list):
                            if i < substitution_range.start:
                                selector[index] = item[i][index[i]]
                            else:
                                offset = substitution_range.stop - substitution_range.start
                                selector[index] = item[i][index[i + (offset - seen_accessors)]]
                        else:
                            selector[index] = item[i][index[substitution_range]]
                            seen_accessors += 1

                # and create intermediate fancy indexing node

                res = self.__class__(
                    shape=resulting_shape,
                    computation=EncArray_FancyIndex(orig_item, indices, self.dtype),
                    predecessors=[self],
                    dtype=self.dtype,
                )
                return res

            arr = self
            if any([x is None for x in item]):
                # must expand dims
                axes = [i for i, a in enumerate(item) if a is None]
                arr = self._inner_expand_dims(axes)
                item = tuple([x if x is not None else np.s_[0:1] for x in item])
            if len(item) > arr.ndim:
                raise IndexError(
                    f"Slice contains too many indices: array has {arr.ndim} dimensions,"
                    f"but {len(item)} were provided"
                )

            def slice_or_int_to_pyslice(tup):
                idx, item = tup
                if isinstance(item, int):
                    return PySliceOrIndex(item)
                elif isinstance(item, slice):
                    start = item.start if item.start is not None else 0
                    end = item.stop if item.stop is not None else arr.shape[idx]
                    step = item.step if item.step is not None else 1
                    if start < 0:
                        start = arr.shape[idx] + start
                    if end < 0:
                        end = arr.shape[idx] + end
                    if end > arr.shape[idx]:
                        # numpy accepts this, and handles it for the user
                        end = arr.shape[idx]
                    if step < 0:
                        start, end = end + 1, start + 1
                    return PySliceOrIndex({"start": start, "end": end, "step": step})
                else:
                    raise ValueError(f"Invalid item type in slice: {type(item)}")

            py_slice = list(map(slice_or_int_to_pyslice, enumerate(item)))
            newshape = list(deepcopy(arr.shape))
            for idx, item in enumerate(item):
                if isinstance(item, slice):
                    start = item.start if item.start is not None else 0
                    end = item.stop if item.stop is not None else arr.shape[idx]
                    step = item.step if item.step is not None else 1
                    if start < 0:
                        start = arr.shape[idx] + start
                    if end < 0:
                        end = arr.shape[idx] + end
                    if end > arr.shape[idx]:
                        # numpy accepts this, and handles it for the user
                        end = arr.shape[idx]
                    if step < 0:
                        step = -step
                        start, end = end, start
                    newshape[idx] = (end - start) // step
                elif isinstance(item, int):
                    # we'll filter this dimension out to eliminate it
                    newshape[idx] = None
                else:
                    raise TypeError(
                        f"__getitem__ slice contains type {type(item)} which is not recognized"
                    )
            newshape = tuple(filter(lambda x: x is not None, newshape))
            if len(newshape) == 0:
                newshape = (1,)
            res = self.__class__(
                shape=newshape,
                computation=EncArray_Slice(orig_item, py_slice, arr.dtype),
                predecessors=[arr],
                dtype=self.dtype,
            )
            return res
        else:
            raise ValueError(f"Invalid call to __getitem__ with {item} argument")

    def __gt__(self, other):
        if isinstance(other, EncryptedArray):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_Greater(self.dtype),
                predecessors=[self, other],
                dtype=EncryptedBool(),
            )
        elif isinstance(other, (int, float, NP_INT_TYPES, NP_FLOAT_TYPES)):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayConstExprScalar_Greater(other, self.dtype),
                predecessors=[self],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(f"comparison between encrypted array and {type(other)} not supported")

    def __ge__(self, other):
        if isinstance(other, EncryptedArray):
            if not self.dtype.is_exact() or not other.dtype.is_exact():
                raise TypeError(
                    f"greater-than or equal (>=) not supported between floating point arrays; use "
                    f"greater-than (>) instead"
                )
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_GreaterEqual(self.dtype),
                predecessors=[self, other],
                dtype=EncryptedBool(),
            )
        elif isinstance(other, (int, float, NP_INT_TYPES, NP_FLOAT_TYPES)):
            if not self.dtype.is_exact():
                raise TypeError(
                    f"greater-than or equal (>=) not supported between floating point arrays; use "
                    f"greater-than (>) instead"
                )
            return self.__class__(
                shape=self.shape,
                computation=EncArrayConstExprScalar_GreaterEqual(other, self.dtype),
                predecessors=[self],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(f"comparison between encrypted array and {type(other)} not supported")

    def __invert__(self):
        if not isinstance(self.dtype, EncryptedBool):
            raise TypeError(f"not operator (~) can only be applied to boolean arrays")
        return self.__class__(
            shape=self.shape,
            computation=EncArray_Not(self.dtype),
            predecessors=[self],
            dtype=EncryptedBool(),
        )

    def __iter__(self):
        for i in range(0, self.shape[0]):
            yield self[i]

    def __lt__(self, other):
        if isinstance(other, EncryptedArray):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_Less(self.dtype),
                predecessors=[self, other],
                dtype=EncryptedBool(),
            )
        elif isinstance(other, (int, float, NP_INT_TYPES, NP_FLOAT_TYPES)):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayConstExprScalar_Less(other, self.dtype),
                predecessors=[self],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(f"comparison between encrypted array and {type(other)} not supported")

    def __le__(self, other):
        if isinstance(other, EncryptedArray):
            if not self.dtype.is_exact() or not other.dtype.is_exact():
                raise TypeError(
                    f"less-than or equal (<=) not supported between floating point arrays; use "
                    f"less-than (<) instead"
                )
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_LessEqual(self.dtype),
                predecessors=[self, other],
                dtype=EncryptedBool(),
            )
        elif isinstance(other, (int, float, NP_INT_TYPES, NP_FLOAT_TYPES)):
            if not self.dtype.is_exact():
                raise TypeError(
                    f"less-than or equal (<=) not supported between floating point arrays; use "
                    f"less-than (<) instead"
                )
            return self.__class__(
                shape=self.shape,
                computation=EncArrayConstExprScalar_LessEqual(other, self.dtype),
                predecessors=[self],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(f"comparison between encrypted array and {type(other)} not supported")

    def __matmul__(self, other):
        return self.matmul(other)

    def __rmatmul__(self, other):
        # todo(Joao)
        raise NotImplementedError

    def __mod__(self, other):
        if isinstance(other, (int, float)):
            res = self.__class__(
                shape=self.shape,
                computation=EncArrayClearConstExprScalar_Mod(other, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            raise TypeError(f"Invalid modulo with type {type(other)}")

    def __mul__(self, other):
        if isinstance(
            other,
            (
                float,
                int,
                NP_FLOAT_TYPES,
                NP_INT_TYPES,
            ),
        ):
            res = self.__class__(
                shape=self.shape,
                computation=EncArrayClearConstExprScalar_Mul(other, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        elif isinstance(other, self.__class__):
            resulting_shape = check_shapes_are_broadcastable("__mul__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)
            broadcasted_other = other._inner_broadcast_to(resulting_shape)

            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayEncArray_Mul(self.dtype),
                predecessors=[broadcasted_self, broadcasted_other],
                dtype=mix_dtypes(self.dtype, other.dtype),
            )
            return res
        elif isinstance(other, np.ndarray):
            resulting_shape = check_shapes_are_broadcastable("__mul__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)
            broadcasted_other = np.ascontiguousarray(np.broadcast_to(other, resulting_shape))
            if self.dtype.is_exact():
                other_dtype = find_exact_clear_dtype(other, "__mul__")
                dtype = mix_dtypes(self.dtype, other_dtype)
            else:
                dtype = self.dtype
            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayClearConstArray_Mul(broadcasted_other, self.dtype),
                predecessors=[broadcasted_self],
                dtype=dtype,
            )
            return res
        else:
            raise TypeError(f"Invalid multiplication between encrypted array and {type(other)}")

    def __ne__(self, other):
        if isinstance(other, EncryptedArray):
            if isinstance(self.dtype, EncryptedBool) and isinstance(other.dtype, EncryptedBool):
                return self._inner_bitwise_xor(other)
            elif self.dtype.is_exact() and other.dtype.is_exact():
                return self.__class__(
                    shape=self.shape,
                    computation=EncArrayEncArray_NotEqual(self.dtype),
                    predecessors=[self, other],
                    dtype=EncryptedBool(),
                )
            else:
                raise TypeError(
                    f"not-equal (!=) comparison is only implemented for exact integer arrays; "
                    f"use ~np.isclose instead"
                )
        elif isinstance(other, (int, NP_INT_TYPES)):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayConstExprScalar_NotEqual(other, self.dtype),
                predecessors=[self],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(f"comparison between encrypted array and {type(other)} not supported")

    def __neg__(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Negative(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def __or__(self, other):
        if not isinstance(self.dtype, EncryptedBool) or not isinstance(other.dtype, EncryptedBool):
            raise TypeError(
                f"logical or (|) operator can be applied only between encrypted "
                f"arrays containing boolean elements"
            )
        return self._inner_bitwise_or(other)

    def __pow__(self, power, modulo=None):
        if modulo is not None:
            # todo(Joao): I'm not sure what this modulo is supposed to do, and couldn't find in the docs
            raise ValueError("pow with modulo not supportd")
        if isinstance(power, (int, float)):
            res = self.__class__(
                shape=self.shape,
                computation=EncArrayClearConstExprScalar_Pow(power, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            raise TypeError(f"Invalid exponentiation with type {type(power)}")

    def __radd__(self, other):
        return self.__add__(other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __rpow__(self, other):
        if isinstance(other, (int, float)):
            res = self.__class__(
                shape=self.shape,
                computation=ClearConstExprScalarEncArray_Pow(other, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            raise TypeError(
                f"exponentiation of an encrypted array by a type {type(other)} " f"is not supported"
            )

    def __rsub__(self, other):
        # This is kind of a workaround, but this way only one implementation of __sub__ is needed
        return -self.__sub__(other)

    def __rtruediv__(self, other):
        if isinstance(other, (int, float)):
            res = self.__class__(
                shape=self.shape,
                computation=ConstScalarEncArray_TrueDiv(other, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            raise ValueError(f"Operation __rtruediv__ not implemented for {type(other)}")

    def __setitem__(self, key, value):
        raise NotImplementedError(
            "hnumpy encrypted arrays are immutable: assignment is not possible"
        )

    def __sub__(self, other):
        if isinstance(other, np.ndarray):
            other = clear_array_impl.ClearConstArray(other)
        if isinstance(
            other,
            (int, float, NP_FLOAT_TYPES, NP_INT_TYPES),
        ):
            if self.dtype.is_exact():
                dtype = self.dtype.as_signed()
            else:
                dtype = self.dtype
            res = self.__class__(
                shape=self.shape,
                computation=EncArrayClearConstExprScalar_Sub(np.float64(other), self.dtype),
                predecessors=[self],
                dtype=dtype,
            )
            return res

        if isinstance(other, self.__class__):
            resulting_shape = check_shapes_are_broadcastable("__sub__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)
            broadcasted_other = other._inner_broadcast_to(resulting_shape)

            # need to make type signed here
            if self.dtype.is_exact():
                self_signed = self.dtype.as_signed()
                other_signed = other.dtype.as_signed()
                dtype = mix_dtypes(self_signed, other_signed)
            else:
                dtype = mix_dtypes(self.dtype, other.dtype)

            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayEncArray_Sub(self.dtype),
                predecessors=[broadcasted_self, broadcasted_other],
                dtype=dtype,
            )
            return res
        elif isinstance(other, clear_array_impl.ClearArray):
            resulting_shape = check_shapes_are_broadcastable("__sub__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)

            if other.shape != resulting_shape:
                raise ValueError(
                    f"Broadcasted subtraction between encrypted array and clear array is not supported"
                )

            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayClearArray_Sub(self.dtype),
                predecessors=[broadcasted_self, other],
                dtype=self.dtype,
            )
            return res
        elif isinstance(other, clear_array_impl.ClearConstArray):
            resulting_shape = check_shapes_are_broadcastable("__sub__", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)

            broadcasted_other = np.broadcast_to(other.content, resulting_shape)

            if self.dtype.is_exact():
                dtype = self.dtype.as_signed()
            else:
                dtype = self.dtype

            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayConstClearArray_Sub(
                    np.ascontiguousarray(broadcasted_other), self.dtype
                ),
                predecessors=[broadcasted_self],
                dtype=dtype,
            )
            return res
        else:
            raise ValueError(f"Undefined subtraction between encrypted array and {type(other)}")

    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            res = self.__class__(
                shape=self.shape,
                computation=EncArrayConstScalar_TrueDiv(other, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        elif isinstance(other, self.__class__):
            # todo(Joao): this is probably bad, 1/x will increase the bounds hugely
            return self * (1 / other)
        else:
            raise ValueError(f"Operation __truediv__ not implemented for {type(other)}")

    ## Inner

    def _inner_all(self, axis):
        if not isinstance(self.dtype, EncryptedBool):
            raise TypeError(f"np.all called on non-boolean array")
        if axis is None:
            axis = tuple(range(0, self.ndim))
        if np.iterable(axis):
            axis = np.sort(axis)
            a = self
            for i, ax in enumerate(axis):
                a = a._inner_all(ax - i)
            return a
        if isinstance(axis, (int, NP_INT_TYPES)):
            return log_reduce_non_pot_axis(self, axis, np.bitwise_and)
        else:
            raise TypeError(f"np.all received axis of unrecognized type: {type(axis)}")

    def _inner_any(self, axis):
        if not isinstance(self.dtype, EncryptedBool):
            raise TypeError(f"np.any called on non-boolean array")
        if axis is None:
            axis = tuple(range(0, self.ndim))
        if np.iterable(axis):
            axis = np.sort(axis)
            a = self
            for i, ax in enumerate(axis):
                a = a._inner_any(ax - i)
            return a
        if isinstance(axis, (int, NP_INT_TYPES)):
            return log_reduce_non_pot_axis(self, axis, np.bitwise_or)
        else:
            raise TypeError(f"np.any received axis of unrecognized type: {type(axis)}")

    def _inner_apply(self, func):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Apply(func, self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_atleast1d(self):
        # the array is at least 1d indeed, so we can just return itself
        return self

    def _inner_atleast2d(self):
        if self.ndim >= 2:
            # nothing to do, just return itself
            return self
        else:
            newshape = (1, self.shape[0])
            res = self.__class__(
                shape=newshape,
                computation=EncArray_Reshape(self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res

    def _inner_atleast3d(self):
        if self.ndim >= 3:
            # nothing to do, just return itself
            return self
        elif self.ndim == 2:
            newshape = (self.shape[0], self.shape[1], 1)
            res = self.__class__(
                shape=newshape,
                computation=EncArray_Reshape(self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            newshape = (1, self.shape[0], 1)
            res = self.__class__(
                shape=newshape,
                computation=EncArray_Reshape(self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res

    def _inner_bitwise_and(self, other):
        if isinstance(other, EncryptedArray):
            resulting_shape = check_shapes_are_broadcastable("bitwise_and", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)
            broadcasted_other = other._inner_broadcast_to(resulting_shape)
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_BitwiseAnd(self.dtype),
                predecessors=[broadcasted_self, broadcasted_other],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(
                f"bitwise_and between encrypted array and {type(other)} not implemented"
            )

    def _inner_bitwise_or(self, other):
        if isinstance(other, EncryptedArray):
            resulting_shape = check_shapes_are_broadcastable("bitwise_or_", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)
            broadcasted_other = other._inner_broadcast_to(resulting_shape)
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_BitwiseOr(self.dtype),
                predecessors=[broadcasted_self, broadcasted_other],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(
                f"bitwise_and between encrypted array and {type(other)} not implemented"
            )

    def _inner_bitwise_xor(self, other):
        if isinstance(other, EncryptedArray):
            resulting_shape = check_shapes_are_broadcastable("bitwise_xor", self, other)
            broadcasted_self = self._inner_broadcast_to(resulting_shape)
            broadcasted_other = other._inner_broadcast_to(resulting_shape)
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_BitwiseXor(self.dtype),
                predecessors=[broadcasted_self, broadcasted_other],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(
                f"bitwise_and between encrypted array and {type(other)} not implemented"
            )

    def _inner_broadcast_to(self, shape):
        if list(shape) == list(self.shape):
            return self

        res = self.__class__(
            shape=shape,
            computation=EncArray_BroadcastTo(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_cbrt(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Cbrt(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_ceil(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Ceil(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_clip(self, a_min, a_max, *args, **kwargs):
        if isinstance(a_min, (int, float)) and isinstance(a_max, (int, float)):
            res = self.__class__(
                shape=self.shape,
                computation=EncArray_Clip(a_min, a_max, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        elif isinstance(a_max, encrypted_scalar_impl.EncryptedScalar) or isinstance(
            a_min, encrypted_scalar_impl.EncryptedScalar
        ):
            raise NotImplementedError(
                "hnp.clip() is not implemented with bounds given from encrypted scalar"
            )
        else:
            raise TypeError(
                f"Type {type(a_min)} or {type(a_max)} is invalid for call to hnp.clip()"
            )

    def _inner_cross(self, other):
        if isinstance(other, np.ndarray):
            other = clear_array_impl.ClearConstArray(other)

        if isinstance(other, clear_array_impl.ClearConstArray):
            resulting_shape = check_shapes_are_crossable("cross", self, other)
            res = self.__class__(
                shape=resulting_shape,
                computation=EncArrayClearConstArray_Cross(other.content, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            raise NotImplementedError(
                f"Cross product between encrypted array and " f"{type(other)} not yet implemented"
            )

    def _inner_dot1d(self, other):
        if isinstance(other, np.ndarray):
            other = clear_array_impl.ClearConstArray(other)
        if isinstance(other, clear_array_impl.ClearConstArray):
            res = self.__class__(
                shape=(1,),
                computation=EncArrayClearConstArray_Dot1d(other.content, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        elif isinstance(other, EncryptedArray):
            return np.sum(self * other)
        else:
            raise NotImplementedError(
                f"Dot product between encrypted array and " f"{type(other)} not yet implemented"
            )

    def _inner_dot2d(self, other):
        if isinstance(other, np.ndarray):
            other = clear_array_impl.ClearConstArray(other)
        if isinstance(other, clear_array_impl.ClearConstArray):
            if len(self.shape) == 2:  # encrypted is the matrix
                output_shape = (self.shape[0],)
            else:  # plain is the matrix
                output_shape = (other.shape[1],)
            res = self.__class__(
                shape=output_shape,
                computation=EncArrayClearConstArray_Dot2d(other.content, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            raise NotImplementedError(
                f"Dot product between encrypted array and " f"{type(other)} not yet implemented"
            )

    def _inner_exp(self, *args, **kwargs):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Exp(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_expand_dims(self, axis):
        if not isinstance(axis, (tuple, list)):
            axis = (axis,)
        out_ndim = len(axis) + self.ndim
        axis = normalize_axis_tuple(axis, out_ndim)

        shape_it = iter(self.shape)
        newshape = [1 if ax in axis else next(shape_it) for ax in range(out_ndim)]

        res = self.__class__(
            shape=newshape,
            computation=EncArray_Reshape(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_floor(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Floor(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_i0(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_i0(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_isclose(self, other, atol):
        if isinstance(other, EncryptedArray):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_IsClose(atol, self.dtype),
                predecessors=[self, other],
                dtype=EncryptedBool(),
            )
        elif isinstance(other, (int, float, NP_INT_TYPES, NP_FLOAT_TYPES)):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayConstExprScalar_IsClose(other, atol, self.dtype),
                predecessors=[self],
                dtype=EncryptedBool(),
            )
        else:
            raise TypeError(f"comparison between encrypted array and {type(other)} not supported")

    def _inner_log(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Log(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_log2(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Log2(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_log10(self, *args, **kwargs):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Log10(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_maximum(self, other):
        if isinstance(other, EncryptedArray):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_Maximum(self.dtype),
                predecessors=[self, other],
                dtype=mix_dtypes(self.dtype, other.dtype),
            )
        elif isinstance(other, (int, float, NP_INT_TYPES, NP_FLOAT_TYPES, np.ndarray)):
            if self.dtype.is_exact() and isinstance(other, (float, NP_FLOAT_TYPES)):
                logger.warning(
                    f"np.maximum between integer array and floating-point type ({other}); value will be truncated"
                )
            return (self + other + abs(self - other)) / 2
        else:
            raise TypeError(
                f"np.maximum between encrypted array and unrecognized type ({type(other)}"
            )

    def _inner_mean(self, axis):
        if axis is None:
            res = self.__class__(
                shape=(1,),
                computation=EncArray_Mean(axis, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        elif isinstance(axis, (tuple, int)):
            axis = normalize_axis_tuple(axis, self.ndim)
            if not all(map(lambda x: x < self.ndim, axis)):
                raise ValueError(
                    f"hnp.mean() receive an invalid axis for its dimension:"
                    f"axes are {axis}, but array has dimension {self.ndim}"
                )
            newshape = list(
                map(
                    lambda i: self.shape[i],
                    filter(lambda i: i not in axis, range(0, self.ndim)),
                )
            )
            if len(newshape) == 0:
                newshape = (1,)
            res = self.__class__(
                shape=newshape,
                computation=EncArray_Mean(axis, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            raise TypeError(f"axis has unrecognized type: {type(axis)}")

    def _inner_minimum(self, other):
        if isinstance(other, EncryptedArray):
            return self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_Minimum(self.dtype),
                predecessors=[self, other],
                dtype=mix_dtypes(self.dtype, other.dtype),
            )
        elif isinstance(other, (int, float, np.ndarray, NP_INT_TYPES, NP_FLOAT_TYPES)):
            return (self + other - abs(self - other)) / 2
        else:
            raise TypeError(
                f"np.maximum between encrypted array and unrecognized type ({type(other)}"
            )

    def _inner_moveaxis(self, source, destination):
        # implementation from numpy's source
        # https://github.com/numpy/numpy/blob/v1.20.0/numpy/core/numeric.py#L1404-L1473
        source = normalize_axis_tuple(source, self.ndim)
        destination = normalize_axis_tuple(destination, self.ndim)
        if len(source) != len(destination):
            raise ValueError(
                "moveaxis() `source` and `destination` arguments must have "
                "the same number of elements"
            )
        order = [n for n in range(self.ndim) if n not in source]

        for dest, src in sorted(zip(destination, source)):
            order.insert(dest, src)

        return self.transpose(order)

    def _inner_pad(self, pad_width, mode):
        if mode != "constant":
            raise NotImplementedError(
                f"pad is implemented only in constant mode, received {mode} instead"
            )
        if isinstance(pad_width, int):
            pad_width = tuple([(pad_width, pad_width) for _ in range(self.ndim)])
        if not np.iterable(pad_width):
            raise TypeError(f"pad_width type ({type(pad_width)} is not iterable")
        pad_width = tuple(
            [(pad[0], pad[1]) if isinstance(pad, tuple) else (pad, pad) for pad in pad_width]
        )
        newshape = tuple(
            [
                shape + pad_before + pad_after
                for shape, (pad_before, pad_after) in zip(self.shape, pad_width)
            ]
        )
        to_insert = tuple(
            [
                np.s_[pad_before : shape - pad_after]
                for shape, (pad_before, pad_after) in zip(newshape, pad_width)
            ]
        )
        base_arr = np.zeros(newshape)
        init_const = self.__class__(
            shape=newshape,
            computation=EncArray_InitConstArray(base_arr, self.dtype),
            predecessors=[],
            dtype=self.dtype,
        )
        return init_const._inner_setitem(to_insert, self)

    def _inner_reshape(self, newshape):
        newshape = deepcopy(newshape)
        if isinstance(newshape, int):
            newshape = (newshape,)
        if not isinstance(newshape, tuple):
            raise TypeError(f"Invalid type of shape to reshape(): {type(newshape)}")
        adjust = None
        for num, ns in enumerate(newshape):
            if ns == -1:
                if adjust is not None:
                    raise ValueError(f"hnp.reshape received more than one -1: {newshape},")
                adjust = num
        product = reduce(lambda x, y: x * y, newshape)
        old_product = reduce(lambda x, y: x * y, self.shape)
        if adjust is not None:
            product *= -1
            if old_product % product != 0:
                raise ValueError(
                    f"Passed newshape with -1: {newshape}, however there's no value that would"
                    f"satisfy newshape with old shape {self.shape}"
                )
            ratio = old_product // product
            newshape = list(newshape)
            newshape[adjust] = ratio
            newshape = tuple(newshape)
            product = reduce(lambda x, y: x * y, newshape)
        if product != old_product:
            raise ValueError(
                f"shape() called with invalid shape: {newshape} is "
                f"incompatible with {self.shape}"
            )
        res = self.__class__(
            shape=newshape,
            computation=EncArray_Reshape(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_resize(self, newshape):
        if isinstance(newshape, int):
            newshape = (newshape,)
        if not isinstance(newshape, tuple):
            raise TypeError(f"Invalid type of shape to hnp.resize: {type(newshape)}")
        product = reduce(lambda x, y: x * y, newshape)
        old_product = reduce(lambda x, y: x * y, self.shape)
        if product > old_product:
            raise ValueError(
                f"Trying to resize from smaller ({self.shape}) into "
                f"bigger ({newshape}) shape, which is not support by"
                f"hnp.resize() yet"
            )
        res = self.__class__(
            shape=newshape,
            computation=EncArray_Resize(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_rollaxis(self, axis, start):
        # implementation from numpy's source
        # https://github.com/numpy/numpy/blob/v1.20.0/numpy/core/numeric.py#L1251-L1338
        axis = normalize_axis_index(axis, self.ndim)
        if start < 0:
            start += self.ndim
        if not (0 <= start <= self.ndim):
            raise AxisError(
                f"axis argument requires {-self.ndim} <= "
                f"start <= {self.ndim}, but {start} was provided"
            )
        if axis < start:
            start -= 1
        if axis == start:
            return self
        axes = list(range(self.ndim))
        axes.remove(axis)
        axes.insert(start, axis)
        return self.transpose(axes)

    def _inner_round(self):
        # todo(Joao): in numpy there's an arg for decimals
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Round(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_setitem(self, obj, values):
        if isinstance(obj, int):
            obj = (obj,)
        if not isinstance(obj, tuple):
            raise TypeError(f"setitem expected tuple, received {type(obj)}")
        if not all([isinstance(x, (slice, int)) for x in obj]):
            bad_indeces = list(filter(lambda x: not isinstance(x, (slice, int)), obj))
            raise TypeError(
                f"setitem expects slices or indexes, received instead unrecognized types {bad_indeces}"
            )

        def slice_or_int_to_pyslice(tup):
            idx, item = tup
            if isinstance(item, int):
                return PySliceOrIndex(item)
            elif isinstance(item, slice):
                start = item.start if item.start is not None else 0
                end = item.stop if item.stop is not None else self.shape[idx]
                step = item.step if item.step is not None else 1
                if start < 0:
                    start = self.shape[idx] + start
                if end < 0:
                    end = self.shape[idx] + end
                if step < 0:
                    start, end = end + 1, start + 1
                return PySliceOrIndex({"start": start, "end": end, "step": step})
            else:
                raise ValueError(f"Invalid item type in slice: {type(item)}")

        py_obj = tuple(map(slice_or_int_to_pyslice, enumerate(obj)))
        slice_shape = list(deepcopy(self.shape))
        for idx, item in enumerate(obj):
            if isinstance(item, slice):
                start = item.start if item.start is not None else 0
                end = item.stop if item.stop is not None else self.shape[idx]
                step = item.step if item.step is not None else 1
                if start < 0:
                    start = self.shape[idx] + start
                    if end < 0:
                        end = self.shape[idx] + end
                    if step < 0:
                        step = -step
                        start, end = end, start
                    slice_shape[idx] = (end - start) // step
            elif isinstance(item, int):
                # we'll filter this dimension out to eliminate it
                slice_shape[idx] = None
            else:
                raise TypeError(
                    f"__getitem__ slice contains type {type(item)} which is not recognized"
                )
        slice_shape = tuple(filter(lambda x: x is not None, slice_shape))

        if slice_shape != values.shape:
            resulting_shape = broadcast_shape(values.shape, slice_shape)
            if resulting_shape is not None:
                resulting_shape = tuple(resulting_shape)
                values = values._inner_broadcast_to(resulting_shape)
        if isinstance(values, self.__class__):
            res = self.__class__(
                shape=self.shape,
                computation=EncArrayEncArray_SetItemWithConstExprIndex(obj, py_obj, self.dtype),
                predecessors=[self, values],
                dtype=mix_dtypes(self.dtype, values.dtype),
            )
            return res
        else:
            raise TypeError(f"values have type {type(values)} which is not supported by setitem")

    def _inner_sign(self, *args, **kwargs):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Sign(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_split(self, indices_or_sections, axis):
        if isinstance(indices_or_sections, int):
            if self.shape[axis] % indices_or_sections != 0:
                raise ValueError(
                    f"Array of shape {self.shape} cannot be split into "
                    f"{indices_or_sections} equal parts"
                )
            size_of_part = self.shape[axis] // indices_or_sections
            res = []
            for part in range(0, self.shape[axis], size_of_part):
                _slice = [slice(None)] * self.ndim
                _slice[axis] = np.s_[part : part + size_of_part]
                res.append(self[tuple(_slice)])
            return res
        elif isinstance(indices_or_sections, (tuple, list)):
            raise NotImplementedError(
                f"splitting is not implemented with non-integer " f"indices_or_sections"
            )
        else:
            raise TypeError(
                f"split received indices_or_sections of unrecognized "
                f"type ({type(indices_or_sections)})"
            )

    def _inner_trunc(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArray_Trunc(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    ## Free methods

    def amax(self, axis=None, *args, **kwargs):
        return self.max(axis, *args, **kwargs)

    def amin(self, axis=None, *args, **kwargs):
        return self.min(axis, *args, **kwargs)

    @property
    def flat(self):
        return self.flatten()

    def flatten(self, order="C"):
        if order != "C":
            raise ValueError(
                f"hnp.flatten() has invalid order {order} - only C indexing order is supported"
            )
        flattened_shape = reduce(lambda x, y: x * y, self.shape)
        res = self.__class__(
            shape=(flattened_shape,),
            computation=EncArray_Flatten(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def matmul(self, other):
        if isinstance(other, clear_array_impl.ClearArray):
            if len(self.shape) != 2 or self.shape[1] != other.shape[0]:
                raise ValueError("Incompatible matrix dimensions for matrix multiplication")

            res = self.__class__(
                shape=(self.shape[0], other.shape[1]),
                computation=EncArrayClearArray_Matmul(self.dtype),
                predecessors=[self, other],
                dtype=self.dtype,
            )
            return res
        elif isinstance(other, (clear_array_impl.ClearConstArray, np.ndarray)):
            if len(self.shape) == 1 and len(other.shape) == 2:
                return self._inner_dot2d(other)
            if len(self.shape) == 1 and len(other.shape) == 1:
                return self._inner_dot1d(other)
            if len(self.shape) != 2 or self.shape[1] != other.shape[0]:
                raise ValueError(
                    f"Matrix multiplication with incompatible dimensions:"
                    f"({self.shape[0]},{self.shape[1]})x({other.shape[0]},{other.shape[1]}),"
                    f"{self.shape[1]} != {other.shape[0]}"
                )
            if isinstance(other, np.ndarray):
                other = clear_array_impl.ClearConstArray(other)
            res = self.__class__(
                shape=(self.shape[0], other.shape[1]),
                computation=EncArrayClearConstArray_Matmul(other.content, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        elif isinstance(other, EncryptedArray):
            # todo: this operation will be very slow, maybe needs intrinsic vm instruction
            if len(self.shape) == 1 and len(other.shape) == 1:
                return self._inner_dot1d(other)
            remove_dim = None
            self_ = self
            if len(self.shape) == 1:
                self_ = self._inner_expand_dims((0,))
                remove_dim = 0
            if len(other.shape) == 1:
                other = other._inner_expand_dims((1,))
                remove_dim = 1
            other = other.transpose()
            rows = other.shape[0]
            cols = []
            for r in range(rows):
                row = other[r, :]
                m = (self_ * row).sum(axis=1)
                cols.append(m)
            res = np.stack(cols).transpose()
            if remove_dim is not None:
                res = np.squeeze(res, remove_dim)
            return res
        else:
            raise TypeError(f"can't perform matmul between encrypted array and {type(other)}")

    def max(self, axis, *args, **kwargs):
        if axis is None:
            axis = tuple(range(0, self.ndim))
        if np.iterable(axis):
            axis = np.sort(axis)
            a = self
            for i, ax in enumerate(axis):
                a = a.max(ax - i)
            return a
        if isinstance(axis, (int, NP_INT_TYPES)):
            return log_reduce_non_pot_axis(self, axis, np.maximum)
        else:
            raise TypeError(f"max received axis of unrecognized type: {type(axis)}")

    def mean(self, axis=None, *args, **kwargs):
        return self._inner_mean(axis)

    def min(self, axis, *args, **kwargs):
        if axis is None:
            axis = tuple(range(0, self.ndim))
        if np.iterable(axis):
            axis = np.sort(axis)
            a = self
            for i, ax in enumerate(axis):
                a = a.min(ax - i)
            return a
        if isinstance(axis, int):
            return log_reduce_non_pot_axis(self, axis, np.minimum)
        else:
            raise TypeError(f"min received axis of unrecognized type: {type(axis)}")

    def reshape(self, newshape):
        return self._inner_reshape(newshape)

    def sqrt(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayClearConstExprScalar_Pow(0.5, self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def squeeze(self, axis=None):
        if axis is None:
            newshape = tuple(filter(lambda s: s != 1, self.shape))
        elif isinstance(axis, (tuple, int, NP_INT_TYPES)):
            if isinstance(axis, (int, NP_INT_TYPES)):
                axis = (axis,)
            axis = normalize_axis_tuple(axis, self.ndim)
            for a in axis:
                if self.shape[a] != 1:
                    raise AxisError(f"squeeze() was passed axis {axis}, which is not 1")
            newshape = tuple([s for a, s in enumerate(self.shape) if a not in axis])
        else:
            raise TypeError(f"hnp.squeeze() receive invalid argument type for axis: {type(axis)}")
        res = self.__class__(
            shape=newshape,
            computation=EncArray_Reshape(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def sum(self, axis=None, *args, **kwargs):
        if axis is None:
            res = self.__class__(
                shape=(1,),
                computation=EncArray_Sum(axis, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res
        else:
            axis = normalize_axis_tuple(axis, self.ndim)
            if not all(map(lambda x: x < self.ndim, axis)):
                raise ValueError(
                    f"hnp.sum() receive an invalid axis for its dimension:"
                    f"axes are {axis}, but array has dimension {self.ndim}"
                )
            newshape = list(
                map(
                    lambda i: self.shape[i],
                    filter(
                        lambda i: i not in axis,
                        range(0, self.ndim),
                    ),
                )
            )
            if len(newshape) == 0:
                newshape = (1,)
            res = self.__class__(
                shape=newshape,
                computation=EncArray_Sum(axis, self.dtype),
                predecessors=[self],
                dtype=self.dtype,
            )
            return res

    def transpose(self, axes=None):
        if axes is None:
            axes = tuple(reversed(range(0, self.ndim)))
        corrected_axes = list(axes)
        corrected_axes = normalize_axis_tuple(corrected_axes, self.ndim)
        corrected_axes = corrected_axes + (len(corrected_axes),)
        res = self.__class__(
            shape=tuple(map(lambda a: self.shape[a], axes)),
            computation=EncArray_Transpose(corrected_axes, self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    # Trigonometric functions

    def _inner_sin(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArraySin(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_cos(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayCos(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_tan(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayTan(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_arcsin(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayArcSin(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_arccos(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayArcCos(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_arctan(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayArcTan(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_arctan2(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayArcTan2(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_hypot(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayHypot(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_sinh(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArraySinh(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_cosh(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayCosh(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_tanh(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayTanh(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_arcsinh(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayArcSinh(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_arccosh(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayArcCosh(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_arctanh(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayArcTanh(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_deg2rad(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayDeg2Rad(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_rad2deg(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayRad2Deg(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_degrees(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayDegrees(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res

    def _inner_radians(self):
        res = self.__class__(
            shape=self.shape,
            computation=EncArrayRadians(self.dtype),
            predecessors=[self],
            dtype=self.dtype,
        )
        return res
