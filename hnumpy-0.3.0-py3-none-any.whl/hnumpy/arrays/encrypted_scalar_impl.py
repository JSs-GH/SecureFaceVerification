from ..encrypted_types import etype
from .base import BaseArray


class EncryptedScalar:
    def __init__(
        self,
        val_range=None,
        graph=None,
        predecessors=None,
        computation=None,
        dtype=None,
        etype=etype("float5"),
    ):
        self.graph = graph
        self.val_range = val_range
        self.shape = (1,)
        self.predecessors = predecessors
        self.computation = computation
        self.dtype = dtype
        self.etype = etype
