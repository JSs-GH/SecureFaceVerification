def check_shapes_match(func_name: str, *nodes):
    """
    Check if shapes of a list of nodes match.
    :param func_name: name of the function that was called. Only serve as a better error message.
    :param nodes: list of nodes to check their shapes
    :raises ValueError: if shapes of nodes doesn't match
    """
    first_shape = nodes[0].shape
    if not all([node.shape == first_shape for node in nodes]):
        raise ValueError(
            f"Shape mismatch while trying to compute {func_name}: all the array shapes must be the same, "
            f"but values are {[node.shape for node in nodes]}"
        )


def broadcast_shape(shape1, shape2):
    result = []
    for size1, size2 in zip(shape1[::-1], shape2[::-1]):
        if size1 != size2 and size1 != 1 and size2 != 1:
            return None
        else:
            result.append(max(size1, size2))

    if len(result) < len(shape1):
        for i in reversed(range(len(shape1) - len(result))):
            result.append(shape1[i])
    elif len(result) < len(shape2):
        for i in reversed(range(len(shape2) - len(result))):
            result.append(shape2[i])

    return list(reversed(result))


def check_shapes_are_broadcastable(func_name, *nodes):
    """
    Check if shapes of a list of nodes are broadcastable.
    :param func_name: name of the function that was called. Only serve as a better error message.
    :param nodes: list of nodes to check
    :raises ValueError: if shapes of nodes aren't broadcastable
    """
    resulting_shape = nodes[0].shape
    for node in nodes[1:]:
        shape = node.shape
        resulting_shape = broadcast_shape(shape, resulting_shape)
        if resulting_shape is None:
            raise ValueError(
                f"Shape mismatch while trying to compute {func_name}: shapes must be broadcastable, "
                f"but they are not ({[node.shape for node in nodes]})"
            )

    return resulting_shape


def check_shapes_are_crossable(func_name, lhs, rhs):
    lhs_shape = list(lhs.shape)
    rhs_shape = list(rhs.shape)

    if lhs_shape != rhs_shape:
        raise ValueError(
            f"Shape mismatch while trying to compute {func_name}: shapes must be the same, "
            f"but one of them is {lhs_shape} and the other one is {rhs_shape}"
        )

    if len(lhs_shape) != 1 and len(lhs_shape) != 2:
        raise ValueError(
            f"Shape mismatch while trying to compute {func_name}: "
            f"operands must be either a vector or a list of vectors, "
            f"but their shape is {lhs_shape}"
        )

    if lhs_shape[-1] != 2 and lhs_shape[-1] != 3:
        raise ValueError(
            f"Shape mismatch while trying to compute {func_name}: "
            f"operands must be consist of 2 or 3 dimensional vectors, "
            f"but they are {lhs_shape[-1]} dimensional"
        )

    if lhs_shape[-1] == 2:
        if len(lhs_shape) == 1:
            resulting_shape = [1]
        else:
            resulting_shape = [lhs_shape[0]]
    else:
        if len(lhs_shape) == 1:
            resulting_shape = [3]
        else:
            resulting_shape = [lhs_shape[0], 3]

    return resulting_shape
