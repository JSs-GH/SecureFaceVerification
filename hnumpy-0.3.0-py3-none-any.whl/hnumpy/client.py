from time import perf_counter

import numpy
from loguru import logger
from zamavm import PyClientEnvironment, PyKeyring


class ClientContext:
    def __init__(self, client_params, ks_keys_dict, pbs_keys_dict, input_names):
        self.client_params = client_params
        self.ks_keys_dict = ks_keys_dict
        self.pbs_keys_dict = pbs_keys_dict
        self.input_names = input_names

    def keygen(
        self,
        noiseless: bool = False,
        null_mask: bool = False,
        null_sk: bool = False,
        keyring: PyKeyring = None,
    ) -> PyClientEnvironment:
        # todo(Joao): have a minimal cost model for key creation
        TIME_PER_KS_KEY = 10
        TIME_PER_PBS_KEY = 30
        key_creation_time = TIME_PER_KS_KEY * len(self.ks_keys_dict) + TIME_PER_PBS_KEY * len(
            self.pbs_keys_dict
        )
        logger.info(
            f"Creating {len(self.ks_keys_dict)} keyswitching key(s) and {len(self.pbs_keys_dict)} bootstrapping "
            f"key(s). This should take approximately {key_creation_time} seconds ({key_creation_time/60} minutes)"
        )
        logger.trace(
            f"Bootstrapping keys: {self.pbs_keys_dict.keys()}\n"
            f"Keyswitching Keys: {self.ks_keys_dict.keys()}\n"
        )

        if noiseless or null_mask or null_sk:
            logger.warning(f"This key generation is made with unsecure parameters")

        start_time = perf_counter()
        client_env = self.client_params.keygen(noiseless, null_mask, null_sk, keyring)
        logger.debug(f"Key creation time took {perf_counter() - start_time} seconds")

        return ClientEnvironment(client_env, self.input_names)


class ClientEnvironment:
    def __init__(self, client_env, input_names):
        self.client_env = client_env
        self.input_names = input_names

    def encrypt(self, *args):
        # Convert array to dict to give to PyRTE
        inputs = {name: arg.astype(numpy.float64) for (name, arg) in zip(self.input_names, args)}

        enc_inputs = self.client_env.encrypt(inputs)

        # ...then convert back to a single element or a tuple for the user
        res = [enc_inputs[name] for name in self.input_names]
        if len(res) == 1:
            return res[0]
        else:
            return tuple(res)

    def decrypt(self, *args):
        res = self.client_env.decrypt(args)
        if len(res) == 1:
            return res[0]
        else:
            return tuple(res)

    @property
    def public_keys(self):
        return self.client_env.public_keys

    @property
    def secret_keys(self):
        return self.client_env.secret_keys
