from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from scipy.stats import kstest
from zamavm import (
    PyClientParameters,
    PyCloudKeys,
    PyEncrypter,
    PyEngine,
    PyInputDescription,
    PyKeysDescription,
    PyOutputDescription,
    check_graph_shapes,
)

from .client import ClientContext, ClientEnvironment
from .config import CompilationArtifacts, str_timestamp
from .crypto import torus_modular_distance
from .debug_utils import human_readable_layout
from .optimizer.simulation import simulate_graph
from .representation import get_ordered_outputs, target


class FheCircuit:
    def __init__(
        self,
        base_graph,
        target_graph,
        compute_graph,
        inputs,
        input_names,
        input_encodings,
        input_keys,
        input_shapes,
        outputs,
        output_encodings,
        output_keys,
        ks_keys,
        pbs_keys,
        artifacts: CompilationArtifacts,
    ):
        self.artifacts = artifacts
        self.base_graph = base_graph
        self.target_graph = target_graph
        self.input_encodings = input_encodings
        self.input_names = input_names
        input_descriptions = {
            input_name: PyInputDescription.new_ciphertext(
                encryption_key.unique_id,
                PyEncrypter(
                    input_encoding.encoder,
                    encryption_key.log_noise,
                ),
                input_shape,
            )
            for input_name, input_encoding, encryption_key, input_shape in zip(
                input_names, input_encodings, input_keys, input_shapes
            )
        }
        self.num_inputs = len(input_descriptions)
        self.param_descriptions = {}

        self.output_encodings = output_encodings
        output_descriptions = [
            PyOutputDescription.new_decryption(decryption_key.unique_id, output_encoding.encoder)
            for output_encoding, decryption_key in zip(output_encodings, output_keys)
        ]

        self.keys = {}
        for node in self.target_graph.nodes():
            if node.output_encryption_key not in self.keys:
                self.keys[node.output_encryption_key.unique_id] = node.output_encryption_key.length

        self.ks_keys_dict = {}
        for key in ks_keys:
            self.ks_keys_dict[key.unique_id] = (
                key.in_key.unique_id,
                key.out_key.unique_id,
                key.params.level,
                key.params.base_log,
                key.log_noise,
            )
        self.pbs_keys_dict = {}
        for key in pbs_keys:
            self.pbs_keys_dict[key.unique_id] = (
                key.in_key.unique_id,
                key.out_key.unique_id,
                key.params.level,
                key.params.base_log,
                key.out_key.length,
                key.params.k,
                key.log_noise,
            )

        self.keys_description = PyKeysDescription(self.keys, self.ks_keys_dict, self.pbs_keys_dict)

        self.csp = PyClientParameters(
            self.keys_description,
            input_descriptions,
            self.param_descriptions,
            output_descriptions,
        )

        check_graph_shapes(compute_graph, self.csp)

        self._engine = PyEngine.new_from_raw_graph(
            compute_graph,
            inputs,
            outputs,
            self.csp,
        )

    def export_compilation_report(self, out_name=None):
        report_id = out_name if out_name is not None else str_timestamp()
        report_dir = Path(report_id)
        report_dir.mkdir(parents=True)
        self.artifacts.export_report(report_dir)
        self.draw_intermediate_graph(save_to_filename=report_dir / "base_graph.png")
        self.draw_target_graph(save_to_filename=report_dir / "target_graph.png")

    def create_context(self):
        return ClientContext(self.csp, self.ks_keys_dict, self.pbs_keys_dict, self.input_names)

    def _check_enough_args(self, args):
        if len(args) != self.num_inputs:
            raise RuntimeError(
                f"Calling homomorphic function with less arguments than "
                f"number of inputs: function takes {self.num_inputs} "
                f"inputs, but {len(args)} were provided"
            )

    def run(self, public_keys, *args):
        if not isinstance(public_keys, PyCloudKeys):
            raise RuntimeError(
                f"run() requires the public keys to be passed to it "
                f"as the first argument, however, the first argument is of "
                f"type {type(public_keys)}  -- probably missing:\n"
                f"\tkeys = context.keygen()\n"
                f"\tenc_inputs = keys.encrypt(...)\n"
                f"\thomomorphic_fun.run(keys.public_keys, enc_inputs)"
            )

        self._check_enough_args(args)

        args = {name: arg.astype(np.uint64) for (name, arg) in zip(self.input_names, args)}
        result = self._engine.run(args, public_keys)
        if len(result) == 1:
            return result[0]
        else:
            return tuple(result)

    def encrypt_and_run(self, keys, *args):
        """for now, must be called with non-encrypted values; things are encrypted
        in the rte an validated, so this data structure should more appropriately be called
        `validator` or something similar"""
        if not isinstance(keys, ClientEnvironment):
            raise RuntimeError(
                f"encrypt_and_run() requires the keys to be passed to it "
                f"as the first argument, however, the first argument is of "
                f"type {type(keys)}  -- probably missing:\n"
                f"\tkeys = context.keygen()\n"
                f"\thomomorphic_fun.encrypt_and_run(keys, ...) "
            )

        self._check_enough_args(args)
        args = {name: arg.astype(np.float64) for (name, arg) in zip(self.input_names, list(args))}
        result = self._engine.encrypt_and_run(args, keys.client_env)
        if len(result) == 1:
            return result[0]
        else:
            return tuple(result)

    def _debug_raw_outputs(self, keys, *args):
        """
        Debug intermediate outputs without applying decoding.
        :returns: a tuple containing:
            - dictionary of the intermediate values
            - outputs of the circuit (same as calling encrypt_and_run)
        """
        debug_outputs = {}

        def callback(name, output):
            # if name in outputs.keys():
            debug_outputs[name] = output

        args = {name: arg.astype(np.float64) for (name, arg) in zip(self.input_names, list(args))}
        real_outputs = self._engine.encrypt_and_run(args, keys.client_env, callback)

        return debug_outputs, real_outputs

    def _debug(self, *args):
        """
        Debug intermediate values (decoded).
        :return: dictionary of the decoded intermediate values
        """
        debug_outputs, _ = self._debug_raw_outputs(*args)

        decoded_outputs = {}
        for key, value in debug_outputs.items():
            node = None
            for n in self.target_graph.nodes():
                if n.unique_id == key:
                    node = n
                    break
            if node.output_encoding is not None:
                decoded_outputs[key] = node.output_encoding.decode(value)
            else:
                raise KeyError(f"problem with node {key} which doesn't have debug output")

        return decoded_outputs

    def _debug_and_draw(self, *args):
        """
        Verbosely debug the execution by printing information about every node
        and drawing the graph with intermediate values.
        """
        debug_outputs = self._debug(*args)
        res_dict = {
            node: (str(node), debug_outputs[node.unique_id])
            for node in nx.topological_sort(self.target_graph)
        }

        # nx.draw_planar(self.target_graph, with_labels=True, labels=res_dict)
        nx.draw(
            self.target_graph,
            human_readable_layout(self.target_graph),
            with_labels=True,
            labels=res_dict,
        )
        plt.show()

    def _theoretical_std_dev(self):
        max_var_out = 0
        for node in self.target_graph:
            max_var_out = max(max_var_out, node.var_out)
        return np.sqrt(max_var_out) / 2 ** 64

    def _compare_real_theoretical_noise(self, keys, *args):

        simulated_results = simulate_graph(self.target_graph, [list(args)], True, False)

        actual_outputs, _ = self._debug_raw_outputs(keys, *args)

        noisy_nodes = []

        for node in nx.topological_sort(self.target_graph):
            actual, theoretical = (
                actual_outputs[node.unique_id],
                simulated_results[node][0],
            )
            actual_torus = actual.flatten().tolist()
            theoretical_torus = theoretical.flatten().tolist()
            mod_ds = []
            for x, y in zip(actual_torus, theoretical_torus):
                mod_d = torus_modular_distance(x, y)
                mod_ds.append(mod_d)
            real_std = np.std(mod_ds)
            predicted_std = np.sqrt(node.var_out) / 2 ** 64
            mean_real = np.mean(mod_ds)

            if real_std > predicted_std:
                noisy_nodes.append((node, predicted_std, real_std))

        if len(noisy_nodes) == 0:
            print(f"Every node has less noise than theoretically expected")
        else:
            print(f"Some nodes have more noise than theoretically expected:")
            for node in noisy_nodes:
                print(
                    f"Node {node[0].unique_id} ({node[0]}): theoretical noise: {node[1]}, real noise: {node[2]}"
                    f"encoding: {node[0].output_encoding.offset, node[0].output_encoding.delta}"
                )

    def draw_intermediate_graph(self, save_to_filename=None):
        """
        Draw the intermediate representation graph composed of plaintext operations.
        """
        f = plt.figure()

        nx.draw(
            self.base_graph,
            human_readable_layout(self.base_graph),
            with_labels=True,
        )

        if save_to_filename is None:
            plt.show()
        else:
            f.savefig(save_to_filename)

    def draw_target_graph(self, save_to_filename=None):
        """
        Draw the target representation graph composed of HE specific operations.
        """
        f = plt.figure()

        nx.draw(
            self.target_graph,
            human_readable_layout(self.target_graph),
            with_labels=True,
        )

        if save_to_filename is None:
            plt.show()
        else:
            f.savefig(save_to_filename)

    def simulate(self, *args):
        """
        Simulate the encrypted execution returning the final results.
        """
        simulated_results = simulate_graph(self.target_graph, [list(args)], True, False)

        results = [
            self.output_encodings[i].decode(simulated_results[out][0])
            for i, out in enumerate(get_ordered_outputs(self.target_graph))
        ]
        if len(results) == 1:
            return results[0]
        else:
            return tuple(results)

    def _simulate_intermediate_results(self, *args):
        """
        Simulate the encrypted execution returning all intermediate results.
        """
        decoded_results = {}
        simulated_results = simulate_graph(self.target_graph, [list(args)], True, False)
        for node in self.target_graph.nodes():
            encoded_result = simulated_results[node][0]
            decoded_results[node] = node.output_encoding.decode(encoded_result)
        return decoded_results

    def expected_precision(self):
        """
        The expected precision is the maximum distance between the expected and output result.
        """
        output_precision = []
        for encoder in self.output_encodings:
            bits_precision = encoder.bits_precision if encoder.bits_precision is not None else 5
            output_precision.append(encoder.delta / (2 ** bits_precision))
        return list(map(abs, output_precision))

    def _print_target_edge_weights(self):
        for node in self.target_graph.nodes():
            for p in self.target_graph.predecessors(node):
                weight = self.target_graph.get_edge_data(p, node)["weight"]
                print(
                    f"edge between {p.unique_id} ({str(p)}) and {node.unique_id}"
                    f" ({str(node)}): {weight}"
                )

    def _discretize_inputs(self, *args):
        """
        Discetize your inputs into their equivalent values that are gonna be actually used as inputs.
        It's a good way to see the difference between your actual input and the encoded input (using fewer bits probably)
        to know how much to expect from the precision of the result.
        """
        if len(args) != len(self.input_encodings):
            raise ValueError(
                f"hnp._discretize_inputs() was given different number of inputs than "
                f"inputs to the homomorphic function"
            )
        encoded = []
        for encoder, arg in zip(self.input_encodings, args):
            e = encoder.decode(encoder.encode(arg))
            encoded.append(e)
        return (*encoded,)

    def _discretize_outputs(self, *args):
        """
        Discetize your outputs into their equivalent values that should be actually expected.
        It's a good way to see the difference between your outputs in plain computation and the discretized output (using fewer bits probably)
        to know how much to expect from the precision of the result.
        """
        if len(args) != len(self.output_encodings):
            raise ValueError(
                f"hnp._discretize_outputs() was given different number of outputs than "
                f"outputs of the homomorphic function "
            )
        encoded = []
        for encoder, arg in zip(self.output_encodings, args):
            e = encoder.decode(encoder.encode(arg))
            encoded.append(e)
        return (*encoded,)

    def operation_count(self):
        return self.target_graph.number_of_nodes()

    def pbs_count(self):
        result = 0
        for node in self.target_graph.nodes():
            if isinstance(node, target.Target_EncArray_Pbs):
                result += 1
        return result
