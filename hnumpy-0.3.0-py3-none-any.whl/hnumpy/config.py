import platform
from datetime import datetime
from pathlib import Path

import networkx as nx

from .constants import STANDARD_BITS_OF_SECURITY

try:
    # for python >= 3.8
    from importlib.metadata import version
except ImportError:
    from importlib_metadata import version

from loguru import logger


def str_timestamp() -> str:
    now = datetime.now().strftime("%Y%m%d_%H_%M_%S")
    return str(now)


class CompilationArtifacts:
    def __init__(self):
        self.optimizations_applied = []
        self.encoding_subgraphs = []
        self.cryptographic_parameters = None
        self.ir_graph = None
        self.target_graph = None

    def export_report(self, report_dir: Path):
        logger.info(f"Exporting report in {report_dir} directory")
        with open(report_dir.joinpath("optimizations_applied.txt"), "w") as f:
            for op in self.optimizations_applied:
                f.write(f"{op}\n")
        with open(report_dir.joinpath("cryptographic_parameters.txt"), "w") as f:
            for id_, param in self.cryptographic_parameters.items():
                f.write(f"{id_}: {param}\n")
        with open(report_dir.joinpath("target_nodes.txt"), "w") as f:
            for node in nx.topological_sort(self.target_graph):
                f.write(f"{node} ({node.unique_id})\n")
        with open(report_dir.joinpath("ir_nodes.txt"), "w") as f:
            for node in nx.topological_sort(self.target_graph):
                f.write(f"{node} ({node.unique_id})\n")
        with open(report_dir.joinpath("bounds.txt"), "w") as f:
            for node in nx.topological_sort(self.target_graph):
                f.write(f"{node}: ({node.output_lower_bound}, {node.output_upper_bound})\n")
        with open(report_dir.joinpath("versions.txt"), "w") as f:

            f.write(f"OS: {platform.platform()}, {platform.version()}\n")

            f.write(f"python version: {platform.python_version()}\n")

            # From
            #
            # pip list | grep -v Package  | grep -v "\-\-" | cut -f 1 -d " " |
            # awk '{print "\"" $0 "\", "}' | tr -d "\n"

            # TODO: replace that by a python call
            package_list = [
                "attrs",
                "cycler",
                "deap",
                "decorator",
                "hnumpy",
                "iniconfig",
                "kiwisolver",
                "loguru",
                "matplotlib",
                "networkx",
                "numpy",
                "packaging",
                "pandas",
                "Pillow",
                "pip",
                "pluggy",
                "py",
                "py-zamavm",
                "pyparsing",
                "pytest",
                "pytest-codeblocks",
                "python-dateutil",
                "pytz",
                "scipy",
                "setuptools",
                "six",
                "toml",
                "torch",
                "torchvision",
                "tqdm",
                "typing-extensions",
                "wheel",
            ]

            for package in package_list:
                f.write(f"{package} version: {version(package)}\n")


class CompilationConfig:
    def __init__(
        self,
        parameter_optimizer="heuristic",
        parameter_optimizer_options=None,
        probabilistic_bounds=None,
        bits_of_security=STANDARD_BITS_OF_SECURITY,
        with_dataset=None,
        opt_level=1,
        apply_topological_optimizations=None,
        apply_concretized_optimizations=None,
        symbolic_bounds=None,
    ):
        # initialize with default options
        self.parameter_optimizer = parameter_optimizer
        self.probabilistic_bounds = probabilistic_bounds
        self.samples = with_dataset
        self.bits_of_security = bits_of_security
        self.parameter_optimizer_options = parameter_optimizer_options
        # optimization levels
        # 0 -> no optimization at all
        # 1 -> topological optimizations
        # 2 -> concretized node optimizations
        # 3 -> symbolic bounds
        # 3 -> probabilistic bounds
        self.opt_level = opt_level
        self.apply_topological_optimizations = False
        self.apply_concretized_optimizations = False
        self.symbolic_bounds = False
        if self.opt_level >= 1:
            self.apply_topological_optimizations = True
        if self.opt_level >= 2:
            self.symbolic_bounds = True
            self.apply_concretized_optimizations = True
        # override opt_level options if user passed specific options
        if apply_topological_optimizations is not None:
            self.apply_topological_optimizations = apply_topological_optimizations
        if apply_concretized_optimizations is not None:
            self.apply_concretized_optimizations = apply_concretized_optimizations
        if symbolic_bounds is not None:
            self.symbolic_bounds = True
