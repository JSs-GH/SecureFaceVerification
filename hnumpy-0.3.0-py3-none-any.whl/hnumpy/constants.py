import numpy as np

NP_FLOAT_TYPES = (np.float32, np.float64)

NP_INT_TYPES = (np.int8, np.int16, np.int32, np.int64, np.uint8, np.uint16, np.uint32, np.uint64)

STANDARD_BITS_OF_SECURITY = 128
