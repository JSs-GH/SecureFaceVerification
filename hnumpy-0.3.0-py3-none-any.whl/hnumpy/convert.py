from inspect import Signature, signature
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import networkx as nx
import numpy
from loguru import logger
from zamavm import PyGraph

from ._exceptions import CompilationError
from .arrays import ClearArray, EncryptedArray
from .compute import FheCircuit
from .config import CompilationArtifacts, CompilationConfig
from .crypto import EncryptionKey, KsKey, PbsKey, Scheme, choose_crypto_scheme
from .encoding import Encoder
from .optimizer.parameter_optimizer import find_good_parameters
from .optimizer.target_optimizer import concretize_nodes, optimize_bounds, update_bounds
from .optimizer.topological_optimizer import (
    optimize_concretized_topology,
    optimize_topology,
)
from .representation import (
    get_ordered_inputs,
    get_ordered_outputs,
    is_output_node,
    replace_output,
    set_outputs,
)
from .representation.intermediate import *
from .representation.intermediate_to_target import intermediate_to_target
from .representation.target import (
    Target_EncArray_Keyswitch,
    Target_EncArray_Pbs,
    TargetNode,
)
from .representation.target_to_rte import get_operator
from .representation.topology import add_after_node


def add_predecessor_edges_in_pygraph(pygraph, graph, mapping, node, node_idx):
    """
    Given an RTE graph (pygraph), puts predecessors of node in `graph` into `pygraph`
    :param pygraph: rte graph
    :param graph: target graph
    :param mapping: a map between rte graph node index <> target graph node
    :param node: node for which to add predecessors
    :param node_idx: index of node in rte graph
    :return:
    """
    predecessors = [mapping[hex(id(p))] for p in graph.predecessors(node)]
    weights = [graph.get_edge_data(p, node)["weight"] for p in graph.predecessors(node)]
    for p, w in zip(predecessors, weights):
        pygraph.add_edge(p, node_idx, weight=w)


def rte_graph_from_target(
    graph: nx.DiGraph,
) -> Tuple[
    nx.DiGraph,
    List[TargetNode],
    List[str],
    List[Encoder],
    List[EncryptionKey],
    List[str],
    List[TargetNode],
    List[Encoder],
    List[EncryptionKey],
    List[KsKey],
    List[PbsKey],
]:
    """
    Creates an RTE graph from target graph
    :param graph: target graph
    :return: rte graph
    """
    rte_graph = PyGraph()
    mapping = {}

    encryption_keys = []
    pbs_keys = []
    ks_keys = []

    for node in nx.topological_sort(graph):
        node.update_output_shape()
        address = hex(id(node))
        operator = get_operator(node)
        node_idx = rte_graph.add_node(operator)
        mapping[address] = node_idx
        if isinstance(node, Target_EncArray_Pbs):
            pbs_key = node.pbs_key
            if pbs_key not in pbs_keys:
                pbs_keys.append(pbs_key)
        if isinstance(node, Target_EncArray_Keyswitch):
            ks_key = node.ks_key
            if ks_key not in ks_keys:
                ks_keys.append(ks_key)
        add_predecessor_edges_in_pygraph(rte_graph, graph, mapping, node, node_idx)
        encryption_key = node.output_encryption_key
        if encryption_key not in encryption_keys:
            encryption_keys.append(encryption_key)

    inputs = get_ordered_inputs(graph)
    input_names = list(map(lambda node: get_operator(node).get_name(), inputs))
    input_encodings = list(map(lambda node: node.input_encodings[0], inputs))
    input_keys = list(map(lambda node: node.input_encryption_key, inputs))
    input_shapes = list(map(lambda node: get_operator(node).get_shape(), inputs))
    inputs = list(map(lambda node: mapping[hex(id(node))], inputs))
    outputs = get_ordered_outputs(graph)
    output_encodings = list(map(lambda node: node.output_encoding, outputs))
    output_keys = list(map(lambda node: node.output_encryption_key, outputs))
    outputs = list(map(lambda node: mapping[hex(id(node))], outputs))

    return (
        rte_graph,
        inputs,
        input_names,
        input_encodings,
        input_keys,
        input_shapes,
        outputs,
        output_encodings,
        output_keys,
        ks_keys,
        pbs_keys,
    )


def create_target_graph(graph: nx.DiGraph) -> nx.DiGraph:
    """
    Create a target graph from an intermediate one
    :param graph: intermediate graph
    :return: target graph
    """
    compute_graph = graph.copy()
    for node in nx.topological_sort(compute_graph):
        intermediate_to_target(compute_graph, node)
    return compute_graph


def catch_input_errors(sig, args):
    """
    Raises an exception when the inputs are somehow invalid
    :param sig: signature of the function being made homomorphic
    :param args: arguments given to the compilation process
    """
    if len(args) > len(sig.parameters):
        raise CompilationError(
            f"compile_fhe() was passed {len(args)} parameters to the "
            f"function, but it takes only {len(sig.parameters)} parameters"
        )
    for arg_name in sig.parameters.keys():
        if arg_name not in args:
            raise CompilationError(
                f"the function requires a parameter named {arg_name}, "
                f"but this parameter was not provided to compile_fhe()"
            )


def prepare_inputs(graph: nx.DiGraph, sig: Signature, args):
    """
    Prepare inputs and put them into the graph
    :param graph: computation graph
    :param sig: signature of the function being made homomorphic
    :param args: list of inputs
    """
    for input_num, arg_name in enumerate(sig.parameters.keys()):
        arg = args[arg_name]
        if isinstance(arg, ClearArray):
            arg.computation = ClearArray_Input(input_num, arg.dtype, input_bounds=arg.bounds)
        elif isinstance(arg, EncryptedArray):
            arg.computation = EncArray_Input(input_num, arg.dtype, input_bounds=arg.bounds)
        else:
            logger.warning(
                f"Using unsupported type {type(arg)} inside compile_fhe:"
                f"during homomorphic run, the argument will be ignored"
            )
        # add node to the graph
        arg.graph = graph
        graph.add_node(arg)


def optimize_target_graph(
    graph: nx.DiGraph,
    scheme: Scheme,
    parameter_optimizer: str,
    apply_topological_optimization: bool,
    samples: List[Tuple[numpy.ndarray]],
    parameter_optimizer_options: Optional[Dict[str, Any]],
    bits_of_security: int,
    artifacts: CompilationArtifacts,
    probabilistic_bounds: Optional[float] = None,
    symbolic_bounds: bool = False,
):
    """
    Topologically optimize the graph, find appropriate parameters, and figure out bounds
    :param graph: target graph
    :param scheme: cryptoscheme to use
    :param parameter_optimizer: parameter optimize to use for parameter search
    :param confidence_level: standard deviations above the mean to use in optimizer
    :param apply_topological_optimization: whether to topologically optimize graph
    :param samples: dataset / samples to calculate tighter bounds
    :param static_encoder: whether to use a static encoder
    :param bits_of_security: how many bits of security to use
    :param artifacts: compilation artifacts object in which to keep information about compilation
    :param early_stop_ga: whether to stop genetic algorithm early
    :param probabilistic_bounds: whether allowed to use probabilistic bounds, and if so, the confidence level
    :return:
    """
    if apply_topological_optimization:
        optimize_topology(graph, artifacts)

    find_good_parameters(
        graph,
        scheme,
        bits_of_security,
        artifacts,
        optimizer=parameter_optimizer,
        optimizer_options=parameter_optimizer_options,
    )

    update_bounds(graph, probabilistic_bounds)

    optimize_bounds(graph, samples=samples, symbolic_bounds=symbolic_bounds)

    concretize_nodes(graph)


def correct_encoding_after_op(target_graph: nx.DiGraph, artifacts: CompilationArtifacts):
    """
    Add encoding correction nodes where necessary

    :param target_graph: target graph to correct
    :ret: number of nodes corrected
    """
    to_correct = {}
    for node in target_graph.nodes():
        correction_node = node.generate_encoding_correction()
        if correction_node is not None:
            to_correct[node] = correction_node
            # encoding node needs to propagate var_out of predecessor
            correction_node.var_out = node.var_out
            correction_node.input_encodings = node.input_encodings
            correction_node.output_encoding = node.output_encoding
            correction_node.input_lower_bounds = [node.output_lower_bound]
            correction_node.input_upper_bounds = [node.output_upper_bound]
            correction_node.output_lower_bound = node.output_lower_bound
            correction_node.output_upper_bound = node.output_upper_bound
    for tc in to_correct:
        add_after_node(target_graph, tc, to_correct[tc])
        if is_output_node(target_graph, tc):
            replace_output(target_graph, tc, to_correct[tc])
    return len(to_correct)


def compile_homomorphic(
    graph: nx.DiGraph, config: CompilationConfig, artifacts: CompilationArtifacts
) -> FheCircuit:
    """
    Compile a computation represented via an intermediate graph into a callable object in Python
    able to process encrypted data. The compilation process choose the encoding and encryption
    parameters that are right for the provided computation circuit
    :param graph: intermediate graph representing the computation to be compiled
    :param config: configuration to use
    :return: FheCircuit object to be executed via the RTE
    """
    logger.info(f"Create target graph")
    target_graph = create_target_graph(graph)

    scheme = choose_crypto_scheme(graph)

    logger.info(f"Optimize target graph with optimizer `{config.parameter_optimizer}`")
    optimize_target_graph(
        target_graph,
        scheme,
        config.parameter_optimizer,
        config.apply_topological_optimizations,
        config.samples,
        config.parameter_optimizer_options,
        config.bits_of_security,
        artifacts,
        config.probabilistic_bounds,
        config.symbolic_bounds,
    )

    logger.info(f"Correct encoding")
    correct_encoding_after_op(target_graph, artifacts)

    if config.apply_concretized_optimizations:
        optimize_concretized_topology(target_graph, artifacts)

    logger.info(f"Create VM graph")
    artifacts.target_graph = target_graph
    (
        rte_graph,
        inputs,
        input_names,
        input_encodings,
        input_keys,
        input_shapes,
        outputs,
        output_encodings,
        output_keys,
        ks_keys,
        pbs_keys,
    ) = rte_graph_from_target(target_graph)

    logger.info(f"Return the result to the caller")
    return FheCircuit(
        graph,
        target_graph,
        rte_graph,
        inputs,
        input_names,
        input_encodings,
        input_keys,
        input_shapes,
        outputs,
        output_encodings,
        output_keys,
        ks_keys,
        pbs_keys,
        artifacts,
    )


def set_predecessors(graph, node):
    """
    Adds edges from predecessors to `node` into graph, and keep going through predecessors
    :param graph: ir graph
    :param node: node to add predecessors
    """
    if node._predecessors is None:
        return
    for p_num, predecessor in enumerate(node.predecessors):
        if predecessor not in graph:
            graph.add_node(predecessor)
        graph.add_edge(predecessor, node, weight=p_num)
        set_predecessors(graph, predecessor)


def set_graph_from_outputs(graph: nx.DiGraph, output_nodes: EncryptedArray):
    """
    Adds predecessors of `output_nodes` into graph and goes to predecessors of predecessors,
    until forming the whole graph in `graph`
    :param graph: ir graph into which to add nodes
    :param output_nodes: outputs from the function
    """
    if not isinstance(output_nodes, (tuple, list)):
        output_nodes = (output_nodes,)
    for node in output_nodes:
        graph.add_node(node)
        set_predecessors(graph, node)


def check_valid_outputs(func: Callable, outputs: Tuple[EncryptedArray]):
    """
    Checks whether the outputs from the function being converted are valid
    :param func: converted function
    :param outputs: outputs of the function
    """
    if outputs is None:
        raise CompilationError(
            f"The function {func} being converted into its homomoprhic equivalent"
            f"doesn't return anything (likely missing a return statement)."
        )
    if not isinstance(outputs, (tuple, list)):
        outputs = (outputs,)
    if not all(map(lambda x: isinstance(x, EncryptedArray), outputs)):
        raise CompilationError(
            f"The function {func} being converted into its homomorphic equivalent "
            f"has non-encrypted outputs, which is not supported by the homomorphic "
            f"Numpy. Output types found: {list(map(lambda x : type(x), outputs))}"
        )


def compile_fhe(func: Callable, args, **kwargs):
    """Converts a function which is applied to NumPy arrays into its homomorphic equivalent
    :param func: python function computing on numpy arrays
    :param args: a dictionary of hnumpy inputs
    :return: an equivalent function that can compute on encrypted inputs
    """
    logger.info(f"Compiling {func.__name__} into an FHE function")

    logger.info(f"Checking input and output")

    artifacts = CompilationArtifacts()
    sig = signature(func)
    catch_input_errors(sig, args)

    graph = nx.DiGraph()

    prepare_inputs(graph, sig, args)

    # call the function itself using the EncryptedArray/ClearArray/etc objects:
    # these objects will record the operations that are applied to them and create a computational graph,
    # which is given to FheCircuit
    output = func(**args)

    check_valid_outputs(func, output)

    set_graph_from_outputs(graph, output)

    # tag outputs in the graph
    if isinstance(output, (tuple, list)):
        set_outputs(graph, *output)
    else:
        set_outputs(graph, output)

    if "config" in kwargs and isinstance(kwargs["config"], CompilationConfig):
        config = kwargs["config"]
    else:
        config = CompilationConfig()

    artifacts.ir_graph = graph

    return compile_homomorphic(graph, config, artifacts)
