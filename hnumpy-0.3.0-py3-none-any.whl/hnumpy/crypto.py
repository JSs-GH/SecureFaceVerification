import uuid
from abc import ABC, abstractmethod
from itertools import product
from typing import Callable

import numpy as np

from .parameters import Encoder


def torus_modular_distance(x: int, y: int):
    """
    from concrete's torus_modular_distance, calculates the modular distance between two torus elements
    :param x: first torus element
    :param y: second torus element
    :return: d(x, y)
    """
    d0 = (x - y) % 2 ** 64
    d1 = (y - x) % 2 ** 64
    if d0 < d1:
        return d0 / 2 ** 64
    else:
        return d1 / 2 ** 64


def get_test_vector_from_func(
    func: Callable,
    polynomial_size: int,
    input_encoder: Encoder,
    output_encoder: Encoder,
    bits_precision: int,
    bits_padding: int,
    log2_q: int,
):
    shift = log2_q - int(np.log2(polynomial_size)) - bits_padding
    encoded = np.array(list(map(lambda x: x << shift, range(0, polynomial_size))), dtype=np.uint64)

    decoded = input_encoder.decode(encoded)

    evals = func(decoded)

    encoded = output_encoder.encode(evals).astype(np.uint64)

    minus_start_index = polynomial_size - (polynomial_size >> (bits_precision + bits_padding)) + 1
    encoded[minus_start_index:] = ~encoded[minus_start_index:]

    return encoded


class Scheme:
    def __init__(self):
        pass


class TFHE(Scheme):
    pass


def choose_crypto_scheme(_graph):
    """Chooses a cryptoscheme based on the topology and operations in the graph"""
    return TFHE()


class Key(ABC):
    def __init__(self):
        pass

    @abstractmethod
    def check_key_identical(self, other):
        pass


class EncryptionKey(Key):
    def __init__(self, length, log_noise):
        Key.__init__(self)
        self.unique_id = str(uuid.uuid4())
        self.length = length
        self.log_noise = log_noise

    def check_key_identical(self, other):
        return self.length == other.length and self.log_noise == other.log_noise

    def __str__(self):
        return f"EncryptionKey({self.length},{self.log_noise})"

    def __repr__(self):
        return self.__str__()

    def __hash__(self):
        return (self.length, self.log_noise).__hash__()

    def __eq__(self, other):
        return self.check_key_identical(other)


class KeyswitchParameters:
    def __init__(self, base_log, level):
        self.base_log = base_log
        self.level = level

    def check_params_identical(self, other):
        assert isinstance(other, KeyswitchParameters)
        return self.base_log == other.base_log and self.level == other.level

    def __str__(self):
        return f"KeyswitchParameters({self.base_log},{self.level})"

    def __repr__(self):
        return self.__str__()


class PbsParameters:
    def __init__(self, base_log, level):
        self.base_log = base_log
        self.level = level
        # todo(Joao): not fixed
        self.k = 1

    def check_params_identical(self, other):
        assert isinstance(other, PbsParameters)
        return self.base_log == other.base_log and self.level == other.level and self.k == other.k

    def __str__(self):
        return f"PbsParameters({self.base_log},{self.level})"

    def __repr__(self):
        return self.__str__()


class PbsKey(Key):
    def __init__(self, in_key, out_key, params):
        Key.__init__(self)
        self.unique_id = str(uuid.uuid4())
        self.in_key = in_key
        self.out_key = out_key
        self.params = params
        self.log_noise = out_key.log_noise

    def check_key_identical(self, key):
        return (
            self.in_key.check_key_identical(key.in_key)
            and self.out_key.check_key_identical(key.out_key)
            and self.params.check_params_identical(key.params)
        )

    def __str__(self):
        return (
            f"PbsKey("
            f"n: {self.in_key.length},"
            f"N: {self.out_key.length},"
            f"params: {self.params},"
            f"noise: {self.log_noise})"
        )

    def __repr__(self):
        return self.__str__()


class KsKey(Key):
    def __init__(self, in_key, out_key, params):
        Key.__init__(self)
        self.unique_id = str(uuid.uuid4())
        self.in_key = in_key
        self.out_key = out_key
        self.params = params
        self.log_noise = out_key.log_noise

    def check_key_identical(self, key):
        return (
            self.in_key.check_key_identical(key.in_key)
            and self.out_key.check_key_identical(key.out_key)
            and self.params.check_params_identical(key.params)
        )

    def __str__(self):
        return (
            f"KsKey("
            f"N: {self.in_key.length},"
            f"n: {self.out_key.length},"
            f"params: {self.params},"
            f"noise: {self.log_noise})"
        )

    def __repr__(self):
        return self.__str__()


def possible_keyswitch_parameters():
    base_log = list(range(4, 18))
    level = list(range(2, 10))
    perm = list(product(base_log, level))
    # todo(Joao): assumption that q = 2**64
    perm = list(filter(lambda x: x[0] * x[1] < 64, perm))
    return perm


def possible_pbs_parameters():
    base_log = list(range(4, 18))
    level = list(range(2, 10))
    perm = list(product(base_log, level))
    # todo(Joao): assumption that q = 2**64
    perm = list(filter(lambda x: x[0] * x[1] < 64, perm))
    return perm


###################################################
#           SECURITY PARAMETERS
#      Probed from the LWE estimator in June 2021
#
# Martin R. Albrecht, Rachel Player and Sam Scott. On the concrete hardness of Learning with Errors.
# Journal of Mathematical Cryptology. Volume 9, Issue 3, Pages 169–203, ISSN (Online) 1862-2984,
# ISSN (Print) 1862-2976 DOI: 10.1515/jmc-2015-0016, October 2015
# https://eprint.iacr.org/2015/046
###################################################


def secure_parameter_tuples_logq_64_sec_64():
    return [
        (128, -6.11951),
        (160, -7.68984),
        (192, -9.27025),
        (224, -10.8626),
        (256, -12.4058),
        (288, -14.0137),
        (320, -15.5925),
        (352, -17.1738),
        (384, -18.7596),
        (416, -20.3522),
        (448, -21.9537),
        (480, -23.5745),
        (512, -25.1929),
        (544, -26.7808),
        (576, -28.3685),
        (608, -29.982),
        (640, -31.605),
        (672, -33.221),
        (704, -34.8372),
        (736, -36.4545),
        (768, -38.0744),
        (800, -39.6979),
        (832, -41.3262),
        (864, -42.9605),
        (896, -44.602),
        (928, -46.317),
        (960, -48.0463),
        (992, -49.7802),
        (1024, -51.5092),
        (1056, -53.2237),
        (1088, -54.9144),
        (1120, -56.5715),
        (1152, -58.1857),
        (1184, -59.7473),
        (1216, -61.2468),
        (1248, -62.6747),
        # log2_noise artificially trimmed at -64 to make it valid with u64
        (2048, -62.0000),
    ]


def secure_parameter_tuples_logq_64_sec_80():
    return [
        (128, -4.36152),
        (160, -5.68618),
        (192, -6.9787),
        (224, -8.27167),
        (256, -9.53003),
        (288, -10.8254),
        (320, -12.122),
        (352, -13.4057),
        (384, -14.6814),
        (416, -15.9525),
        (448, -17.2283),
        (480, -18.5225),
        (512, -19.8251),
        (544, -21.136),
        (576, -22.4393),
        (608, -23.7116),
        (640, -24.9752),
        (672, -26.2603),
        (704, -27.5541),
        (736, -28.8544),
        (768, -30.1591),
        (800, -31.4628),
        (832, -32.7678),
        (864, -34.0731),
        (896, -35.378),
        (928, -36.6789),
        (960, -37.9786),
        (992, -39.277),
        (1024, -40.5743),
        (1056, -41.8652),
        (1088, -43.1573),
        (1120, -44.453),
        (1152, -45.7544),
        (1184, -47.0749),
        (1216, -48.4013),
        (1248, -49.7315),
        (1280, -51.0634),
        (1312, -52.4296),
        (1344, -53.7951),
        (1376, -55.152),
        (1408, -56.492),
        (1440, -57.8072),
        (1472, -59.0895),
        (1504, -60.3307),
        (1536, -61.5227),
        (1568, -62.6576),
        (1600, -63.7271),
        # log2_noise artificially trimmed at -64 to make it valid with u64
        (2048, -62.0000),
    ]


def secure_parameter_tuples_logq_64_sec_96():
    return [
        (128, -3.00475),
        (160, -4.22454),
        (192, -5.37443),
        (224, -6.48834),
        (256, -7.56672),
        (288, -8.66879),
        (320, -9.77391),
        (352, -10.868),
        (384, -11.9524),
        (416, -13.0255),
        (448, -14.0986),
        (480, -15.1844),
        (512, -16.2767),
        (544, -17.3777),
        (576, -18.4741),
        (608, -19.5483),
        (640, -20.6163),
        (672, -21.699),
        (704, -22.7875),
        (736, -23.8804),
        (768, -24.9761),
        (800, -26.0694),
        (832, -27.1642),
        (864, -28.2605),
        (896, -29.3581),
        (928, -30.4618),
        (960, -31.5651),
        (992, -32.6663),
        (1024, -33.7635),
        (1056, -34.842),
        (1088, -35.9182),
        (1120, -36.9954),
        (1152, -38.0772),
        (1184, -39.1801),
        (1216, -40.2891),
        (1248, -41.4024),
        (1280, -42.5183),
        (1312, -43.6232),
        (1344, -44.7263),
        (1376, -45.828),
        (1408, -46.9283),
        (1440, -48.0276),
        (1472, -49.126),
        (1504, -50.2237),
        (1536, -51.321),
        (1568, -52.4181),
        (1600, -53.5152),
        (1632, -54.6124),
        (1664, -55.7101),
        (1696, -56.8085),
        (1728, -57.9077),
        (1760, -59.0079),
        (1792, -60.1095),
        # log2_noise artificially trimmed at -64 to make it valid with u64
        (2048, -62.0000),
    ]


def secure_parameter_tuples_logq_64_sec_112():
    return [
        (128, -2.46558),
        (160, -2.96101),
        (192, -4.0907),
        (224, -5.11505),
        (256, -6.09853),
        (288, -7.07478),
        (320, -8.04592),
        (352, -9.00411),
        (384, -9.95399),
        (416, -10.9024),
        (448, -11.8473),
        (480, -12.7865),
        (512, -13.7276),
        (544, -14.6824),
        (576, -15.6365),
        (608, -16.5765),
        (640, -17.5121),
        (672, -18.4542),
        (704, -19.3986),
        (736, -20.3448),
        (768, -21.2924),
        (800, -22.2399),
        (832, -23.1884),
        (864, -24.138),
        (896, -25.0888),
        (928, -26.043),
        (960, -26.9976),
        (992, -27.9517),
        (1024, -28.9044),
        (1056, -29.8503),
        (1088, -30.7949),
        (1120, -31.7394),
        (1152, -32.6845),
        (1184, -33.6346),
        (1216, -34.586),
        (1248, -35.5386),
        (1280, -36.492),
        (1312, -37.4438),
        (1344, -38.3957),
        (1376, -39.3478),
        (1408, -40.3001),
        (1440, -41.2527),
        (1472, -42.2056),
        (1504, -43.1589),
        (1536, -44.1128),
        (1568, -45.0671),
        (1600, -46.0221),
        (1632, -46.9778),
        (1664, -47.9341),
        (1696, -48.8913),
        (1728, -49.8493),
        (1760, -50.8083),
        (1792, -51.7682),
        (2048, -59.3200),
    ]


def secure_parameter_tuples_logq_64_sec_128():
    return [
        (128, -2.46558),
        (160, -2.19929),
        (192, -2.88455),
        (224, -3.97194),
        (256, -4.91206),
        (288, -5.81146),
        (320, -6.6934),
        (352, -7.55766),
        (384, -8.41136),
        (416, -9.26651),
        (448, -10.1155),
        (480, -10.9505),
        (512, -11.7847),
        (544, -12.6316),
        (576, -13.4822),
        (608, -14.3323),
        (640, -15.1815),
        (672, -16.0254),
        (704, -16.8662),
        (736, -17.7045),
        (768, -18.5408),
        (800, -19.3745),
        (832, -20.2078),
        (864, -21.0418),
        (896, -21.8775),
        (928, -22.7198),
        (960, -23.5643),
        (992, -24.4105),
        (1024, -25.258),
        (1056, -26.1077),
        (1088, -26.957),
        (1120, -27.8048),
        (1152, -28.65),
        (1184, -29.4862),
        (1216, -30.3196),
        (1248, -31.1513),
        (1280, -31.9824),
        (1312, -32.821),
        (1344, -33.6614),
        (1376, -34.5034),
        (1408, -35.3467),
        (1440, -36.1913),
        (1472, -37.0368),
        (1504, -37.8832),
        (1536, -38.7301),
        (1568, -39.5774),
        (1600, -40.4249),
        (1632, -41.2725),
        (1664, -42.1198),
        (1696, -42.9667),
        (1728, -43.813),
        (1760, -44.6585),
        (1792, -45.503),
        (2048, -52.302),
    ]


def secure_parameter_tuples_logq_64_sec_144():
    return [
        (128, -2.46558),
        (160, -1.5899),
        (192, -1.83107),
        (224, -2.73768),
        (256, -3.85828),
        (288, -4.74146),
        (320, -5.56976),
        (352, -6.37403),
        (384, -7.16183),
        (416, -7.9443),
        (448, -8.71815),
        (480, -9.48115),
        (512, -10.2412),
        (544, -11.0068),
        (576, -11.7741),
        (608, -12.5426),
        (640, -13.3106),
        (672, -14.0744),
        (704, -14.8358),
        (736, -15.5952),
        (768, -16.353),
        (800, -17.1101),
        (832, -17.8663),
        (864, -18.622),
        (896, -19.3774),
        (928, -20.1325),
        (960, -20.888),
        (992, -21.6444),
        (1024, -22.4022),
        (1056, -23.1658),
        (1088, -23.93),
        (1120, -24.6936),
        (1152, -25.4554),
        (1184, -26.2092),
        (1216, -26.9608),
        (1248, -27.711),
        (1280, -28.4606),
        (1312, -29.2161),
        (1344, -29.9729),
        (1376, -30.731),
        (1408, -31.4901),
        (1440, -32.2501),
        (1472, -33.0109),
        (1504, -33.7722),
        (1536, -34.534),
        (1568, -35.2962),
        (1600, -36.0584),
        (1632, -36.8207),
        (1664, -37.5827),
        (1696, -38.3445),
        (1728, -39.1058),
        (1760, -39.8665),
        (1792, -40.6264),
        (2048, -46.7390),
    ]


def secure_parameter_tuples_logq_64_sec_160():
    return [
        (128, -2.46558),
        (160, -2.02222),
        (192, -2.01882),
        (224, -2.36376),
        (256, -2.9654),
        (288, -3.7321),
        (320, -4.57223),
        (352, -5.35806),
        (384, -6.10626),
        (416, -6.83878),
        (448, -7.55652),
        (480, -8.26747),
        (512, -8.9723),
        (544, -9.67345),
        (576, -10.3736),
        (608, -11.0777),
        (640, -11.7818),
        (672, -12.4807),
        (704, -13.1772),
        (736, -13.872),
        (768, -14.5659),
        (800, -15.2628),
        (832, -15.9589),
        (864, -16.6539),
        (896, -17.3471),
        (928, -18.0339),
        (960, -18.7196),
        (992, -19.4054),
        (1024, -20.0924),
        (1056, -20.7863),
        (1088, -21.482),
        (1120, -22.1788),
        (1152, -22.8761),
        (1184, -23.5722),
        (1216, -24.2681),
        (1248, -24.9635),
        (1280, -25.6584),
        (1312, -26.3508),
        (1344, -27.0422),
        (1376, -27.7328),
        (1408, -28.4227),
        (1440, -29.1121),
        (1472, -29.8012),
        (1504, -30.4901),
        (1536, -31.1789),
        (1568, -31.8678),
        (1600, -32.557),
        (1632, -33.2466),
        (1664, -33.9367),
        (1696, -34.6275),
        (1728, -35.3192),
        (1760, -36.012),
        (1792, -36.7058),
        (2048, -42.2710),
    ]


_SECURE_PARAMS = {
    64: secure_parameter_tuples_logq_64_sec_64(),
    80: secure_parameter_tuples_logq_64_sec_80(),
    96: secure_parameter_tuples_logq_64_sec_96(),
    112: secure_parameter_tuples_logq_64_sec_112(),
    128: secure_parameter_tuples_logq_64_sec_128(),
    144: secure_parameter_tuples_logq_64_sec_144(),
    160: secure_parameter_tuples_logq_64_sec_160(),
}


def secure_parameter_tuples(bits):
    """
    Generates tuples of LWE parameters, corresponding to key length and log of noise,
    which are known to be secure up to bits of security
    :return:
    """
    if bits not in _SECURE_PARAMS:
        raise ValueError(
            f"Number of bits of security ({bits}) is non-standard, "
            f"please choose between {list(_SECURE_PARAMS.keys())}"
        )
    else:
        return _SECURE_PARAMS[bits]


def check_parameter_choice_secure(parameters, min_bits):
    params_equal_or_better_than_bits = list(filter(lambda x: x >= min_bits, _SECURE_PARAMS.keys()))
    return any(map(lambda x: parameters in _SECURE_PARAMS[x], params_equal_or_better_than_bits))
