import networkx as nx


def human_readable_layout(graph: nx.DiGraph, x_delta=1.0, y_delta=1.0):
    """
    Prepare a dictionary formated for nx.draw so that nodes are ordered by depth from input along
    the x axis and have a uniform distribution along the y axis
    """

    nodes_depth = {node: 0 for node in graph.nodes()}
    input_nodes = [node for node in graph.nodes() if len(list(graph.predecessors(node))) == 0]

    # Init a layout so that unreachable nodes have a pos, avoids potential crashes wiht networkx
    # use a cheap layout
    pos = nx.random_layout(graph)

    curr_x = 0.0
    curr_y = -(len(input_nodes) - 1) / 2 * y_delta

    for in_node in input_nodes:
        pos[in_node] = (curr_x, curr_y)
        curr_y += y_delta

    curr_x += x_delta

    curr_nodes = input_nodes

    current_depth = 0
    while len(curr_nodes) > 0:
        current_depth += 1
        next_nodes_set = set()
        for node in curr_nodes:
            try:
                next_nodes_set.update(graph.successors(node))
            except nx.NetworkXError:
                pass

        curr_nodes = next_nodes_set
        for node in curr_nodes:
            nodes_depth[node] = current_depth

    nodes_by_depth = {}
    for node, depth in nodes_depth.items():
        nodes_for_depth = nodes_by_depth.get(depth, [])
        nodes_for_depth.append(node)
        nodes_by_depth[depth] = nodes_for_depth

    depths = sorted(nodes_by_depth.keys())

    for depth in depths:
        nodes_at_depth = nodes_by_depth[depth]

        curr_y = -(len(nodes_at_depth) - 1) / 2 * y_delta
        for node in nodes_at_depth:
            pos[node] = (curr_x, curr_y)
            curr_y += y_delta

        curr_x += x_delta

    return pos
