from typing import Optional, Union

import numpy as np
from zamavm import PyEncoder, PyExactEncodingParameters


class Encoder:
    def __init__(
        self,
        offset: float,
        delta: float,
        bits_precision: Optional[int],
        bits_padding: Optional[int],
    ):
        assert (bits_precision is None and bits_padding is None) or (
            bits_precision is not None and bits_padding is not None
        )
        self.offset = offset
        self.delta = delta
        self.bits_precision = bits_precision
        self.bits_padding = bits_padding
        if bits_precision is not None:
            self.exact_params = PyExactEncodingParameters(bits_precision, bits_padding)
        else:
            self.exact_params = None
        self.encoder = PyEncoder(offset, delta, self.exact_params)

    def encode(self, value: np.ndarray):
        """
        Encode a Numpy ndarray.
        """

        # TODO: reconsider this workaround, which was added for #457
        # (https://github.com/zama-ai/hnp/pull/457)

        if value.dtype != np.float64:
            value = value.astype(np.float64)

        return self.encoder.encode_tensor(value)

    def encode_single(self, value: Union[int, float]):
        """
        Encode a single value (int, float).
        """
        if isinstance(value, int):
            value = float(value)
        as_array = np.array([value]).astype(np.float64)
        return self.encode(as_array)[0]

    def decode(self, value: np.ndarray):
        """
        Decode a Numpy ndarray.
        """
        return self.encoder.decode_tensor(value)

    def decode_single(self, value: int):
        """
        Decode a single value (int).
        """
        as_array = np.array([value]).astype(np.uint64)
        return self.decode(as_array)[0]

    def copy_new_offset_delta(self, offset: float, delta: float):
        """
        Updates the current encoder object
        :param offset:
        :param delta:
        """
        return Encoder(
            offset,
            delta,
            self.bits_precision,
            self.bits_padding,
        )

    def clone(self):
        return Encoder(self.offset, self.delta, self.bits_precision, self.bits_padding)
