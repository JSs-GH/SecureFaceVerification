import math
from abc import ABC, abstractmethod, abstractstaticmethod
from typing import Union

import numpy as np
from loguru import logger

from .constants import NP_INT_TYPES
from .parameters import Encoder


class EncryptedType(ABC):
    def __init__(self):
        pass

    @abstractstaticmethod
    def bits_of_precision():
        """
        :return: Number of bits of precision needed for the type
        """
        pass

    @abstractmethod
    def is_approximate(self):
        """
        :return: True if the type is for approximate computation, False if exact computation
        """
        pass

    def is_exact(self):
        """
        :return: True if the type is for exact computation, False if approximate computation
        """
        return not self.is_approximate()

    @staticmethod
    def is_signed():
        """
        :return: True if the type is signed, False otherwise
        """

    @abstractmethod
    def generate_encoder(self, **kwargs):
        pass


class EncryptedFloat3(EncryptedType):
    def is_approximate(self):
        return True

    @staticmethod
    def bits_of_precision():
        return 3

    def generate_encoder(self, local_offset, local_delta, regional_delta):
        """Returns an appropriate encoder for the given paradigm"""
        margin = regional_delta / (2 ** self.bits_of_precision() - 1)
        return Encoder(local_offset, 2 * regional_delta + margin, None, None)


class EncryptedFloat4(EncryptedType):
    def is_approximate(self):
        return True

    @staticmethod
    def bits_of_precision():
        return 4

    def generate_encoder(self, local_offset, local_delta, regional_delta):
        """Returns an appropriate encoder for the given paradigm"""
        margin = regional_delta / (2 ** self.bits_of_precision() - 1)
        return Encoder(local_offset, 2 * regional_delta + margin, None, None)


class EncryptedFloat5(EncryptedType):
    def is_approximate(self):
        return True

    @staticmethod
    def bits_of_precision():
        return 5

    def generate_encoder(self, local_offset, local_delta, regional_delta):
        """Returns an appropriate encoder for the given paradigm"""
        margin = regional_delta / (2 ** self.bits_of_precision() - 1)
        return Encoder(local_offset, 2 * regional_delta + margin, None, None)


class EncryptedFloat8(EncryptedType):
    def is_approximate(self):
        return True

    @staticmethod
    def bits_of_precision():
        return 8

    def generate_encoder(self, local_offset, local_delta, regional_delta):
        """Returns an appropriate encoder for the given paradigm"""
        margin = regional_delta / (2 ** self.bits_of_precision() - 1)
        return Encoder(local_offset, 2 * regional_delta + margin, None, None)


class EncryptedInt2(EncryptedType):
    def is_approximate(self):
        return False

    @staticmethod
    def bits_of_precision():
        return 2

    def generate_encoder(self, *_):
        """Returns an appropriate encoder for the given paradigm"""
        local_offset = -float(2 ** (self.bits_of_precision() - 1))
        regional_delta = float(2 ** self.bits_of_precision())
        padding = 1
        return Encoder(local_offset, regional_delta, self.bits_of_precision(), padding)

    def min_value(self):
        return -(2 ** (self.bits_of_precision() - 1))

    def cast_cleartext_tensor(self, tensor):
        assert isinstance(tensor, np.ndarray)
        if not np.issubdtype(tensor.dtype, np.signedinteger):
            logger.warning(
                f"trying to cast a cleartext array to int2, but the array is not an unsigned integer: "
                f"possible loss of precision in the casting"
            )
        if tensor.min() < -(2 ** (self.bits_of_precision() - 1)) or tensor.max() >= (
            2 ** self.bits_of_precision() - 1
        ):
            logger.warning(
                f"cleartext tensor operating with encrypted int4 contains elements "
                f"that are bigger than the data type: int2 fits range ({-2**(self.bits_of_precision()-1)}, "
                f"{2**(self.bits_of_precision()-1)}), but array contains elements outside of that range, "
                f"which will be clipped "
            )
        return np.clip(
            tensor, -(2 ** (self.bits_of_precision() - 1)), 2 ** (self.bits_of_precision() - 1)
        ).astype(np.int8)

    @staticmethod
    def is_signed():
        return True

    def as_signed(self):
        return self

    def get_dtype_extra_bit(self):
        return _INT_BITS_MAPPING[self.bits_of_precision() + 1]()


class EncryptedInt3(EncryptedType):
    def is_approximate(self):
        return False

    @staticmethod
    def bits_of_precision():
        return 3

    def generate_encoder(self, *_):
        """Returns an appropriate encoder for the given paradigm"""
        local_offset = -float(2 ** (self.bits_of_precision() - 1))
        regional_delta = float(2 ** self.bits_of_precision())
        padding = 1
        return Encoder(local_offset, regional_delta, self.bits_of_precision(), padding)

    def min_value(self):
        return -(2 ** (self.bits_of_precision() - 1))

    def cast_cleartext_tensor(self, tensor):
        assert isinstance(tensor, np.ndarray)
        if not np.issubdtype(tensor.dtype, np.signedinteger):
            logger.warning(
                f"trying to cast a cleartext array to int4, but the array is not an unsigned integer: "
                f"possible loss of precision in the casting"
            )
        if tensor.min() < -(2 ** (self.bits_of_precision() - 1)) or tensor.max() >= (
            2 ** self.bits_of_precision() - 1
        ):
            logger.warning(
                f"cleartext tensor operating with encrypted int4 contains elements "
                f"that are bigger than the data type: int4 fits range ({-2**(self.bits_of_precision()-1)}, "
                f"{2**(self.bits_of_precision()-1)}), but array contains elements outside of that range, "
                f"which will be clipped "
            )
        return np.clip(
            tensor, -(2 ** (self.bits_of_precision() - 1)), 2 ** (self.bits_of_precision() - 1)
        ).astype(np.int8)

    @staticmethod
    def is_signed():
        return True

    def as_signed(self):
        return self

    def get_dtype_extra_bit(self):
        return _INT_BITS_MAPPING[self.bits_of_precision() + 1]()


class EncryptedInt4(EncryptedType):
    def is_approximate(self):
        return False

    @staticmethod
    def bits_of_precision():
        return 4

    def generate_encoder(self, *_):
        """Returns an appropriate encoder for the given paradigm"""
        local_offset = -float(2 ** (self.bits_of_precision() - 1))
        regional_delta = float(2 ** self.bits_of_precision())
        padding = 1
        return Encoder(local_offset, regional_delta, self.bits_of_precision(), padding)

    def min_value(self):
        return -(2 ** (self.bits_of_precision() - 1))

    def cast_cleartext_tensor(self, tensor):
        assert isinstance(tensor, np.ndarray)
        if not np.issubdtype(tensor.dtype, np.signedinteger):
            logger.warning(
                f"trying to cast a cleartext array to int4, but the array is not an unsigned integer: "
                f"possible loss of precision in the casting"
            )
        if tensor.min() < -(2 ** (self.bits_of_precision() - 1)) or tensor.max() >= (
            2 ** self.bits_of_precision() - 1
        ):
            logger.warning(
                f"cleartext tensor operating with encrypted int4 contains elements "
                f"that are bigger than the data type: int4 fits range ({-2**(self.bits_of_precision()-1)}, "
                f"{2**(self.bits_of_precision()-1)}), but array contains elements outside of that range, "
                f"which will be clipped "
            )
        return np.clip(
            tensor, -(2 ** (self.bits_of_precision() - 1)), 2 ** (self.bits_of_precision() - 1)
        ).astype(np.int8)

    @staticmethod
    def is_signed():
        return True

    def as_signed(self):
        return self

    def get_dtype_extra_bit(self):
        logger.warning(
            f"computation required more bits of precision than available -- result is not guaranteed to "
            f"be reliable; decrease precision of inputs"
        )
        return self


class EncryptedBool(EncryptedType):
    def is_approximate(self):
        return False

    @staticmethod
    def bits_of_precision():
        return 1

    @staticmethod
    def is_signed():
        return False

    def generate_encoder(self, *_):
        """Returns an appropriate encoder for the given paradigm"""
        local_offset = 0
        regional_delta = float(2 ** self.bits_of_precision())
        padding = 1
        return Encoder(
            local_offset,
            regional_delta,
            self.bits_of_precision(),
            padding,
        )

    def min_value(self):
        return 0

    def cast_cleartext_tensor(self, tensor):
        raise NotImplementedError(f"casting to bool not implemented")

    def as_signed(self):
        return EncryptedInt2()

    def get_dtype_extra_bit(self):
        return _UINT_BITS_MAPPING[self.bits_of_precision() + 1]()


class EncryptedUint2(EncryptedType):
    def is_approximate(self):
        return False

    @staticmethod
    def bits_of_precision():
        return 2

    @staticmethod
    def is_signed():
        return False

    def generate_encoder(self, *_):
        """Returns an appropriate encoder for the given paradigm"""
        local_offset = 0
        regional_delta = float(2 ** self.bits_of_precision())
        padding = 1
        return Encoder(
            local_offset,
            regional_delta,
            self.bits_of_precision(),
            padding,
        )

    def min_value(self):
        return 0

    def cast_cleartext_tensor(self, tensor):
        assert isinstance(tensor, np.ndarray)
        if not np.issubdtype(tensor.dtype, np.unsignedinteger):
            logger.warning(
                f"trying to cast a cleartext array to encrypted uint2, but the array is not an unsigned "
                f"integer: possible loss of precision in the casting"
            )
        if tensor.max() >= 2 ** self.bits_of_precision():
            logger.warning(
                f"cleartext tensor operating with uint4 contains elements "
                f"that are bigger than the data type: uint2 fits range (0, {2**self.bits_of_precision()}), "
                f"but array contains elements outside of that range, which will be clipped "
            )
        return np.clip(tensor, 0, 2 ** self.bits_of_precision()).astype(np.uint8)

    def as_signed(self):
        return EncryptedInt3()

    def get_dtype_extra_bit(self):
        return _UINT_BITS_MAPPING[self.bits_of_precision() + 1]()


class EncryptedUint3(EncryptedType):
    def is_approximate(self):
        return False

    @staticmethod
    def bits_of_precision():
        return 3

    @staticmethod
    def is_signed():
        return False

    def generate_encoder(self, *_):
        """Returns an appropriate encoder for the given paradigm"""
        local_offset = 0
        regional_delta = float(2 ** self.bits_of_precision())
        padding = 1
        return Encoder(
            local_offset,
            regional_delta,
            self.bits_of_precision(),
            padding,
        )

    def min_value(self):
        return 0

    def cast_cleartext_tensor(self, tensor):
        assert isinstance(tensor, np.ndarray)
        if not np.issubdtype(tensor.dtype, np.unsignedinteger):
            logger.warning(
                f"trying to cast a cleartext array to encrypted uint4, but the array is not an unsigned "
                f"integer: possible loss of precision in the casting"
            )
        if tensor.max() >= 2 ** self.bits_of_precision():
            logger.warning(
                f"cleartext tensor operating with uint4 contains elements "
                f"that are bigger than the data type: uint4 fits range (0, {2**self.bits_of_precision()}), "
                f"but array contains elements outside of that range, which will be clipped "
            )
        return np.clip(tensor, 0, 2 ** self.bits_of_precision()).astype(np.uint8)

    def as_signed(self):
        return EncryptedInt4()

    def get_dtype_extra_bit(self):
        return _UINT_BITS_MAPPING[self.bits_of_precision() + 1]()


class EncryptedUint4(EncryptedType):
    def is_approximate(self):
        return False

    @staticmethod
    def bits_of_precision():
        return 4

    @staticmethod
    def is_signed():
        return False

    def generate_encoder(self, *_):
        """Returns an appropriate encoder for the given paradigm"""
        local_offset = 0
        regional_delta = float(2 ** self.bits_of_precision())
        padding = 1
        return Encoder(
            local_offset,
            regional_delta,
            self.bits_of_precision(),
            padding,
        )

    def min_value(self):
        return 0

    def cast_cleartext_tensor(self, tensor):
        assert isinstance(tensor, np.ndarray)
        if not np.issubdtype(tensor.dtype, np.unsignedinteger):
            logger.warning(
                f"trying to cast a cleartext array to encrypted uint4, but the array is not an unsigned "
                f"integer: possible loss of precision in the casting"
            )
        if tensor.max() >= 2 ** self.bits_of_precision():
            logger.warning(
                f"cleartext tensor operating with uint4 contains elements "
                f"that are bigger than the data type: uint4 fits range (0, {2**self.bits_of_precision()}), "
                f"but array contains elements outside of that range, which will be clipped "
            )
        return np.clip(tensor, 0, 2 ** self.bits_of_precision()).astype(np.uint8)

    def as_signed(self):
        raise TypeError(
            f"operations require exact data type with more precision than currently available"
        )

    def get_dtype_extra_bit(self):
        logger.warning(
            f"computation required more bits of precision than available -- result is not guaranteed to "
            f"be reliable; decrease precision of inputs"
        )
        return self


_NAME_TYPE_MAPPING = {
    "uint2": EncryptedUint2,
    "uint3": EncryptedUint3,
    "uint4": EncryptedUint4,
    "int2": EncryptedInt2,
    "int3": EncryptedInt3,
    "int4": EncryptedInt4,
    "bool": EncryptedBool,
    "float3": EncryptedFloat3,
    "float4": EncryptedFloat4,
    "float5": EncryptedFloat5,
    "float8": EncryptedFloat8,
}

_INT_BITS_MAPPING = {
    1: EncryptedInt2,
    2: EncryptedInt2,
    3: EncryptedInt3,
    4: EncryptedInt4,
}

_UINT_BITS_MAPPING = {
    1: EncryptedBool,
    2: EncryptedUint2,
    3: EncryptedUint3,
    4: EncryptedUint4,
}


def mix_dtypes(dtype1: EncryptedType, dtype2: EncryptedType):
    """Returns a dtype that is appropriate to fit both dtype1 and dtype2, if such dtype exists"""
    if dtype1 is None and dtype2 is not None:
        return dtype2
    if dtype2 is None and dtype1 is not None:
        return dtype1
    if dtype1.is_exact() and dtype2.is_exact():
        max_bits = max(dtype1.bits_of_precision(), dtype2.bits_of_precision())
        if dtype1.is_signed() and dtype2.is_signed():
            return _INT_BITS_MAPPING[max_bits]()
        if not dtype1.is_signed() and not dtype2.is_signed():
            return _UINT_BITS_MAPPING[max_bits]()
        if dtype1.is_signed() and not dtype2.is_signed():
            if dtype2.bits_of_precision() >= dtype1.bits_of_precision():
                new_bits = dtype2.bits_of_precision() + 1
                return _INT_BITS_MAPPING[new_bits]()
            else:
                return _INT_BITS_MAPPING[dtype1.bits_of_precision()]()
        if dtype2.is_signed() and not dtype1.is_signed():
            if dtype2.bits_of_precision() >= dtype1.is_signed():
                new_bits = dtype2.bits_of_precision()
                return _INT_BITS_MAPPING[new_bits]()
    elif dtype1.is_approximate() and dtype2.is_approximate():
        # mixed precision not implemented yet
        assert dtype1.bits_of_precision() == dtype2.bits_of_precision()
        return dtype1
    else:
        raise TypeError(f"computation mixing approximate and exact types is not supported")


def etype(type_name):
    if type_name not in _NAME_TYPE_MAPPING:
        raise ValueError(f"type '{type_name}' doesn't exist")
    return _NAME_TYPE_MAPPING[type_name]()


def find_exact_clear_dtype(x: Union[int, np.ndarray], op: str):
    if isinstance(x, np.ndarray):
        min_bits = int(math.ceil(math.log2(abs(x.min()))))
        max_bits = int(math.ceil(math.log2(abs(x.max()))))
        max_bits = max(max_bits, min_bits)
        max_bits = max(max_bits, 1)
        if np.all(x > 0):
            mapping = _UINT_BITS_MAPPING
        else:
            mapping = _INT_BITS_MAPPING
        if max_bits not in mapping.keys():
            raise TypeError(
                f"cleartext array being used in operation {op} contains values that cannot be "
                f"cast into an exact type (maximum value of array requires {max_bits}, "
                f"but integer types are restricted to at most {max(mapping)} bits"
            )
        else:
            return mapping[max_bits]()
    elif isinstance(x, (NP_INT_TYPES, int)):
        if x > 0:
            mapping = _UINT_BITS_MAPPING
        else:
            mapping = _INT_BITS_MAPPING
        bits = int(math.ceil(math.log2(x)))
        if bits not in mapping.keys():
            raise TypeError(
                f"cleartext scalar being used in operation {op} has value that cannot be "
                f"cast into an exact type (its value requires {bits}, but integer "
                f"types are restricted to at most {max(mapping)} bits"
            )
        else:
            return mapping[bits]()
