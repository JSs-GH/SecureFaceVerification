import numpy as np

from ..arrays import EncryptedArray
from ..encrypted_types import EncryptedBool
from ..numpy_api.encrypted_ndarray import EncryptedNDArray
from ..representation.intermediate import EncArray_InitConstArray


def set_item(arr, obj, value):
    if isinstance(arr, EncryptedArray) and isinstance(value, EncryptedArray):
        return EncryptedNDArray._wrap_or_return(arr._inner_setitem(obj, value))
    elif isinstance(arr, np.ndarray) and isinstance(value, EncryptedArray):
        new_arr = EncryptedArray(
            shape=arr.shape,
            computation=EncArray_InitConstArray(arr, value.dtype),
            predecessors=[],
        )
        return EncryptedNDArray._wrap_or_return(new_arr._inner_setitem(obj, value))
    elif isinstance(arr, EncryptedArray) and isinstance(value, np.ndarray):
        new_value = EncryptedArray(
            shape=value.shape,
            computation=EncArray_InitConstArray(value, arr.dtype),
            predecessors=[],
        )
        return EncryptedNDArray._wrap_or_return(arr._inner_setitem(obj, new_value))
    elif isinstance(arr, EncryptedArray) and isinstance(value, (int, float)):
        new_value = EncryptedArray(
            shape=(1,),
            computation=EncArray_InitConstArray(np.array([value]).astype(np.float64), arr.dtype),
            predecessors=[],
        )
        return EncryptedNDArray._wrap_or_return(arr._inner_setitem(obj, new_value))
    elif isinstance(arr, np.ndarray) and not isinstance(value, EncryptedArray):
        tmp = np.copy(arr)
        tmp[obj] = value
        return tmp
    else:
        raise TypeError(f"set_item must receive")


def im2col(kernel_shape, strides, x):
    """
    Apply img2col algorithm to perform convolution as a single matmul.

    :param kernel_shape: tuple or list of the 4 dimension of the kernel
        (out_channels, in_channels, height, width)
    :param stride: tuple of the strides on both axis (rows, columns)
    :param x: 3D array to transform
    :return: transformed array (2D) and the number of windows (rows, cols)
    """
    x_channel, x_row, x_col = x.shape
    _, in_channels, k_row, k_col = kernel_shape
    stride_row, stride_col = strides
    # build indexes to extract windows using fancy indexing
    # this optimize the number of nodes to be executed
    row_range = []
    col_range = []
    steps_row = (x_row - k_row) // stride_row + 1
    steps_col = (x_col - k_col) // stride_col + 1

    # row index
    for row in range(steps_row):
        # one window
        idx = np.arange(row * stride_row, row * stride_row + k_row).repeat(k_col)
        # repeat for channels
        idx = np.tile(idx, in_channels)
        # repeat for columns
        idx = np.tile(idx, steps_col)
        row_range.extend(idx)

    # col index
    for col in range(steps_col):
        # one window
        idx = np.tile(np.arange(col * stride_col, col * stride_col + k_col), k_row)
        # repeat for channels
        idx = np.tile(idx, in_channels)
        col_range.extend(idx)
    # repeat for rows
    col_range = np.tile(col_range, steps_row)

    # channel index
    idx = np.arange(x_channel)
    # repeat a single channel for an entire window
    idx = np.repeat(idx, k_row * k_col)
    # repeat for every single window
    channel_range = np.tile(idx, steps_row * steps_col)

    windows = x[channel_range, row_range, col_range].reshape((-1, k_row * k_col * in_channels))
    return windows, (steps_row, steps_col)


def conv2d(x, kernel, bias, stride=1, padding=0, padding_value=0):
    """
    Apply convolution to a 3D array (in_channels, height, width)

    :param x: 2D or 3D input to the convolution
    :param kernel: 4D array kernel (out_channels, in_channels, height, width)
    :param bias: 1D array of size out_channels
    :param stride: int or a a pair of int (stride_rows, stride_col). Default: 1
    :param padding: int or a a pair of int (padding_heigh, padding_width). Default: 0
    :param padding_value: the value to pad with. Default: 0
    :return: 3D output of the convolution (out_channels, height, width)
    """
    if isinstance(stride, int):
        stride = (stride, stride)
    if isinstance(padding, int):
        padding = (padding, padding)
    if len(kernel.shape) != 4:
        raise ValueError("kernel must have 4 dimensions (out_channels, in_channels, height, width)")
    (
        out_channels,
        in_channels,
        *_,
    ) = kernel.shape
    if len(bias.shape) != 1:
        raise ValueError("bias must be a vector")
    if out_channels != bias.shape[0]:
        raise ValueError(
            f"kernel and bias first dim don't match ({out_channels} and {bias.shape[0]}"
        )

    if len(x.shape) == 2 and in_channels == 1:
        x = x.reshape((1, *x.shape))
    if len(x.shape) != 3:
        raise ValueError(
            f"input x must be either 2D (if in_channels is 1) or 3D, not {len(x.shape)}D"
        )

    if padding != (0, 0):
        pad_width = (
            (0, 0),  # don't pad channel dim
            (padding[0], padding[0]),  # pad height
            (padding[1], padding[1]),  # pad width
        )
        constant_values = (
            (padding_value, padding_value),
            (padding_value, padding_value),
            (padding_value, padding_value),
        )
        x = np.pad(x, pad_width, mode="constant", constant_values=constant_values)

    x, out_shape = im2col(kernel.shape, stride, x)
    k = kernel.reshape((out_channels, -1)).T
    x = np.dot(x, k) + bias.reshape((1, -1))
    return x.T.reshape((out_channels, *out_shape))
