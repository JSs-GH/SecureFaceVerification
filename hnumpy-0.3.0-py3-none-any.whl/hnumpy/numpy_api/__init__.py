"""
This package provide an additional layer to hnumpy.arrays.encrypted_array
in order to be executed by numpy functions.
"""

import numpy as np

from .. import api

_UFUNC_ROUTING = None

_FUNC_ROUTING = None

# When one adds a new function, to know if it goes to _init_hnp_func or
# _init_hnp_ufunc (or both), just print the function
# Eg,
#   print(np.mean)
#       <function mean at 0x10ea3eee0>
#   print(np.add)
#       <ufunc 'add'>


def _init_hnp_func():
    global _FUNC_ROUTING
    _FUNC_ROUTING = {
        np.all: api._all,
        np.allclose: api.allclose,
        np.any: api._any,
        np.isclose: api.isclose,
        np.dot: api.dot,
        np.reshape: api.reshape,
        np.split: api.split,
        np.vsplit: api.vsplit,
        np.hsplit: api.hsplit,
        np.dsplit: api.dsplit,
        np.swapaxes: api.swapaxes,
        np.expand_dims: api.expand_dims,
        np.squeeze: api.squeeze,
        np.atleast_1d: api.atleast_1d,
        np.atleast_2d: api.atleast_2d,
        np.atleast_3d: api.atleast_3d,
        np.transpose: api.transpose,
        np.concatenate: api.concatenate,
        np.row_stack: api.row_stack,
        np.i0: api.i0,
        np.stack: api.stack,
        np.column_stack: api.column_stack,
        np.vstack: api.vstack,
        np.hstack: api.hstack,
        np.dstack: api.dstack,
        np.broadcast_to: api.broadcast_to,
        np.resize: api.resize,
        np.maximum: api.maximum,
        np.pad: api.pad,
        np.sum: api._sum,
        np.mean: api.mean,
        np.cross: api.cross,
        np.moveaxis: api.moveaxis,
        np.rollaxis: api.rollaxis,
        np.clip: api.clip,
        np.round: api.round,
        np.interp: api.interp,
        np.abs: api.absolute,
        np.fabs: api.fabs,
        np.cbrt: api.cbrt,
        np.fix: api.fix,
        np.where: api.where,
    }


def _init_hnp_ufunc():
    global _UFUNC_ROUTING
    _UFUNC_ROUTING = {
        np.add: api.add,
        np.subtract: api.subtract,
        np.multiply: api.multiply,
        np.matmul: api.matmul,
        np.cbrt: api.cbrt,
        np.i0: api.i0,
        np.interp: api.interp,
        np.divide: api.divide,
        np.floor_divide: None,
        np.true_divide: api.divide,
        np.logaddexp: api.logaddexp,
        np.logaddexp2: api.logaddexp2,
        np.positive: None,
        np.negative: api.negative,
        np.concatenate: api.concatenate,
        np.power: None,
        np.remainder: None,
        np.mod: None,
        np.round: api.round,
        np.moveaxis: api.moveaxis,
        np.rollaxis: api.rollaxis,
        np.divmod: None,
        np.absolute: None,
        np.fabs: api.fabs,
        np.rint: None,
        np.heaviside: None,
        np.conj: None,
        np.conjugate: None,
        np.exp: api.exp,
        np.exp2: None,
        np.log: api.log,
        np.log2: api.log2,
        np.log10: api.log10,
        np.expm1: api.expm1,
        np.log1p: api.log1p,
        np.sqrt: api.sqrt,
        np.square: api.square,
        np.reciprocal: api.reciprocal,
        np.gcd: None,
        np.lcm: None,
        np.sin: api.sin,
        np.cos: api.cos,
        np.tan: api.tan,
        np.arcsin: api.arcsin,
        np.arccos: api.arccos,
        np.arctan: api.arctan,
        np.arctan2: api.arctan2,
        np.clip: api.clip,
        np.hypot: api.hypot,
        np.sinh: api.sinh,
        np.cosh: api.cosh,
        np.tanh: api.tanh,
        np.arcsinh: api.arcsinh,
        np.arccosh: api.arccosh,
        np.arctanh: api.arctanh,
        np.degrees: api.degrees,
        np.radians: api.radians,
        np.deg2rad: api.deg2rad,
        np.rad2deg: api.rad2deg,
        np.bitwise_or: api.bitwise_or,
        np.bitwise_xor: api.bitwise_xor,
        np.invert: None,
        np.left_shift: None,
        np.right_shift: None,
        np.greater: api.greater,
        np.greater_equal: api.greater_equal,
        np.less: api.less,
        np.less_equal: api.less_equal,
        np.not_equal: api.not_equal,
        np.equal: api.equal,
        np.logical_and: api.logical_and,
        np.logical_or: api.logical_or,
        np.pad: api.pad,
        np.logical_xor: api.logical_xor,
        np.logical_not: api.logical_not,
        np.maximum: api.maximum,
        np.minimum: api.minimum,
        np.fmax: None,
        np.fmin: None,
        np.isfinite: None,
        np.isinf: None,
        np.isnan: None,
        np.isnat: None,
        np.abs: api.absolute,
        np.signbit: None,
        np.sign: api.sign,
        np.copysign: None,
        np.nextafter: None,
        np.spacing: None,
        np.modf: None,
        np.ldexp: None,
        np.frexp: None,
        np.fmod: None,
        np.floor: api.floor,
        np.ceil: api.ceil,
        np.trunc: api.trunc,
        np.sum: api._sum,
        np.mean: api.mean,
        np.bitwise_and: api.bitwise_and,
    }


def get_hnp_ufunc(ufunc):
    if _UFUNC_ROUTING is None:
        _init_hnp_ufunc()
    return _UFUNC_ROUTING.get(ufunc, None)


def get_hnp_func(func):
    if _FUNC_ROUTING is None:
        _init_hnp_func()
    return _FUNC_ROUTING.get(func, None)


__all__ = [
    "encrypted_ndarray",
]
