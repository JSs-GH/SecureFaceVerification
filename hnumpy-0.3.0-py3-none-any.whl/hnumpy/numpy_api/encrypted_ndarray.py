"""
EncryptedNDArray extend EncryptedArray to be able to be executed by numpy functions.
It routes supported numpy functions into their hnumpy equivalent.
"""

from typing import Tuple, Union

from ..arrays import EncryptedArray
from . import get_hnp_func, get_hnp_ufunc


class EncryptedNDArray(EncryptedArray):
    # All methods should be returning an EncryptedNDArray to still be able to use the numpy API
    # That's why we change EncryptedArray Instances in the return by
    # EncryptedNDArray instances

    def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
        """
        Catch calls to numpy ufunc and routes them to hnp functions if supported
        read more: https://numpy.org/doc/stable/user/basics.dispatch.html#basics-dispatch
        """
        if method == "__call__":
            hnp_ufunc = get_hnp_ufunc(ufunc)
            if hnp_ufunc is None:
                raise NotImplementedError(f"not implemented {ufunc}")
            return EncryptedNDArray._wrap_or_return(hnp_ufunc(*inputs, **kwargs))
        raise NotImplementedError

    def __array_function__(self, func, types, args, kwargs):
        """
        Catch calls to numpy function in routes them to hnp functions if supported
        read more: https://numpy.org/doc/stable/user/basics.dispatch.html#basics-dispatch
        """
        hnp_func = get_hnp_func(func)
        if hnp_func is None:
            raise NotImplementedError(f"not implemented {func}")
        return EncryptedNDArray._wrap_or_return(hnp_func(*args, **kwargs))

    @staticmethod
    def _wrap_or_return(ret_value):
        if isinstance(ret_value, EncryptedArray):
            enc_ndarray = EncryptedNDArray(
                ret_value._bounds,
                ret_value._shape,
                ret_value._predecessors,
                ret_value._computation,
                ret_value._dtype,
                ret_value._etype,
            )
            return enc_ndarray
        return ret_value


def encrypted_ndarray(
    bounds: Tuple[float, float], shape: Union[int, Tuple[int, ...]], *args, **kwargs
):
    """Constructor for the EncryptedNDArray objects"""
    if isinstance(shape, int):
        # accept int for 1-D array
        shape = (shape,)
    if not isinstance(bounds, tuple):
        raise ValueError(
            f"Bounds needs to be a tuple from `min` to `max`. Instead, provided {bounds}"
        )
    if not isinstance(shape, tuple):
        raise ValueError(f"Shape needs to be a tuple of dimensions. Instead, provided {shape}")
    bounds = tuple(map(lambda x: float(x), bounds))
    return EncryptedNDArray(bounds, shape, *args, **kwargs)
