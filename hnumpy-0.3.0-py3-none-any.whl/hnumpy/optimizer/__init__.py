from ..representation import get_ordered_outputs
from ..representation.intermediate import ClearArray_Input, EncArray_Input


def remove_dead_nodes(graph):
    """
    Remove nodes that doesn't lead to one of the output

    :param graph: graph representing the computation
    """
    outputs = get_ordered_outputs(graph)
    visited = set()
    to_visit = set(outputs)
    while len(to_visit):
        v = to_visit.pop()
        visited.add(v)
        for p in graph.predecessors(v):
            if p not in visited and p not in to_visit:
                to_visit.add(p)

    to_remove = [node for node in graph.nodes() if node not in visited]
    for r in to_remove:
        graph.remove_node(r)
