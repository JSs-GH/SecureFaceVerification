from typing import List

import networkx as nx
import sympy

from ..encrypted_types import mix_dtypes
from ..parameters import Bounds


def find_regional_encodings(
    graph: nx.DiGraph,
    subgraphs: List[nx.DiGraph],
):
    """
    Finds the bounds for each subgraph, and updates the input and output encoder of each node accordingly
    :param graph: original full graph
    :param subgraphs: independent subgraphs from graph
    """
    approximate_paradigm = False
    for sg in subgraphs:
        regional_bounds = Bounds()
        padding = 1
        regional_dtype = None
        for node in sg.nodes():
            # the local output lower/upper bound has been assessed already elsewhere in the code (using
            # worst-case or dataset), so we just need to calculate the regional lower/upper bounds
            regional_bounds.update_lower_bound(node.output_lower_bound)
            regional_bounds.update_upper_bound(node.output_upper_bound)
            regional_dtype = mix_dtypes(regional_dtype, node.dtype)
            # highest_precision = max(highest_precision, node.dtype.bits_of_precision())
            # assert highest_precision > 0
            # approximate_paradigm = node.dtype.is_approximate() or approximate_paradigm
        assert regional_dtype is not None
        # let's find regional torus shift
        regional_delta = regional_bounds.upper_bound - regional_bounds.lower_bound
        for node in sg.nodes():
            local_offset = node.output_lower_bound
            local_delta = node.output_upper_bound - node.output_lower_bound
            node.dtype = regional_dtype
            node.output_encoding = regional_dtype.generate_encoder(
                local_offset, local_delta, regional_delta
            )

    # must do this second part separately to make sure predecessor encoding has been set
    for sg in subgraphs:
        for node in sg.nodes():
            predecessors = [p for p in graph.predecessors(node)]
            weights = [graph.get_edge_data(p, node)["weight"] for p in predecessors]
            sorted_predecessors = [predecessors[i] for i in weights]
            if len(predecessors) == 0:
                # it means, it's some sort of input that can choose its own encoding input as well
                node.input_encodings = [node.output_encoding.clone()]
            else:
                node.input_encodings = [p.output_encoding for p in sorted_predecessors]


def update_input_encodings(graph: nx.DiGraph):

    for node in nx.topological_sort(graph):
        predecessors = [p for p in graph.predecessors(node)]
        weights = [graph.get_edge_data(p, node)["weight"] for p in predecessors]
        sorted_predecessors = [predecessors[i] for i in weights]
        encodings = [p.output_encoding for p in sorted_predecessors]
        node.input_encodings = encodings


def optimize_with_simplification(graph: nx.DiGraph):
    symbolic_context = {"bounds": dict(), "temporaries": 0}
    for node in nx.topological_sort(graph):
        predecessors = [p for p in graph.predecessors(node)]
        weights = [graph.get_edge_data(p, node)["weight"] for p in predecessors]

        sorted_predecessors = [predecessors[i] for i in weights]
        node.update_formula(sorted_predecessors, symbolic_context)

        [optimized_lower_bound, optimized_upper_bound] = calculate_bounds(
            node.formula, symbolic_context["bounds"]
        )

        node.output_lower_bound = optimized_lower_bound
        node.output_upper_bound = optimized_upper_bound

    update_input_encodings(graph)


def calculate_bounds(formula, bounds):
    if formula.is_number:
        value = float(formula)
        return [value, value]

    if isinstance(formula, sympy.Abs):
        operand = formula.args[0]

        [lower, upper] = calculate_bounds(operand, bounds)

        if lower >= 0:
            return [lower, upper]
        else:
            return [0, max(abs(lower), abs(upper))]

    elif isinstance(formula, sympy.Add):
        lhs = formula.args[0]
        rhs = formula.args[1]

        [left_lower, left_upper] = calculate_bounds(lhs, bounds)
        [right_lower, right_upper] = calculate_bounds(rhs, bounds)

        return [left_lower + right_lower, left_upper + right_upper]

    elif isinstance(formula, sympy.Mul):
        lhs = formula.args[0]
        rhs = formula.args[1]

        [left_lower, left_upper] = calculate_bounds(lhs, bounds)
        [right_lower, right_upper] = calculate_bounds(rhs, bounds)

        combinations = [
            left_lower * right_lower,
            left_lower * right_upper,
            left_upper * right_lower,
            left_upper * right_upper,
        ]
        return [min(*combinations), max(*combinations)]

    elif isinstance(formula, sympy.Pow):
        lhs = formula.args[0]
        rhs = formula.args[1]

        [left_lower, left_upper] = calculate_bounds(lhs, bounds)
        [right_lower, right_upper] = calculate_bounds(rhs, bounds)

        combinations = [
            left_lower ** right_lower,
            left_lower ** right_upper,
            left_upper ** right_lower,
            left_upper ** right_upper,
        ]
        return [min(*combinations), max(*combinations)]

    elif isinstance(formula, sympy.Symbol):
        return bounds[formula]

    else:
        raise NotImplementedError
