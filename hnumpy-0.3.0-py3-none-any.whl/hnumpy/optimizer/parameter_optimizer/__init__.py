from inspect import isclass
from typing import Any, Callable, Dict, Optional, Set, Union

import networkx as nx

from ..._exceptions import CompilationError
from ...config import CompilationArtifacts
from ...crypto import Scheme
from ...representation.target import Target_EncArray_Pbs, TargetNode
from ...representation.topology import (
    add_between_nodes,
    replace_node_with_subgraph,
    theres_predecessor_cond,
)
from .ab_pruning import AlphaBetaPruning
from .base import ParamOptimizer
from .genetic import Genetic
from .genetic_experimental import GeneticExperimental
from .handselected import HandSelectedOptimizer
from .heuristic import HeuristicOptimizer
from .mcts import MonteCarloTreeSearch


def _recurse_successors_equal(graph: nx.DiGraph, node_1: TargetNode, node_2, stop_cond: Callable):
    """Recursively go through node_1 successors, stopping when
    stop_cond returns True for it, until either a path between
    them (without stop_cond in the middle) is found), which then
    return True, or returns False if no such path is found"""
    if node_1 == node_2:
        return True
    if stop_cond(node_1):
        return False
    for s in graph.successors(node_1):
        if _recurse_successors_equal(graph, s, node_2, stop_cond):
            return True
    return False


def is_successor_wo_noise_refresh(
    graph: nx.DiGraph, node: TargetNode, unsolved_nodes: Set[TargetNode]
):
    """Returns true iff this node is a successor of another node in the nodes_wo_solution set,
    and there's no node in between them that refreshes noise"""
    for unsolved in unsolved_nodes:
        if node == unsolved:
            continue
        if _recurse_successors_equal(graph, unsolved, node, lambda x: x.refreshes_noise()):
            return False
    return True


def find_earliest_noisy(graph: nx.DiGraph, unsolved_nodes: Set[TargetNode]) -> Set[TargetNode]:
    """Finds the nodes that cause noise to grow too much, excluding successors of those nodes without
    node that reduces noise between them"""
    earliest_noisy = set()
    for node in unsolved_nodes:
        if is_successor_wo_noise_refresh(graph, node, unsolved_nodes):
            earliest_noisy.add(node)
    return earliest_noisy


def try_add_pbs(graph: nx.DiGraph, noisy_nodes: Set[TargetNode]) -> bool:
    """
    Tries to add PBS nodes to the graph, to make the noise level acceptable
    """
    # first we need to find the node that actually causes the noise growth, for example, if we have
    # a -> b -> c -> d -> ...
    # if node b causes the noise to grow too much, then c and d will also have too much noise,
    # but we don't need necessarily more PBS nodes before c and d, so we have to find to earliest predecessor
    # that crosses noise tolerance
    added_pbs = False

    for node in noisy_nodes:
        # create list just to avoid using the iterator while graph is mutating
        predecessors = list(graph.predecessors(node))
        for p in predecessors:
            # todo(Joao): assumed to be ok to mutate graph while iterating through it,
            # because we don't delete nodes, and just add new nodes that don't affect other predecessors
            assert isinstance(p, TargetNode)
            if not isinstance(p, Target_EncArray_Pbs) and (
                p.increases_noise()
                or theres_predecessor_cond(graph, p, lambda x: x.increases_noise())
            ):
                new_pbs = Target_EncArray_Pbs(
                    lambda x: x,
                    [],
                    [p.output_shape],
                    p.output_shape,
                    node.ir_source,
                    node.dtype,
                )
                add_between_nodes(graph, p, node, new_pbs)
                added_pbs = True

    return added_pbs


def try_split_noisy_nodes(graph: nx.DiGraph, noisy_nodes: Set[TargetNode]) -> bool:
    """
    Tries to split nodes that have too high var_out, such that noise is refresh "during" the node's computations
    :param graph: graph to try to split noisy nodes
    :param noisy_nodes: set of noisy nodes
    """
    node_was_split = False

    for node in noisy_nodes:
        assert isinstance(node, TargetNode)
        sg: Union[nx.DiGraph, None] = node.split_node()
        if sg is not None:
            rhs = list(filter(lambda x: len(list(sg.successors(x))) == 1, sg.nodes()))
            assert len(rhs) == 1
            last = rhs[0]
            try_add_pbs(sg, {last})
            replace_node_with_subgraph(graph, node, sg)
            node_was_split = True

    return node_was_split


_OPTIMIZERS = {
    "ab_pruning": AlphaBetaPruning,
    "mcts": MonteCarloTreeSearch,
    "genetic": Genetic,
    "genetic_experimental": GeneticExperimental,
    "handselected": HandSelectedOptimizer,
    "heuristic": HeuristicOptimizer,
}


def find_good_parameters(
    graph: nx.DiGraph,
    scheme: Scheme,
    bits_of_security: int,
    artifacts: CompilationArtifacts,
    optimizer: Union[str, type] = "genetic",
    optimizer_options: Optional[Dict[str, Any]] = None,
):
    """Find good parameters based on a specific optimizer. Default is GeneticOptimizer.
    :param graph: the computation graph to optimize for
    :param scheme: encryption scheme to be used during the computation
    :param optimizer: either the name or the class of the optimizer to be used
    :param kwargs: additional keyword arguments to be forwarded to the optimizer
    :return: crypto parameters to be used.
    """
    if isinstance(optimizer, str):
        # optimizer is a name of an optimizer, so find it and instantiate
        optimizer = optimizer.lower()
        if optimizer not in _OPTIMIZERS:
            raise ValueError(f"optimizer {optimizer} doesn't exist")
        else:
            optimizer_type = _OPTIMIZERS[optimizer]
    elif isclass(optimizer) and issubclass(optimizer, ParamOptimizer):
        # optimizer is a subclass of ParamOptimizer, so instanciate it
        optimizer_type = optimizer
    else:
        raise TypeError(
            "optimizer can only be a string (name of an optimizer) or a class "
            f"inhereting ParamOptimzer, passed {optimizer} instead"
        )

    # we'll try to run the optimization until an appropriate solution is found
    # first, we use the given optimizer to find parameters for the given graph
    # if no good parameters are found, it means that the optimizer can't solve the given graph,
    # it will return None to chosen_parameters, and we can use other strategies to fix the graph,
    # notably:
    #   1) add pbs nodes before nodes that have too high var_out; the optimizer must implement a method
    #      get_unsolved_nodes() which returns these nodes, such that we can try this strategy
    #   2) if an operation has very high var_out but already has a pbs node before it, then we must split
    #      that operation into smaller ones and add PBSes before their union. This means that target nodes
    #      have to implement some `split_operation()`.
    run_optimization = True
    good_solution = False

    while run_optimization:
        optimizer = optimizer_type(graph, scheme, bits_of_security)

        chosen_parameters = optimizer.optimize(optimizer_options)

        if chosen_parameters is None:
            # no acceptable solution was found, use alternatives above
            noisy_nodes = find_earliest_noisy(graph, optimizer.get_unsolved_nodes())

            if try_add_pbs(graph, noisy_nodes):
                # there were still pbses to add, so
                # we can try to optimize again
                continue

            if try_split_noisy_nodes(graph, noisy_nodes):
                # it was possible to split some nodes, so we can try again
                continue

            # it wasn't possible to add PBS nodes or split noisy nodes, so there's nothing else to do except fail
            good_solution = False
            run_optimization = False
        else:
            optimizer.postprocess_parameters(chosen_parameters)
            artifacts.cryptographic_parameters = chosen_parameters
            good_solution = True
            run_optimization = False

    if not good_solution:
        raise CompilationError(
            "parameter optimizer couldn't find an appropriate solution to the graph "
            "(the operations in the graph generate too much noise, and no applicable noise \n"
            "\treduction strategy was able to control it to an acceptable level). Check the "
            "troubleshooting section of the documentation for tips on what could be done to solve it: \n"
            "\thttps://app.gitbook.com/@zama/s/hnp/"
        )
