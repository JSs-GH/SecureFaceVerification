import networkx as nx

from .base import ParamOptimizer


class AlphaBetaPruning(ParamOptimizer):
    def __init__(self, graph, scheme, bounds):
        ParamOptimizer.__init__(self, graph, scheme, bounds)
        self.tree = nx.DiGraph()

    def get_unsolved_nodes(self):
        ...

    def optimize(self):
        ...
