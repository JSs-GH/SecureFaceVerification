import random
import uuid
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

import networkx as nx

from ...crypto import EncryptionKey, Scheme
from ...representation.target import Target_EncArray_Keyswitch, Target_EncArray_Pbs
from ...representation.topology import divide_into_subgraphs


def merge_encryption_keys(chosen_parameters: Dict[str, Any]):
    equivalent_encryption_keys = {}

    for uid, param in chosen_parameters.items():
        if isinstance(param, EncryptionKey):
            list_of_equivalent_encryption_keys = equivalent_encryption_keys.get(param, [])
            list_of_equivalent_encryption_keys.append(uid)
            equivalent_encryption_keys[param] = list_of_equivalent_encryption_keys

    to_merge = [
        tuple(list_of_equivalent_encryption_keys)
        for list_of_equivalent_encryption_keys in equivalent_encryption_keys.values()
    ]

    for merge in to_merge:
        key_to_use = chosen_parameters[merge[0]]
        for item in merge:
            chosen_parameters[item] = key_to_use


def merge_pbs_ks_keys(graph: nx.DiGraph):
    """
    If more than one node has different PBS or KS keys with same parameters, create a single key and use the
    same for both, such that key creation time is smaller
    :param graph: target graph of fhe operations
    """
    used_ks_keys = []
    used_pbs_keys = []

    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_Pbs):
            matched = False
            for key in used_pbs_keys:
                if key.check_key_identical(node.pbs_key):
                    node.pbs_key = key
                    matched = True
            if not matched:
                used_pbs_keys.append(node.pbs_key)
        elif isinstance(node, Target_EncArray_Keyswitch):
            matched = False
            for key in used_ks_keys:
                if key.check_key_identical(node.ks_key):
                    node.ks_key = key
                    matched = True
            if not matched:
                used_ks_keys.append(node.ks_key)


def eliminate_useless_keyswitches(graph: nx.DiGraph, chosen_params: Dict[str, Any]):
    """
    Find keyswitches that go from larger to smaller dimension, and eliminate them, since they are useless
    :param graph: target graph of fhe operations
    :param chosen_params: chosen parameters for the graph
    """
    to_eliminate = []
    for node in graph.nodes():
        if isinstance(node, Target_EncArray_Keyswitch):
            in_len = chosen_params[node.input_encryption_key.unique_id].length
            out_len = chosen_params[node.output_encryption_key.unique_id].length
            if out_len >= in_len:
                to_eliminate.append(node)

    for node in to_eliminate:
        predecessors = [p for p in graph.predecessors(node)]
        successors = [s for s in graph.successors(node)]
        assert len(predecessors) == 1
        # todo(Joao): at the moment, it can't connect to more than one pbs, but perhaps it could at some point
        assert len(successors) == 1
        assert isinstance(successors[0], Target_EncArray_Pbs)
        pred = predecessors[0]
        weight = graph.get_edge_data(pred, node)["weight"]
        suc = successors[0]
        in_key = node.input_encryption_key
        suc.input_encryption_key = in_key
        graph.add_edge(pred, suc, weight=weight)
        graph.remove_node(node)


class OptimizableDiscreteParameter:
    """
    Representation of an optimization parameter with a discrete search search
    """

    def __init__(self, obj: type, choices: List[Tuple[Any]]):
        """
        :param obj: the type of the object being optimized (the class itself)
        :param choices: a list with choices for initialization of obj's constructor
        """
        self.obj = obj
        self.choices = choices
        self.unique_id = str(uuid.uuid4())

    def choose_random(self):
        return self.obj(*random.choice(self.choices))

    def build_from_choice(self, choice: Tuple[Any]):
        return self.obj(*choice)


class ParamOptimizer(ABC):
    def __init__(self, graph: nx.DiGraph, scheme: Scheme, bits_of_security: int):
        self.graph = graph
        self.scheme = scheme
        self.bits_of_security = bits_of_security
        self.parameters_to_optimize = self.preprocess_find_parameters_to_optimize()

    @abstractmethod
    def get_unsolved_nodes(self):
        """Returns a set of nodes whose var_out is always too high and don't have a solution"""

    def preprocess_find_parameters_to_optimize(self):
        # find subgraphs in which all nodes share the same output encryption key
        subgraphs = divide_into_subgraphs(self.graph, lambda x: x.can_change_encryption())

        parameters_to_optimize = {}
        # create encryption keys for each of the subgraphs, give them a unique id and put it
        # inside an encryption_key object
        for sg in subgraphs:
            key_constraints = []
            for node in sg.nodes():
                constraint = node.output_encryption_key_constraint(self.bits_of_security)
                if constraint is not None:
                    key_constraints.append(constraint)
            # find intersection of constraints
            constraint_sets = list(map(set, key_constraints))
            assert len(constraint_sets) > 0
            intersection = constraint_sets[0]
            for s in constraint_sets:
                intersection = intersection.intersection(s)
            intersection = list(intersection)
            if len(intersection) == 0:
                # todo(Joao): compilation error
                # this should never happen
                raise RuntimeError("Impossible to find appropriate key sizes in optimization")
            output_encryption_key = OptimizableDiscreteParameter(EncryptionKey, intersection)
            parameters_to_optimize[output_encryption_key.unique_id] = output_encryption_key
            for node in sg.nodes():
                node.output_encryption_key = output_encryption_key
                new_param = node.attach_parameter_to_optimizer()
                if new_param is not None:
                    obj, choices = new_param
                    parameter = OptimizableDiscreteParameter(obj, choices)
                    parameters_to_optimize[parameter.unique_id] = parameter
                    node.attach_parameter(parameter)
        for sg in subgraphs:
            for node in sg.nodes():
                predecessor_output_keys = [
                    p.output_encryption_key for p in self.graph.predecessors(node)
                ]
                if len(predecessor_output_keys) == 0:
                    # input node
                    node.input_encryption_key = node.output_encryption_key
                else:
                    p0 = predecessor_output_keys[0]
                    # this should always be true, but we check for debugging
                    assert all(map(lambda x: x == p0, predecessor_output_keys))
                    node.input_encryption_key = p0
        return parameters_to_optimize

    def postprocess_parameters(self, chosen_parameters: Dict[str, Any]):
        # if we have keys which are identical (i.e., same size and noise), then we don't need to create
        # different keys; this step thus eliminates redundant keys
        merge_encryption_keys(chosen_parameters)

        # some keyswitches are not useful, for example when it goes to a key of same size as it came from,
        # so we eliminate them here
        eliminate_useless_keyswitches(self.graph, chosen_parameters)

        for node in nx.topological_sort(self.graph):
            pred = list(self.graph.predecessors(node))
            node.update_variance(pred, chosen_parameters)
            node.set_parameters(chosen_parameters)

        merge_pbs_ks_keys(self.graph)

    @abstractmethod
    def optimize(self, optimizer_options: Optional[Dict[str, Any]]):
        """Optimize the parameters for a specific graph, given the scheme and bounds, as well
        as any aditional information that can be passed via **kwargs. This method should return
        encryption parameters.
        """
        pass
