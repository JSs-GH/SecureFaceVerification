import random
import uuid
from typing import Any, Dict, List, Optional, Set, Tuple

import networkx as nx
import numpy as np
from deap import base, creator, tools
from loguru import logger
from tqdm import trange

from ...crypto import Scheme
from ...representation.target import TargetNode
from .base import ParamOptimizer


class Individual:
    """
    Representation of an individual in our genetic algorithm
    """

    def __init__(self, parameter_choices: Dict[str, Any]):
        """
        :param parameter_choices: a dictionary of the parameters needed by the individual, where each entry
        represents the chosen parameter for this individual
        """
        self.unique_id = str(uuid.uuid4())
        self.parameter_choices = parameter_choices

    def __str__(self):
        return str(self.parameter_choices)


class IndividualGenerator:
    def __init__(
        self,
        parameters_to_optimize: Dict[str, Any],
    ):
        self.parameters_to_optimize = parameters_to_optimize

    def gen_random_individual(self):
        # let's start with individuals
        random_parameters = dict(
            (key, param.choose_random()) for key, param in self.parameters_to_optimize.items()
        )
        return random_parameters

    def mutate_individual(self, individual: Individual):
        mtpb = 0.25
        for uid, param in self.parameters_to_optimize.items():
            if random.random() < mtpb:
                new_param = param.choose_random()
                individual.parameter_choices[uid] = new_param


class IndividualEvaluator:
    def __init__(self, graph: nx.DiGraph, max_precision: int, confidence_level: int):
        self.graph = graph
        self.max_precision = max_precision
        self.confidence_level = confidence_level
        self.mean_costs = None
        self.std_dev_costs = None
        self.mean_noises = None
        self.std_dev_noises = None
        self.nodes_wo_solution = set(graph.nodes())

    def evaluate(self, individual: Individual):
        max_var_out = 0
        total_cost = 0

        for node in nx.topological_sort(self.graph):
            predecessors = [p for p in self.graph.predecessors(node)]
            node.update_variance(predecessors, individual.parameter_choices)
            node.update_cost(predecessors, individual.parameter_choices)
            # print(node, np.sqrt(node.var_out) / 2 ** 64)
            max_var_out = max(max_var_out, node.var_out)
            total_cost += node.cost
            # logger.debug(f"individual: {}, fitness: {}")
            if node in self.nodes_wo_solution and self.confidence_level * np.sqrt(
                node.var_out
            ) / 2 ** 64 < 1 / (2 ** self.max_precision):
                self.nodes_wo_solution.remove(node)

        worst_bit_affect = self.confidence_level * np.sqrt(max_var_out) / 2 ** 64

        return (
            -total_cost,
            worst_bit_affect,
        )

    def update_mean_stdev(self, scores: List[Tuple[float, float]]):
        score_costs = list(map(lambda x: x[0], scores))
        score_noises = list(map(lambda x: x[1], scores))
        self.mean_costs = np.mean(score_costs)
        self.std_dev_costs = np.std(score_costs)
        self.mean_noises = np.mean(score_noises)
        self.std_dev_noises = np.std(score_noises)

    def normalize_score(self, scores: Tuple[float, float]):
        tolerance = 1 / (2 ** self.max_precision)
        score_costs = list(map(lambda x: x[0], scores))
        score_worst_bit = list(map(lambda x: x[1], scores))
        z_score_costs = self.normalize_cost(score_costs)
        z_score_noises = self.normalize_noise(score_worst_bit)
        score = list(
            map(
                lambda x: x[1] if x[0] < tolerance else x[2],
                zip(score_worst_bit, z_score_costs, z_score_noises),
            )
        )
        return score

    def normalize_cost(self, score: List[float]):
        z_score_costs = list(map(lambda x: (x - self.mean_costs) / self.std_dev_costs, score))
        min_z_score = min(z_score_costs)
        z_score_bounded = list(map(lambda x: x - min_z_score, z_score_costs))

        return z_score_bounded

    def normalize_noise(self, score: List[float]):
        eps = 1 / 2 ** 10
        z_score_noises = list(map(lambda x: (x - self.mean_noises) / self.std_dev_noises, score))
        min_z_score = min(z_score_noises)
        z_score_bounded = map(lambda x: x - min_z_score, z_score_noises)
        # avoid becoming positive while still under tolerance
        z_score_bounded = list(map(lambda x: -x - eps, z_score_bounded))

        return z_score_bounded


def mate_individuals(child1: Individual, child2: Individual):
    total_fit = child1.fitness.values[0] + child2.fitness.values[0]
    eps = 1 / 2 ** 10
    if abs(total_fit) > eps:
        prob1 = 1 - child1.fitness.values[0] / total_fit
    else:
        prob1 = 0.5
    ind1_params = child1.parameter_choices
    ind2_params = child2.parameter_choices
    new_params_1 = {}
    new_params_2 = {}
    for key in ind1_params.keys():
        if random.random() < prob1:
            new_params_1[key] = ind1_params[key]
        else:
            new_params_1[key] = ind2_params[key]
        if random.random() < prob1:
            new_params_2[key] = ind1_params[key]
        else:
            new_params_2[key] = ind2_params[key]
    child1.parameter_choices = new_params_1
    child2.parameter_choices = new_params_2


# pylint: disable=E1101
class Genetic(ParamOptimizer):
    def __init__(self, graph: nx.DiGraph, scheme: Scheme, bits_of_security: int):
        ParamOptimizer.__init__(self, graph, scheme, bits_of_security)
        self.stop_at_score_score = None
        self.unsolved_nodes = None
        # optimizer parameters
        self.stop_at_score = None
        self.confidence_level = 10
        self.ngen = 100
        self.tournsize = 100
        self.popsize = 400
        self.elitism = 25

    def get_unsolved_nodes(self) -> Set[TargetNode]:
        return self.unsolved_nodes

    def optimize(self, optimizer_options: Optional[Dict[str, Any]]):
        if optimizer_options is None:
            optimizer_options = {}
        if "confidence_level" in optimizer_options:
            self.confidence_level = optimizer_options["confidence_level"]
        if "stop_at_score" in optimizer_options:
            self.stop_at_score = optimizer_options["stop_at_score"]
        if "ngen" in optimizer_options:
            self.ngen = optimizer_options["ngen"]
        if "tournsize" in optimizer_options:
            self.tournsize = optimizer_options["tournsize"]
        if "popsize" in optimizer_options:
            self.popsize = optimizer_options["popsize"]
        if "elitism" in optimizer_options:
            self.elitism = optimizer_options["elitism"]

        return self.run_genetic_optimization()

    def run_genetic_optimization(
        self,
    ):
        random.seed(60)
        # do genetic optimization
        # here, have a best individual
        individual_generator = IndividualGenerator(self.parameters_to_optimize)
        # todo(Joao): not so great, we're assuming same precision for whole graph,
        # but since we only support float5 for now, that's not so bad
        max_precision = max([n.dtype.bits_of_precision() for n in self.graph.nodes()])
        individual_evaluator = IndividualEvaluator(self.graph, max_precision, self.confidence_level)
        individual_historical_unnorm_scores = {}

        individual_generator.gen_random_individual()
        tournsize = self.tournsize
        popsize = self.popsize
        elitism = self.elitism
        cxpb, mutpb, ngen = 1, 0.25, self.ngen

        creator.create("FitnessMax", base.Fitness, weights=(1.0,))
        creator.create("Individual", Individual, fitness=creator.FitnessMax)

        toolbox = base.Toolbox()
        toolbox.register("attribute", individual_generator.gen_random_individual)
        toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.attribute)
        toolbox.register("population", tools.initRepeat, list, toolbox.individual)
        toolbox.register("mate", mate_individuals)
        toolbox.register("mutate", individual_generator.mutate_individual)
        toolbox.register("select", tools.selTournament, tournsize=tournsize)
        toolbox.register("evaluate", individual_evaluator.evaluate)

        pop = toolbox.population(n=popsize)
        fitnesses = list(map(toolbox.evaluate, pop))
        individual_evaluator.update_mean_stdev(fitnesses)
        norm_score = individual_evaluator.normalize_score(fitnesses)

        historic_unnormalized_fitnesses = fitnesses

        for ind, fit, unnorm_fit in zip(pop, norm_score, fitnesses):
            individual_historical_unnorm_scores[ind.unique_id] = unnorm_fit
            ind.fitness.values = (fit,)

        logger.debug(f"Genetic algorithm running for {ngen} generations")
        bob = []

        with trange(ngen) as t:
            for _ in t:
                offspring = toolbox.select(pop, elitism)
                offspring = list(map(toolbox.clone, offspring))
                # to_add = list(map(toolbox.clone, offspring))

                for child1, child2 in zip(offspring[::2], offspring[1::2]):
                    if random.random() < cxpb:
                        toolbox.mate(child1, child2)
                        del child1.fitness.values
                        del child2.fitness.values

                for mutant in offspring:
                    if random.random() < mutpb:
                        toolbox.mutate(mutant)
                        del mutant.fitness.values

                offspring += bob

                if len(offspring) < popsize:
                    offspring += toolbox.population(n=popsize - len(offspring))
                # invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
                # todo(Joao): re-evaluating all, let's avoid it
                inds = [ind for ind in offspring]
                fitnesses = list(map(toolbox.evaluate, inds))
                historic_unnormalized_fitnesses += fitnesses
                individual_evaluator.update_mean_stdev(historic_unnormalized_fitnesses)
                norm_fitnesses = individual_evaluator.normalize_score(fitnesses)

                for ind, fit in zip(inds, norm_fitnesses):
                    if fit >= 0 and ind not in bob:
                        bob.append(ind)
                    ind.fitness.values = (fit,)

                # lowest_noise = sorted(fitnesses, key=lambda x: x[0])[0]
                largest_noise = sorted(fitnesses, key=lambda x: x[1])[0]
                ##lowest_cost = sorted(fitnesses, key=lambda x: x[0])[0]
                highest_cost = sorted(fitnesses, key=lambda x: x[0])[-1]
                best_score = sorted(norm_fitnesses)[-1]
                # worst_score = sorted(norm_fitnesses)[0]

                t.set_postfix(
                    best_score=best_score,
                    best_noise=largest_noise[1],
                    best_cost=-highest_cost[0],
                    # largest_noise=largest_noise,
                    # lowest_cost=lowest_cost,
                    # highest_cost=highest_cost,
                    # individuals=len(offspring),
                )

                pop[:] = offspring

                if self.stop_at_score_score is not None and best_score > self.stop_at_score_score:
                    logger.debug(f"Genetic algorithm found acceptable solution early")
                    break

        best = 0
        winner = None
        for ind in bob:
            # print(f"evaluation: {individual_evaluator.evaluate(ind)}")
            # print(f"score: {ind.fitness.values}")
            if ind.fitness.values[0] >= best:
                best = ind.fitness.values[0]
                winner = ind

        if winner is None:
            # it couldn't find an acceptable solution (i.e. with low enough noise)
            # so we return None and record the nodes that particularly didn't have a solution,
            # such that the GA can try to solve it again with more PBSes or other strategies
            self.unsolved_nodes = individual_evaluator.nodes_wo_solution

            del creator.Individual
            del creator.FitnessMax

            return None
        else:

            logger.debug(f"Genetic algorithm finished. Winner: {winner}")

            score = individual_evaluator.evaluate(winner)
            normalized = individual_evaluator.normalize_score([score])

            # confidence_in_pct = int(1 / (1 - erf(confidence_level / np.sqrt(2))))
            logger.debug(
                f"Winner score: {score}, z_score: {normalized}, "  # probability of noise in the message: 1 in {confidence_in_pct:,}"
            )

            # for now, we just simulate to create one
            chosen_params = winner.parameter_choices

            del creator.Individual
            del creator.FitnessMax

            return chosen_params


# pylint: enable=E1101
