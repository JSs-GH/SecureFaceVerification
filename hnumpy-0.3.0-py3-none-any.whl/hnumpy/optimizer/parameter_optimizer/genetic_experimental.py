import random
import uuid
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Tuple

import networkx as nx
import numpy as np
from deap import base, creator, tools
from loguru import logger
from tqdm import trange

from ...crypto import Scheme
from ...parameters import Bounds
from .base import ParamOptimizer


class Individual:
    """
    Representation of an individual in our genetic algorithm
    """

    def __init__(self, parameter_choices: Dict[str, Any]):
        """
        :param parameter_choices: a dictionary of the parameters needed by the individual, where each entry
        represents the chosen parameter for this individual
        """
        self.unique_id = str(uuid.uuid4())
        self.parameter_choices = parameter_choices

    def __str__(self):
        return str(self.parameter_choices)


class IndividualGenerator:
    def __init__(
        self,
        graph: nx.DiGraph,
        parameters_to_optimize: Dict[str, Any],
        pbs_noise_sorted: List[Tuple[Tuple[int, int, int, int, int], float]],
        ks_noise_sorted: List[Tuple[Tuple[int, int, int, int, int], float]],
    ):
        self.graph = graph
        self.parameters_to_optimize = parameters_to_optimize
        self.nodes_affected_per_parameter = {}
        self.pbs_noise_sorted = pbs_noise_sorted
        self.ks_noise_sorted = ks_noise_sorted

        for node in self.graph.nodes():
            params = node.parameters_being_optimized()
            for param in params:
                if param not in self.nodes_affected_per_parameter:
                    self.nodes_affected_per_parameter[param] = [node]
                else:
                    self.nodes_affected_per_parameter[param].append(node)

    def gen_random_individual(self):
        # let's start with individuals
        random_parameters = dict(
            (key, param.choose_random()) for key, param in self.parameters_to_optimize.items()
        )
        return random_parameters

    def check_noise_by_switching(
        self, current_choices: Dict[str, Any], uid: str, choice: Tuple[Any]
    ):
        new_choices = deepcopy(current_choices)
        new_choices[uid] = self.parameters_to_optimize[uid].build_from_choice(choice)
        max_old_var = 0
        max_new_var = 0
        nodes_affected = self.nodes_affected_per_parameter[uid]
        for node in nx.topological_sort(self.graph):
            if node in nodes_affected:
                pred = list(self.graph.predecessors(node))
                old_var = node.var_out
                node.update_variance(pred, new_choices)
                new_var = node.var_out
                max_old_var = max(max_old_var, old_var)
                max_new_var = max(max_new_var, new_var)
        return max_new_var

    def mutate_noisy_individual(self, individual: Individual):
        for uid, param in self.parameters_to_optimize.items():
            if random.random() < 0.25:
                # best_choice = None
                lowest_var = np.inf
                to_select = None
                for choice in param.choices:
                    max_new_var = self.check_noise_by_switching(
                        individual.parameter_choices, uid, choice
                    )
                    if max_new_var < lowest_var:
                        lowest_var = max_new_var
                        to_select = choice
                if to_select is not None:
                    individual.parameter_choices[uid] = self.parameters_to_optimize[
                        uid
                    ].build_from_choice(to_select)

                """
                if self.check_noise_by_switching(
                    individual.parameter_choices, uid, choice
                ):
                    best_choice = choice
                    break
            if best_choice is not None:
                individual.parameter_choices[uid] = self.parameters_to_optimize[
                    uid
                ].build_from_choice(best_choice)
                break
                """

    def mutate_for_cost_individual(self, individual: Individual):
        pass

    def mutate_invalid_individual(self, individual: Individual):
        mtpb = 0.25
        for uid, param in self.parameters_to_optimize.items():
            if random.random() < mtpb:
                new_param = param.choose_random()
                individual.parameter_choices[uid] = new_param

    def mutate_individual(self, individual: Individual):
        if not individual.fitness.valid:
            self.mutate_invalid_individual(individual)
        elif individual.fitness.values[0] < 0:
            self.mutate_noisy_individual(individual)
        else:
            self.mutate_for_cost_individual(individual)


class IndividualEvaluator:
    def __init__(self, graph: nx.DiGraph, max_precision: int):
        self.graph = graph
        self.max_precision = max_precision
        self.mean_costs = None
        self.std_dev_costs = None
        self.mean_noises = None
        self.std_dev_noises = None

    def evaluate(self, individual: Individual):
        max_var_out = 0
        total_cost = 0

        for node in nx.topological_sort(self.graph):
            predecessors = [p for p in self.graph.predecessors(node)]
            node.update_variance(predecessors, individual.parameter_choices)
            node.update_cost(predecessors, individual.parameter_choices)
            max_var_out = max(max_var_out, node.var_out)
            total_cost += node.cost
            # logger.debug(f"individual: {}, fitness: {}")

        worst_bit_affect = (np.sqrt(max_var_out) * 3) / 2 ** 64  # 99.7% confidence

        return (
            -total_cost,
            worst_bit_affect,
        )

    def update_mean_stdev(self, scores: List[Tuple[float, float]]):
        score_costs = list(map(lambda x: x[0], scores))
        score_noises = list(map(lambda x: x[1], scores))
        self.mean_costs = np.mean(score_costs)
        self.std_dev_costs = np.std(score_costs)
        self.mean_noises = np.mean(score_noises)
        self.std_dev_noises = np.std(score_noises)

    def normalize_score(self, scores: List[Tuple[float, float]]):
        tolerance = 1 / (2 ** self.max_precision)
        score_costs = list(map(lambda x: x[0], scores))
        score_worst_bit = list(map(lambda x: x[1], scores))
        z_score_costs = self.normalize_cost(score_costs)
        z_score_noises = self.normalize_noise(score_worst_bit)
        score = list(
            map(
                lambda x: x[1] if x[0] < tolerance else x[2],
                zip(score_worst_bit, z_score_costs, z_score_noises),
            )
        )
        return score

    def normalize_cost(self, score: List[float]):
        z_score_costs = list(map(lambda x: (x - self.mean_costs) / self.std_dev_costs, score))
        min_z_score = min(z_score_costs)
        z_score_bounded = list(map(lambda x: x - min_z_score, z_score_costs))

        return z_score_bounded

    def normalize_noise(self, score: List[float]):
        eps = 1 / 2 ** 10
        z_score_noises = list(map(lambda x: (x - self.mean_noises) / self.std_dev_noises, score))
        min_z_score = min(z_score_noises)
        z_score_bounded = map(lambda x: x - min_z_score, z_score_noises)
        # avoid becoming positive while still under tolerance
        z_score_bounded = list(map(lambda x: -x - eps, z_score_bounded))

        return z_score_bounded


def mate_valid_inds(child1: Individual, child2: Individual):
    fit1, fit2 = child1.fitness.values[0], child2.fitness.values[0]
    if fit1 > 0 > fit2:
        prob1, prob2 = 0.9, 0.1
    elif fit2 > 0 > fit1:
        prob1, prob2 = 0.1, 0.9
    elif fit1 > 0 and fit2 > 0:
        total = fit1 + fit2
        prob1, prob2 = fit1 / total, fit2 / total
    else:
        total = fit1 + fit2
        prob1, prob2 = fit2 / total, fit1 / total
    return prob1, prob2


def mate_valid_invalid_ind(valid_ind: Individual, invalid_ind: Individual):
    vfit = valid_ind.fitness.values[0]
    if vfit > 0:
        prob1, prob2 = 0.95, 0.05
    else:
        prob1, prob2 = 0.75, 0.25
    return prob1, prob2


def mate_invalid_inds(*_):
    prob1, prob2 = 0.5, 0.5
    return prob1, prob2


def mate_individuals(child1: Individual, child2: Individual):
    """
    if child1.fitness.valid and child2.fitness.valid:
        prob1, prob2 = mate_valid_inds(child1, child2)
    elif child1.fitness.valid and not child2.fitness.valid:
        prob1, prob2 = mate_valid_invalid_ind(child1, child2)
    elif not child1.fitness.valid and child2.fitness.valid:
        prob1, prob2 = mate_valid_invalid_ind(child2, child1)
    else:
        prob1, prob2 = mate_invalid_inds(child1, child2)
    """
    prob1, prob2 = 0.5, 0.5
    ind1_params = child1.parameter_choices
    ind2_params = child2.parameter_choices
    new_params_1 = {}
    new_params_2 = {}
    for key in ind1_params.keys():
        if random.random() < prob1:
            new_params_1[key] = ind1_params[key]
        else:
            new_params_1[key] = ind2_params[key]
        if random.random() < prob1:
            new_params_2[key] = ind1_params[key]
        else:
            new_params_2[key] = ind2_params[key]
    child1.parameter_choices = new_params_1
    child2.parameter_choices = new_params_2


# pylint: disable=E1101
class GeneticExperimental(ParamOptimizer):
    def __init__(self, graph: nx.DiGraph, scheme: Scheme, bounds: Bounds):
        ParamOptimizer.__init__(self, graph, scheme, bounds)

    def get_unsolved_nodes(self):
        raise NotImplementedError

    def optimize(self, **kwargs):
        return self.run_genetic_optimization(self.parameters_to_optimize)

    def run_genetic_optimization(self, parameters_to_optimize: Dict[str, Any]):
        # do genetic optimization
        # here, have a best individual
        individual_generator = IndividualGenerator(
            self.graph,
            parameters_to_optimize,
            self.pbs_noise_sorted,
            self.ks_noise_sorted,
        )
        # todo(Joao): not so great, we're assuming same precision for whole graph,
        # but since we only support float5 for now, that's not so bad
        max_precision = max([n.dtype.bits_of_precision() for n in self.graph.nodes()])
        individual_evaluator = IndividualEvaluator(self.graph, max_precision)
        individual_historical_unnorm_scores = {}

        individual_generator.gen_random_individual()
        tournsize = 100
        popsize = 400
        elitism = 100
        cxpb, mutpb, ngen = 0.50, 0.10, 100

        creator.create("FitnessMax", base.Fitness, weights=(1.0,))
        creator.create("Individual", Individual, fitness=creator.FitnessMax)

        toolbox = base.Toolbox()
        toolbox.register("attribute", individual_generator.gen_random_individual)
        toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.attribute)
        toolbox.register("population", tools.initRepeat, list, toolbox.individual)
        toolbox.register("mate", mate_individuals)
        toolbox.register("mutate", individual_generator.mutate_individual)
        # toolbox.register("select", tools.selNSGA2)
        toolbox.register("select", tools.selBest)
        toolbox.register("evaluate", individual_evaluator.evaluate)

        pop = toolbox.population(n=popsize)
        fitnesses = list(map(toolbox.evaluate, pop))
        individual_evaluator.update_mean_stdev(fitnesses)
        norm_score = individual_evaluator.normalize_score(fitnesses)

        historic_unnormalized_fitnesses = fitnesses

        for ind, fit, unnorm_fit in zip(pop, norm_score, fitnesses):
            individual_historical_unnorm_scores[ind.unique_id] = unnorm_fit
            ind.fitness.values = (fit,)

        logger.info(f"Genetic algorithm running for {ngen} generations")
        bob = []
        bob_orig_fitnesess = {}

        with trange(ngen) as t:
            for _ in t:
                # select top individuals
                offspring = toolbox.select(pop, tournsize)
                # clone individuals
                offspring = list(map(toolbox.clone, offspring))

                # add some randomly chosen best-of-best individuals from previous generations
                if len(bob) > 0:
                    # random_bob = random.choices(bob, k=popsize - len(offspring))
                    # offspring += list(map(toolbox.clone, random_bob))
                    offspring += list(map(toolbox.clone, bob))
                else:
                    offspring += toolbox.population(n=popsize - len(offspring))

                # perform crossover between chosen individuals
                for child1, child2 in zip(offspring[::2], offspring[1::2]):
                    if random.random() < cxpb:
                        toolbox.mate(child1, child2)
                        del child1.fitness.values
                        del child2.fitness.values

                for mutant in offspring:
                    if random.random() < mutpb:
                        toolbox.mutate(mutant)
                        del mutant.fitness.values

                fitnesses = list(map(toolbox.evaluate, offspring))

                historic_unnormalized_fitnesses += fitnesses

                individual_evaluator.update_mean_stdev(historic_unnormalized_fitnesses)

                norm_fitnesses = individual_evaluator.normalize_score(fitnesses)

                for ind, fit, unnorm_fit in zip(offspring, norm_fitnesses, fitnesses):
                    if fit > 0 and ind not in bob:
                        bob.append(ind)
                        bob_orig_fitnesess[ind] = unnorm_fit
                    ind.fitness.values = (fit,)

                positive_bob = list(filter(lambda x: x.fitness.values[0], bob))

                if len(positive_bob) > 0:
                    bob = positive_bob

                if len(bob) == 0:
                    # just add a few best so far
                    lowest_noise = sorted(zip(offspring, fitnesses), key=lambda x: x[1][0])[
                        :elitism
                    ]
                    bob += list(map(lambda x: x[0], lowest_noise))
                    for ind, fit in lowest_noise:
                        bob_orig_fitnesess[ind] = fit

                bob_fit_old = list(map(lambda x: bob_orig_fitnesess[x], bob))
                norm_bob_fitnesses = individual_evaluator.normalize_score(bob_fit_old)
                for b, norm in zip(bob, norm_bob_fitnesses):
                    b.fitness.values = (norm,)

                lowest_noise = sorted(fitnesses, key=lambda x: x[0])[0]
                # largest_noise = sorted(fitnesses, key=lambda x: x[0])[-1]
                ##lowest_cost = sorted(fitnesses, key=lambda x: x[0])[0]
                # highest_cost = sorted(fitnesses, key=lambda x: x[0])[-1]
                best_score = sorted(norm_fitnesses)[-1]
                # worst_score = sorted(norm_fitnesses)[0]

                t.set_postfix(
                    best_score=best_score,
                    lowest_noise=lowest_noise,
                    # largest_noise=largest_noise,
                    # lowest_cost=lowest_cost,
                    # highest_cost=highest_cost,
                    individuals=len(offspring),
                )

                pop[:] = offspring

        best = 0
        winner = None
        for ind in bob:
            # print(f"evaluation: {individual_evaluator.evaluate(ind)}")
            # print(f"score: {ind.fitness.values}")
            if ind.fitness.values[0] > best:
                best = ind.fitness.values[0]
                winner = ind

        # if it's None, it couldn't find a good solution
        if winner is None:
            # fall back to some sort of worst case?
            # raise CompilationError
            raise ValueError("Parameter optimizer couldn't find a good solution")

        logger.info(f"Genetic algorithm finished. Winner: {winner}")

        score = individual_evaluator.evaluate(winner)
        normalized = individual_evaluator.normalize_score([score])

        logger.info(f"Winner score: {score}, z_score: {normalized}")

        # for now, we just simulate to create one
        chosen_params = winner.parameter_choices

        return chosen_params


# pylint: enable=E1101
