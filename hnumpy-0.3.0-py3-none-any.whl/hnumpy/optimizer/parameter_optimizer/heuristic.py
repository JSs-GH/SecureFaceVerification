from typing import Any, Dict, Optional

from ...crypto import (
    EncryptionKey,
    KeyswitchParameters,
    PbsParameters,
    secure_parameter_tuples,
)
from .base import ParamOptimizer


class HeuristicOptimizer(ParamOptimizer):
    def get_unsolved_nodes(self):
        ...

    def optimize(self, _optimizer_options: Optional[Dict[str, Any]] = None):

        parameters = secure_parameter_tuples(self.bits_of_security)
        n_encryption_key_choices = list(filter(lambda x: x[1] <= -31, parameters))[0]
        N_encryption_key_choices = filter(lambda x: x[1] <= -31, parameters)
        N_encryption_key_choices = list(
            filter(
                lambda x: (x[0] & (x[0] - 1) == 0) and x[0] != 0,
                N_encryption_key_choices,
            )
        )[0]

        ks_params_choices = [(8, 4)]
        pbs_params_choices = [(8, 4)]

        for uid, param in self.parameters_to_optimize.items():
            if param.obj is EncryptionKey:
                if n_encryption_key_choices in param.choices:
                    param.choices = [n_encryption_key_choices]
                elif N_encryption_key_choices in param.choices:
                    param.choices = [N_encryption_key_choices]
            elif param.obj is PbsParameters:
                param.choices = pbs_params_choices
            elif param.obj is KeyswitchParameters:
                param.choices = ks_params_choices

        chosen_params = dict(
            map(
                lambda item: (item[0], item[1].choose_random()),
                self.parameters_to_optimize.items(),
            )
        )

        return chosen_params
