import networkx as nx

from .base import ParamOptimizer


class MonteCarloTreeSearch(ParamOptimizer):
    def __init__(self, graph, scheme, bounds):
        ParamOptimizer.__init__(self, graph, scheme, bounds)
        self.tree = nx.DiGraph()
        # we need this not to change order
        self.stable_params = self.parameters_to_optimize.keys()

    def optimize(self, **kwargs):
        for leaf in self.tree:
            pass

        pass
