from typing import Any, Callable, Dict, Optional

import networkx as nx

from ..representation.topology import is_output_node, replace_output


def find_pattern(graph: nx.DiGraph, pattern: nx.DiGraph) -> Optional[Dict[Any, int]]:
    """
    Returns a subgraph containing the nodes that match `pattern`
    :param graph:
    :param old_pattern:
    :return:
    """

    # find subgraph isomorphism
    def node_match(a, b):
        if b["op"] == Ellipsis:
            return True
        elif isinstance(b["op"], tuple):
            if "cond" in b:
                return a["op"] in b["op"] and b["cond"](a["self_"])
            else:
                return a["op"] in b["op"]
        else:
            if "cond" in b:
                return a["op"] == b["op"] and b["cond"](a["self_"])
            else:
                return a["op"] == b["op"]

    graph_matcher = nx.algorithms.isomorphism.DiGraphMatcher(graph, pattern, node_match=node_match)

    graph_matcher.match()

    for isomorphim in graph_matcher.subgraph_isomorphisms_iter():
        yield isomorphim


def check_pattern_is_valid(pattern: nx.DiGraph):
    nodes_wo_pred = list(filter(lambda x: len(list(pattern.predecessors(x))) == 0, pattern.nodes()))
    nodes_wo_succ = list(filter(lambda x: len(list(pattern.successors(x))) == 0, pattern.nodes()))
    if len(nodes_wo_pred) > 1 or len(nodes_wo_succ) > 1:
        raise ValueError(
            f"pattern given to pattern rewriter is invalid, because it contains "
            f"{len(nodes_wo_pred)} nodes without predecessors, and {len(nodes_wo_succ)}"
            f" nodes without successors, but only one of each is allowed "
        )


def build_pattern(
    new_pattern: nx.DiGraph,
    old_nodes_dict: Dict[int, Any],
    initializer: Dict[int, Callable],
):
    subgraph = nx.DiGraph()
    new_node_dict = {}
    for node in nx.topological_sort(new_pattern):
        new_node = initializer[node](old_nodes_dict)
        new_node_dict[node] = new_node
        subgraph.add_node(new_node)
        for p in new_pattern.predecessors(node):
            new_graph_p = new_node_dict[p]
            w = new_pattern.get_edge_data(p, node)["weight"]
            subgraph.add_edge(new_graph_p, new_node, weight=w)
    return subgraph


def rewrite_graph(
    graph: nx.DiGraph,
    old_pattern: nx.DiGraph,
    found_pattern: Dict[int, Any],
    new_subgraph: nx.DiGraph,
) -> bool:
    initial_nodes_new = list(
        filter(lambda x: len(list(new_subgraph.predecessors(x))) == 0, new_subgraph.nodes())
    )

    terminal_nodes_new = list(
        filter(lambda x: len(list(new_subgraph.successors(x))) == 0, new_subgraph.nodes())
    )

    # assert len(initial_nodes_new) == 1
    assert len(terminal_nodes_new) == 1

    terminal_node_new = terminal_nodes_new[0]

    for num, node in found_pattern.items():
        predecessors = list(graph.predecessors(node))
        successors = list(graph.successors(node))
        for p in predecessors:
            if p not in found_pattern.values() and node not in new_subgraph.nodes():
                # this is a problem, since the predecessor will be edgeless,
                # unless it's the initial, so we check that it's initial
                # within subgraph
                if len(list(old_pattern.predecessors(num))) > 0:
                    return False
        for s in successors:
            if s not in found_pattern.values() and node not in new_subgraph.nodes():
                # this is a problem, since the successor will be edgeless,
                # unless it's the terminal, so we check for terminality
                # within subgraph
                if len(list(old_pattern.successors(num))) > 0:
                    return False

    keep_node = []
    for node in new_subgraph.nodes():
        if node in graph.nodes():
            keep_node.append(node)
        else:
            graph.add_node(node)
    for f, t in new_subgraph.edges():
        w = new_subgraph.get_edge_data(f, t)["weight"]
        graph.add_edge(f, t, weight=w)

    initial_nodes_old = list(
        filter(lambda x: len(list(old_pattern.predecessors(x))) == 0, old_pattern.nodes())
    )

    terminal_nodes_old = list(
        filter(lambda x: len(list(old_pattern.successors(x))) == 0, old_pattern.nodes())
    )

    # assert len(initial_nodes_old) == 1
    assert len(terminal_nodes_old) == 1
    assert len(initial_nodes_new) == len(initial_nodes_old)

    terminal_in_graph = found_pattern[terminal_nodes_old[0]]

    if len(initial_nodes_new) > 1:
        for node in initial_nodes_new:
            if node not in graph.nodes():
                # cannot resolve predecessors
                return False
        succ = [s for s in graph.successors(terminal_in_graph)]
        succ_w = [graph.get_edge_data(terminal_in_graph, s)["weight"] for s in succ]

        for w, s in zip(succ_w, succ):
            graph.add_edge(terminal_node_new, s, weight=w)

        if is_output_node(graph, terminal_in_graph):
            replace_output(graph, terminal_in_graph, terminal_node_new)
        for num, node in found_pattern.items():
            if node not in keep_node:
                graph.remove_node(node)
        return True
    else:
        initial_in_graph = found_pattern[initial_nodes_old[0]]
        pred = [p for p in graph.predecessors(initial_in_graph)]
        pred_w = [graph.get_edge_data(p, initial_in_graph)["weight"] for p in pred]
        succ = [s for s in graph.successors(terminal_in_graph)]
        succ_w = [graph.get_edge_data(terminal_in_graph, s)["weight"] for s in succ]

        for w, p in zip(pred_w, pred):
            graph.add_edge(p, initial_nodes_new[0], weight=w)

        for w, s in zip(succ_w, succ):
            graph.add_edge(terminal_node_new, s, weight=w)

        if is_output_node(graph, terminal_in_graph):
            replace_output(graph, terminal_in_graph, terminal_node_new)

        for num, node in found_pattern.items():
            if node not in keep_node:
                graph.remove_node(node)

        return True


def pattern_rewrite(
    graph: nx.DiGraph,
    old_pattern: nx.DiGraph,
    new_pattern: nx.DiGraph,
    node_initializer: Dict[int, Callable],
) -> bool:
    """
    Rewriter the `old_pattern` into a `new_pattern`
    The patterns must be written with integer nodes containing the node type as attribute,
    and the node_initializer must contain for each new node in the new pattern, a function which
    takes a dictionary of the old nodes and returns an initialized new node
    :param graph: graph in which to search for matches
    :param old_pattern:
    :param new_pattern:
    :param node_initializer:
    """
    values = dict(map(lambda x: (x, type(x)), graph.nodes()))
    selfs = dict(map(lambda x: (x, x), graph.nodes()))
    nx.set_node_attributes(graph, values, "op")
    nx.set_node_attributes(graph, selfs, "self_")

    # check_pattern_is_valid(old_pattern)
    # check_pattern_is_valid(new_pattern)

    optimized = False

    for found_pattern in find_pattern(graph, old_pattern):
        # just invert dict
        found_pattern = dict([(value, key) for key, value in found_pattern.items()])

        next_pattern = False

        for num, node in found_pattern.items():
            if len(list(old_pattern.successors(num))) > 0 and is_output_node(graph, node):
                # there's an output node in the middle of the pattern, cannot substitute it safely
                next_pattern = True

        if next_pattern:
            continue

        new_subgraph = build_pattern(new_pattern, found_pattern, node_initializer)

        optimized = rewrite_graph(graph, old_pattern, found_pattern, new_subgraph)

        if optimized:
            break

    return optimized
