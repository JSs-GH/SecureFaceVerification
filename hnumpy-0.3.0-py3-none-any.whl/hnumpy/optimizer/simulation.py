"""
Simulation package to estimate results or intermediate values at a specific computation node
"""

from typing import List

import networkx as nx
import numpy as np

from ..representation.target import *


def _compute_cleararray_input(node, inputs):
    assert len(inputs) == 1, "cleararray requires a single input"
    return inputs[0]


def _compute_encarray_input(node, inputs):
    assert len(inputs) == 1, "encarray requires a single input"
    return inputs[0]


def _compute_encarray_encarray_add(node, inputs):
    assert len(inputs) == 2, "addition requires two inputs"
    return inputs[0] + inputs[1]


def _compute_encarray_add_with_const(node, inputs):
    assert len(inputs) == 1, "encarray_add_with_const requires a single input"
    return inputs[0] + node.constant


def _compute_encarray_sub_with_const(node, inputs):
    assert len(inputs) == 1, "encarray_sub_with_const requires a single input"
    return inputs[0] - node.scalar


def _compute_encarray_mult_by_scalar(node, inputs):
    assert len(inputs) == 1, "encarray_mult_by_scalar requires a single input"
    return inputs[0] * node.scalar


def _compute_encarray_cleararray_matmul(node, inputs):
    assert len(inputs) == 2, "matmul requires two inputs"
    return np.matmul(inputs[0], inputs[1])


def _compute_encarray_constarray_dot2d(node, inputs):
    assert len(inputs) == 1, "constant dot2d requires a single input"
    if node.side == "right":
        return inputs[0].dot(node.content)
    else:
        return node.content.dot(inputs[0])


def _compute_encarray_constarray_add(node, inputs):
    assert len(inputs) == 1, "constant add requires a single input"
    return inputs[0] + node.constant_array


def _compute_keyswitch(node, inputs):
    assert len(inputs) == 1, "keyswitch requires a single inputs"
    return inputs[0]


def _compute_discretize(node, inputs):
    assert len(inputs) == 1, "discretize requires a single inputs"
    return inputs[0] * node.expansion


# TODO: from where to get the value
def _compute_encarray_setitem(node, inputs):
    assert len(inputs) == 2, "setitem requires a single inputs"
    inputs[0][node.item] = inputs[1]
    return inputs


def _compute_encarray_getitem(node, inputs):
    assert len(inputs) == 1, "getitem requires a single inputs"
    return inputs[0][node.item]


def _compute_encarray_pbs(node, inputs):
    # TODO: use a lookup table
    assert len(inputs) == 1, "pbs requires a single inputs"
    return node.func(inputs[0])


def _compute_encarray_sum(node, inputs):
    assert len(inputs) == 1, "sum requires a single inputs"
    return np.sum(inputs[0])


_NODE_COMPUTATION_MAPPING = {
    Target_ClearArray_Input: _compute_cleararray_input,
    Target_EncArray_Input: _compute_encarray_input,
    Target_EncArrayEncArray_Add: _compute_encarray_encarray_add,
    Target_EncArray_AddWithConst: _compute_encarray_add_with_const,
    Target_EncArray_SubWithConstant: _compute_encarray_sub_with_const,
    Target_EncArrayClearArray_Matmul: _compute_encarray_cleararray_matmul,
    Target_EncArrayClearConstArray_Dot2d: _compute_encarray_constarray_dot2d,
    Target_EncArray_AddWithConstArray: _compute_encarray_constarray_add,
    Target_EncArray_Keyswitch: _compute_keyswitch,
    # Target_ClearArray_Discretize: _compute_discretize,
    Target_EncArray_MultByScalar: _compute_encarray_mult_by_scalar,
    Target_EncArrayEncArray_SetItemWithConstExprIndex: _compute_encarray_setitem,
    Target_EncArray_Pbs: _compute_encarray_pbs,
    Target_EncArray_Sum: _compute_encarray_sum,
}


def simulate_compute_node(node, inputs):
    """
    Simulate the execution of a node given its inputs
    :param node: target node to be simulated
    :param inputs: list of inputs the node is expecting
    :return: output of the target node
    """
    if type(node) not in _NODE_COMPUTATION_MAPPING:
        raise TypeError(f"node of type '{type(node)}' can't be simulated")
    return _NODE_COMPUTATION_MAPPING[type(node)](node, inputs)


def simulate_graph(
    graph: nx.DiGraph, dataset: List[List[np.ndarray]], fhe_aware: bool, add_noise: bool
):
    """
    Simulate the execution of a graph given a set of inputs
    :param graph: graph of target nodes to be simulated
    :param dataset: set of inputs
    :return: dictionnary of points computed on each node
    """
    points = {node: [] for node in graph.nodes()}
    # compute points by iterating over nodes in a topological order, and simulating computation
    for i, x in enumerate(dataset):
        for node in nx.topological_sort(graph):
            predecessors = list(graph.predecessors(node))
            inputs = [None] * len(predecessors)
            # if isinstance(node, Target_EncArrayClearArray_Matmul):
            #     ps = [p for p in graph.predecessors(node)]
            #     assert isinstance(ps[0], Target_ClearArray_Input)
            #     assert isinstance(ps[1], Target_EncArrayEncArray_Add)
            for p in graph.predecessors(node):
                weight = graph.get_edge_data(p, node)["weight"]
                assert len(points[p]) == i + 1, "predecessor should have already been computed"
                inputs[weight] = points[p][i]
            if isinstance(node, Target_EncArray_Input):
                inputs = [x[node.input_num]]
            assert all(map(lambda x: x is not None, inputs))
            if fhe_aware:
                result = node.simulate_fhe(*tuple(inputs))
            else:
                result = simulate_compute_node(node, inputs)
            # simulate_compute_node(node, tuple(inputs))
            points[node].append(result)
    return points
