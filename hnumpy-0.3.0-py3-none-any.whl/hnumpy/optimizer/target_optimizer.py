from typing import Callable, List, Optional

import networkx as nx
import numpy as np

from ..representation.target import *
from ..representation.topology import divide_into_subgraphs
from .encoding_optimizer import find_regional_encodings, optimize_with_simplification
from .simulation import simulate_graph


def concretize_nodes(graph: nx.DiGraph):
    """
    Prepares the nodes in the graph for VM conversion,
    and returns information about secret and public keys
    required by the graph
    :param graph: target graph to concretize
    """
    encryption_keys = []
    pbs_keys = []
    ks_keys = []
    for node in graph.nodes():
        node.prepare_for_rte_conversion()
        if node.output_encryption_key not in encryption_keys:
            encryption_keys.append(node.output_encryption_key)
        if isinstance(node, Target_EncArray_Keyswitch):
            pbs_keys.append(node.ks_key)
        elif isinstance(node, Target_EncArray_Pbs):
            ks_keys.append(node.pbs_key)
    return encryption_keys, pbs_keys, ks_keys


def update_bounds(graph: nx.DiGraph, probabilistic_bounds: Optional[float] = None):
    """
    Update the bounds of every node. This assumes
    worst case scenario and will support the biggest bounds possible. Check
    `update_bounds_with_dataset` for a more optimized function.
    :param graph: target graph
    :param probabilistic_bounds: if set, use probabilistic bounds computation using the provided
                                 value as the confidence level
    """
    for node in nx.topological_sort(graph):
        predecessors = [p for p in graph.predecessors(node)]
        p_weight = [graph.get_edge_data(p, node)["weight"] for p in predecessors]
        predecessors = [p for _, p in sorted(zip(p_weight, predecessors))]
        lower_bounds = [p.output_lower_bound for p in predecessors]
        upper_bounds = [p.output_upper_bound for p in predecessors]
        node.update_bounds(lower_bounds, upper_bounds, probabilistic_bounds)


def update_bounds_with_dataset(
    graph: nx.DiGraph, dataset: List[List[np.ndarray]], bounds_estimator: Callable
):
    """
    Use a dataset to estimate the range of input at every node, and update node bounds using
    emperical results
    :param graph: the computation graph
    :param dataset: sequence of inputs as numpy arrays
    :param bounds_estimator: function to compute the bounds from a given list of data points
    """
    points_per_node = simulate_graph(graph, dataset, False, False)
    # use bounds_estimator to compute the bounds from the data points
    bounds = {node: bounds_estimator(points_per_node[node]) for node in graph.nodes()}
    # update the bounds at every node
    for node in nx.topological_sort(graph):
        node.output_lower_bound = bounds[node][0]
        node.output_upper_bound = bounds[node][1]
        predecessors = [p for p in graph.predecessors(node)]
        if len(predecessors) == 0:  # input node
            node.input_lower_bounds = [node.output_lower_bound]
            node.input_upper_bounds = [node.output_upper_bound]
        else:
            node.input_lower_bounds = []
            node.input_upper_bounds = []
            for p in predecessors:
                node.input_lower_bounds.append(p.output_lower_bound)
                node.input_upper_bounds.append(p.output_upper_bound)


def get_input_bounds(graph: nx.DiGraph):
    """
    Get the bounds of inputs sorted by their input number
    :return: input_bounds sorted by input numbers
    """
    input_bounds = {}
    for node in graph.nodes():
        if isinstance(node, (Target_ClearArray_Input, Target_EncArray_Input)):
            input_num = node.input_num
            try:
                lower_bound = node.input_lower_bounds[0]
                upper_bound = node.input_upper_bounds[0]
            except IndexError:
                raise RuntimeError("tried to get input bounds before setting them")
            input_bounds[input_num] = (lower_bound, upper_bound)
    return [input_bounds[i] for i in sorted(input_bounds.keys())]


def optimize_bounds(graph: nx.DiGraph, samples=None, symbolic_bounds=False):
    if samples is not None:
        # TODO: parameterize this
        bounds_estimator = lambda x: (np.min(x), np.max(x))
        update_bounds_with_dataset(graph, samples, bounds_estimator)

    if symbolic_bounds:
        optimize_with_simplification(graph)

    # divide graph into independent sub-graphs bordered by nodes that can change encoding
    subgraphs = divide_into_subgraphs(graph, lambda node: node.can_change_encoding())

    # find lower and upper bounds within each sub-graph, and use that as separate encodings
    find_regional_encodings(graph, subgraphs)
