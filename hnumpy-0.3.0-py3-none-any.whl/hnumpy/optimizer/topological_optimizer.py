from typing import Any, Callable, List, Tuple

import networkx as nx
import numpy as np

from ..config import CompilationArtifacts
from ..encoding import Encoder
from ..representation import is_output_node, replace_output
from ..representation.target import *
from ..representation.target.pbs import (
    FuncPropAdditive,
    FuncPropAffine,
    FuncPropInvertible,
    PbsFuncProperty,
)
from ..representation.topology import (
    add_between_nodes,
    move_node_before_node,
    substitute_node,
    switch_nodes,
)
from . import remove_dead_nodes
from .pattern_rewriter import pattern_rewrite


def find_closest_successor_condition(graph: nx.DiGraph, node: Any, condition: Callable):
    """
    Finds the closest successor to node that satisfies the condition
    :param graph: graph
    :param node: node to start looking
    :param condition: condition to satisfy
    :return: closest successor
    """
    for s in graph.successors(node):
        if condition(s):
            return s
        else:
            return find_closest_successor_condition(graph, s, condition)
    return None


def check_chain_satisfies_condition(graph: nx.DiGraph, left: Any, right: Any, condition: Callable):
    """
    Checks that there's a single "chain" between left and right,
    meaning that all intermediate nodes have a single predecessor and a
    single successor, and every intermediate node satisfies condition
    :param graph: graph to check for chain
    :param left: initial node
    :param right: last node
    :param condition: condition to satisfy
    :return: True iff satisfies unique chain and condition
    """
    successor = left
    while True:
        predecessors = [p for p in graph.predecessors(successor)]
        successors = [s for s in graph.successors(successor)]
        if len(successors) != 1 or len(predecessors) != 1:
            return False
        successor = successors[0]
        if successor == right:
            break
        elif not condition(successor):
            return False
    return True


def is_affine(props: List[PbsFuncProperty]) -> bool:
    """
    returns True iff the function in the pbs is affine
    :param props: pbs node
    :return: bool
    """
    return any([isinstance(x, FuncPropAffine) for x in props])


def is_additive(props: List[PbsFuncProperty]) -> bool:
    """
    Returns True iff the function in the pbs is additive
    :param pbs: pbs node
    :return: bool
    """
    return any([isinstance(x, FuncPropAdditive) for x in props])


def is_invertible(props: List[PbsFuncProperty]) -> bool:
    """
    Returns True iff the function in the pbs is invertible
    :param pbs: pbe node
    :return: bool
    """
    return any([isinstance(x, FuncPropInvertible) for x in props])


def get_inv_func(props: List[PbsFuncProperty]) -> Callable:
    """
    Returns the inverse of the function in the Pbs, if it exists
    :param pbs: pbe node
    :return: inverse function
    """
    assert is_invertible(props)
    inv = list(filter(lambda x: isinstance(x, FuncPropInvertible), props))
    assert len(inv) == 1
    return inv[0].inv_func


def get_affine_parameters(props: List[PbsFuncProperty]) -> Tuple[float, float]:
    """
    Returns affine parameters (a and b in ax+b)
    :param props: function properties
    :return: (a, b)
    """
    assert is_affine(props)
    affine = list(filter(lambda x: isinstance(x, FuncPropAffine), props))
    assert len(affine) == 1
    return affine[0].a, affine[0].b


def find_addition_properties(
    lhs: List[PbsFuncProperty], rhs: List[PbsFuncProperty]
) -> List[PbsFuncProperty]:
    """
    Given two functions f(x) and g(x) and their properties,
    we find the properties of f(x) + g(x)
    :param lhs: properties of f(x)
    :param rhs:  properties of g(x)
    """
    new_properties = []
    # check whether they're additive
    if is_additive(lhs) and is_additive(rhs):
        # if f(x+y) = f(x) + f(y) and g(x+y) = g(x) + g(y), then
        # f(x+y) + g(x+y) =f(x) + f(y) + g(x) + g(y)
        new_properties.append(FuncPropAdditive())
    if is_affine(lhs) and is_affine(rhs):
        lhs_a, lhs_b = get_affine_parameters(lhs)
        rhs_a, rhs_b = get_affine_parameters(rhs)
        new_a = lhs_a + rhs_a
        new_b = lhs_b + rhs_b
        new_affine = FuncPropAffine(new_a, new_b)
        new_properties.append(new_affine)

    # we can't tell whether h(x) = f(x) + g(x) is invertible,
    # so no need to check for property
    return new_properties


def find_composite_properties(
    inner_func_prop: List[PbsFuncProperty], outer_func_prop: List[PbsFuncProperty]
) -> List[PbsFuncProperty]:
    """
    Given two functions f(x) and g(x) and their properties,
    we find the properties of f(g(x))
    :param inner_func: properties of g(x)
    :param outer_func: properties of f(x)
    :return: new properties
    """
    new_properties = []
    # check whether they're additive
    if is_additive(inner_func_prop) and is_additive(outer_func_prop):
        # if f(x+y) = f(x) + f(y) and g(x+y) = g(x) + g(y), then
        # f(g(x+y)) = f(g(x)) + f(g(y))
        new_properties.append(FuncPropAdditive())
    # check whether both are invertible
    if is_invertible(inner_func_prop) and is_invertible(outer_func_prop):
        inner_inv = get_inv_func(inner_func_prop)
        outer_inv = get_inv_func(outer_func_prop)
        # the inverse of f(g(x)) == f^-1(g^-1(x))
        inner_inv_func = inner_inv
        outer_inv_func = outer_inv
        new_inv = FuncPropInvertible(lambda x, f=outer_inv_func, g=inner_inv_func: f(g(x)))
        new_properties.append(new_inv)
    # check whether they're affine
    if is_affine(inner_func_prop) and is_affine(outer_func_prop):
        inner_a, inner_b = get_affine_parameters(inner_func_prop)
        outer_a, outer_b = get_affine_parameters(outer_func_prop)
        new_a = outer_a * inner_a
        new_b = inner_b * outer_a + outer_b
        new_affine = FuncPropAffine(new_a, new_b)
        new_properties.append(new_affine)
    return new_properties


def apply_optimizations(
    graph: nx.DiGraph, collection: List[Callable], artifacts: CompilationArtifacts
):
    """
    Applies optimizations from collection into the graph, until there's nothing more to apply
    :param graph: graph in which to apply optimizations
    :param collection: collection of callable objects which take a graph and modify it inplace to optimize it
    """
    opt_to_apply = True
    while opt_to_apply:
        opt_to_apply = False
        for opt in collection:
            opt_graph = opt(graph)
            if opt_graph:
                artifacts.optimizations_applied.append(str(opt))
            opt_to_apply = opt_graph or opt_to_apply


def add_keyswitch(graph: nx.DiGraph, node: TargetNode):
    """
    Inserts a keyswitch node and its unique predecessors
    :param graph: target graph
    :param node: node that has predecessors which need a keyswitch
    """
    predecessors = list(graph.predecessors(node))
    assert len(predecessors) == 1
    pred = predecessors[0]
    input_shapes = [pred.output_shape]
    output_shape = numpy.copy(pred.output_shape)
    keyswitch = Target_EncArray_Keyswitch(
        input_shapes,
        output_shape,
        pred.ir_source,
        pred.dtype,
    )
    add_between_nodes(graph, pred, node, keyswitch)


def there_is_pbs_predecessor(graph: nx.DiGraph, node: TargetNode):
    found_pbs = False
    for pred in graph.predecessors(node):
        if isinstance(pred, Target_EncArray_Pbs):
            found_pbs = True
            break
        else:
            found_pbs = there_is_pbs_predecessor(graph, pred)
    return found_pbs


def add_keyswitch_before_pbs(graph: nx.DiGraph):
    """
    Finds pbs nodes whose inputs have been through a pbs before, and add a keyswitch before them
    :param graph: target graph
    """
    ks_to_add = []
    for node in graph.nodes():
        if isinstance(node, Target_EncArray_Pbs):
            if there_is_pbs_predecessor(graph, node):
                # we assume that, at this point, there's no keyswitch before this node
                # if there were, we'd be adding extra useless keyswitches
                ks_to_add.append(node)
    for pbs in ks_to_add:
        add_keyswitch(graph, pbs)


def _can_merge(graph: nx.DiGraph, first_node: TargetNode, second_node: TargetNode):
    """
    Check if first and second node can be merged
    :param graph: the graph where these two nodes resides
    :param first_node: predecessor node of second_node
    :param second_node: successor node of first_node
    :return: True if they can be merged, False otherwise
    """
    assert second_node in graph.successors(first_node)
    if is_output_node(graph, first_node):
        return False
    return True


def merge_addition_addconst_add_pbs(graph: nx.DiGraph):
    """When we have
     pbs(add(addconst(x), y))
    the addconst() can be merged with the earlier add_const
    it's not such a big optimization, except for the fact that it can open way for more optimizations
    """
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=...)  # x
    old_pattern.add_node(1, op=...)  # y
    old_pattern.add_node(
        2, op=(Target_EncArray_AddWithConst, Target_EncArray_SubWithConstant)
    )  # addwithconst(x)
    old_pattern.add_node(3, op=Target_EncArrayEncArray_Add)  # add(addconst(x) + y)
    old_pattern.add_node(4, op=Target_EncArray_Pbs)
    old_pattern.add_edge(0, 2)
    old_pattern.add_edge(2, 3)
    old_pattern.add_edge(1, 3)
    old_pattern.add_edge(3, 4)

    # we'll make pbs(add(x, y))
    new_pattern = nx.DiGraph()
    new_pattern.add_node(0)
    new_pattern.add_node(1)
    new_pattern.add_node(2)
    new_pattern.add_node(3)
    new_pattern.add_edge(0, 2, weight=0)
    new_pattern.add_edge(1, 2, weight=1)
    new_pattern.add_edge(2, 3, weight=0)

    def handle_keep_0(node_dict):
        return node_dict[0]

    def handle_keep_1(node_dict):
        return node_dict[1]

    def handle_add(node_dict):
        old_add = node_dict[3]
        return Target_EncArrayEncArray_Add(
            old_add.input_shapes, old_add.output_shape, old_add.ir_source, old_add.dtype
        )

    def handle_pbs(node_dict):
        pbs = node_dict[4]
        old_const = node_dict[2]
        if isinstance(old_const, Target_EncArray_AddWithConst):
            constant = old_const.constant
        elif isinstance(old_const, Target_EncArray_SubWithConstant):
            constant = -old_const.constant
        else:
            raise TypeError
        new_func = lambda x, f=pbs.func, cst=constant: f(x + cst)
        inner_func = [
            FuncPropInvertible(lambda x, cst=constant: x - cst),
            FuncPropAffine(1, constant),
        ]
        func_properties = find_composite_properties(inner_func, pbs.func_properties)
        return Target_EncArray_Pbs(
            new_func,
            func_properties,
            pbs.input_shapes,
            pbs.output_shape,
            pbs.ir_source,
            pbs.dtype,
        )

    return pattern_rewrite(
        graph,
        old_pattern,
        new_pattern,
        {0: handle_keep_0, 1: handle_keep_1, 2: handle_add, 3: handle_pbs},
    )


def merge_mul_by_scalar_add_with_itself(graph: nx.DiGraph):
    """Merge x * c + x into (c+1) * x"""
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=...)
    old_pattern.add_node(1, op=Target_EncArray_MultByScalar)
    old_pattern.add_node(2, op=Target_EncArrayEncArray_Add)
    old_pattern.add_edge(0, 1)
    old_pattern.add_edge(1, 2)
    old_pattern.add_edge(0, 2)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0)
    new_pattern.add_node(1)
    new_pattern.add_edge(0, 1, weight=0)

    def handle_0(nodes_dict):
        return nodes_dict[0]

    def handle_mul(nodes_dict):
        mul_node = nodes_dict[1]
        return Target_EncArray_MultByScalar(
            mul_node.scalar + 1,
            mul_node.input_shapes,
            mul_node.output_shape,
            mul_node.ir_source,
            mul_node.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: handle_0, 1: handle_mul})


def merge_addition_linx_and_fx(graph: nx.DiGraph):
    """When we have
     add(op(x) + f(x)),
    we can express it as a univariate
     h(x) := op(x) + f(x)
    such that we have less PBS
    Here we apply it for ops negate, add_with_const, sub_with_const, mul_with_const
    """
    ops = (
        Target_EncArray_AddWithConst,
        Target_EncArray_MultByScalar,
        Target_EncArray_Negate,
        Target_EncArray_SubWithConstant,
    )
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=...)
    old_pattern.add_node(1, op=Target_EncArray_Pbs)
    old_pattern.add_node(2, op=ops)
    old_pattern.add_node(3, op=Target_EncArrayEncArray_Add)
    old_pattern.add_edge(0, 1)
    old_pattern.add_edge(0, 2)
    old_pattern.add_edge(2, 3)
    old_pattern.add_edge(1, 3)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0)
    new_pattern.add_node(1)
    new_pattern.add_edge(0, 1, weight=0)

    def handle_any(nodes_dict):
        return nodes_dict[0]

    def create_pbs(nodes_dict):
        pbs = nodes_dict[1]
        other_node = nodes_dict[2]
        if isinstance(other_node, Target_EncArray_Negate):
            new_func = lambda x, f=pbs.func: -x + f(x)
            lhs = [FuncPropAdditive(), FuncPropInvertible(lambda x: -x), FuncPropAffine(-1, 0)]
            func_properties = find_addition_properties(lhs, pbs.func_properties)
        elif isinstance(other_node, Target_EncArray_AddWithConst):
            new_func = lambda x, f=pbs.func, cst=other_node.constant: x + cst + f(x)
            lhs = [
                FuncPropAdditive(),
                FuncPropAffine(1, other_node.constant),
                FuncPropInvertible(lambda x, cst=other_node.constant: x - cst),
            ]
            func_properties = find_addition_properties(lhs, pbs.func_properties)
        elif isinstance(other_node, Target_EncArray_MultByScalar):
            new_func = lambda x, f=pbs.func, scalar=other_node.scalar: x * scalar + f(x)
            lhs = [
                FuncPropAdditive(),
                FuncPropAffine(other_node.scalar, 0),
                FuncPropInvertible(lambda x, scalar=other_node.scalar: x / scalar),
            ]
            func_properties = find_addition_properties(lhs, pbs.func_properties)
        elif isinstance(other_node, Target_EncArray_SubWithConstant):
            new_func = lambda x, f=pbs.func, cst=other_node.constant: x - cst + f(x)
            lhs = [
                FuncPropAdditive(),
                FuncPropAffine(1, -other_node.constant),
                FuncPropInvertible(lambda x, cst=other_node.constant: x + cst),
            ]
            func_properties = find_addition_properties(lhs, pbs.func_properties)
        else:
            raise TypeError
        return Target_EncArray_Pbs(
            new_func,
            func_properties,
            pbs.input_shapes,
            pbs.output_shape,
            pbs.ir_source,
            pbs.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: handle_any, 1: create_pbs})


def merge_addition_of_x_add_fx(graph: nx.DiGraph):
    """When we have
      add(x + f(x))
    we can express it as a univariate
      h(x) := x + f(x)
    such that we have less PBS
    """
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=...)
    old_pattern.add_node(1, op=Target_EncArray_Pbs)
    old_pattern.add_node(2, op=Target_EncArrayEncArray_Add)
    old_pattern.add_edge(0, 1)
    old_pattern.add_edge(0, 2)
    old_pattern.add_edge(1, 2)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0)
    new_pattern.add_node(1)
    new_pattern.add_edge(0, 1, weight=0)

    def handle_any(nodes_dict):
        return nodes_dict[0]

    def create_pbs(nodes_dict):
        old_pbs = nodes_dict[1]
        lhs = [FuncPropAdditive, FuncPropAffine(1, 0), FuncPropInvertible(lambda x: x)]
        func_properties = find_addition_properties(lhs, old_pbs.func_properties)

        return Target_EncArray_Pbs(
            lambda x, f=old_pbs.func: x + f(x),
            func_properties,
            old_pbs.input_shapes,
            old_pbs.output_shape,
            old_pbs.ir_source,
            old_pbs.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: handle_any, 1: create_pbs})


def merge_addition_of_pbs_with_single_predecessor(graph: nx.DiGraph):
    """When we have
     add(f(x) + g(x))
    we can express it as a univariate
     h(x) := f(x) + g(x)
    such that we have less PBS
    """
    for node in nx.topological_sort(graph):
        successors = [s for s in graph.successors(node)]
        pbs_successors = list(
            filter(
                lambda x: isinstance(x, Target_EncArray_Pbs) and not is_output_node(graph, x),
                successors,
            )
        )
        # we check if any 2 of those successors are succeded by the same addition node
        add_successor = {}
        for s in pbs_successors:
            suc = [s1 for s1 in graph.successors(s)]
            if len(suc) == 1 and isinstance(suc[0], Target_EncArrayEncArray_Add):
                if suc[0] not in add_successor.keys():
                    add_successor[suc[0]] = [s]
                else:
                    add_successor[suc[0]].append(s)
        for add_node, pbs_nodes in add_successor.items():
            if len(pbs_nodes) == 2:
                # means that one add has 2 pbs predecessors
                first_pbs = pbs_nodes[0]
                second_pbs = pbs_nodes[1]
                new_func = lambda x, f=first_pbs.func, g=second_pbs.func: f(x) + g(x)
                new_pbs = Target_EncArray_Pbs(
                    new_func,
                    # todo(Joao): add func properties
                    [],
                    [node.output_shape],
                    node.output_shape,
                    node.ir_source,
                    node.dtype,
                )
                lowest_weight = min(
                    graph.get_edge_data(node, first_pbs)["weight"],
                    graph.get_edge_data(node, second_pbs)["weight"],
                )
                graph.add_node(new_pbs)
                graph.add_edge(node, new_pbs, weight=lowest_weight)
                add_suc = [s for s in graph.successors(add_node)]
                add_w = [graph.get_edge_data(add_node, s)["weight"] for s in add_suc]
                for w, s in zip(add_w, add_suc):
                    graph.add_edge(new_pbs, s, weight=w)
                graph.remove_node(first_pbs)
                graph.remove_node(second_pbs)
                if is_output_node(graph, add_node):
                    replace_output(graph, add_node, new_pbs)
                graph.remove_node(add_node)
                return True
    return False


def remove_useless_broadcast(graph: nx.DiGraph):
    optimized = False
    for node in nx.topological_sort(graph):
        if (
            isinstance(node, Target_EncArray_Broadcast)
            and len(node.input_shapes[0]) == len(node.output_shape)
            and np.all(node.input_shapes[0].tolist() == node.output_shape)
            and not is_output_node(graph, node)
        ):
            pred = [p for p in graph.predecessors(node)]
            succ = [s for s in graph.successors(node)]
            succ_w = [graph.get_edge_data(node, s)["weight"] for s in succ]
            assert len(pred) == 1
            pred = pred[0]
            for w, s in zip(succ_w, succ):
                graph.add_edge(pred, s, weight=w)
            graph.remove_node(node)
            return True
    return False


def merge_pbs_and_mul_scalar(graph: nx.DiGraph):
    """A PBS followed by a single scalar multiplication can be reduced to a single
    PBS, by doing the scalar multiplication inside it.
    """
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_MultByScalar):
            predecessors = [p for p in graph.predecessors(node)]
            successors = [s for s in graph.successors(node)]
            if (
                len(predecessors) == 1
                and isinstance(predecessors[0], Target_EncArray_Pbs)
                and _can_merge(graph, predecessors[0], node)
            ):
                pbs = predecessors[0]
                old_func = pbs.func
                scalar = node.scalar
                func = lambda x, func=old_func, scalar=scalar: func(x) * scalar
                outer_prop = [
                    FuncPropAdditive(),
                    FuncPropAffine(scalar, 0),
                    FuncPropInvertible(lambda x: x / scalar),
                ]
                func_prop = find_composite_properties(pbs.func_properties, outer_prop)
                pbs.update_func(func, func_prop)
                # replicate edges
                for s in graph.successors(node):
                    edge_data = graph.get_edge_data(node, s, default={})
                    graph.add_edge(pbs, s, **edge_data)
                if is_output_node(graph, node):
                    replace_output(graph, node, pbs)
                # delete mul scalar node
                graph.remove_node(node)
                optimized = True
            elif (
                len(successors) == 1
                and isinstance(successors[0], Target_EncArray_Pbs)
                and _can_merge(graph, node, successors[0])
            ):
                pbs = successors[0]
                old_func = pbs.func
                scalar = node.scalar
                func = lambda x, func=old_func, scalar=scalar: func(x * scalar)
                inner_prop = [
                    FuncPropAdditive(),
                    FuncPropAffine(scalar, 0),
                    FuncPropInvertible(lambda x: x / scalar),
                ]
                func_prop = find_composite_properties(inner_prop, pbs.func_properties)
                pbs.update_func(func, func_prop)
                # replicate edges
                for p in graph.predecessors(node):
                    edge_data = graph.get_edge_data(p, node, default={})
                    graph.add_edge(p, pbs, **edge_data)
                # delete mul scalar node
                graph.remove_node(node)
                return True
    return False


def merge_pbs_and_neg(graph: nx.DiGraph):
    """
    A PBS and a negate node can be merged by doing:
    * F(-x) if NEG ---> PBS
    * -F(x) if PBS ---> NEG
    """
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_Negate):
            predecessors = [p for p in graph.predecessors(node)]
            successors = [s for s in graph.successors(node)]
            if (
                len(predecessors) == 1
                and isinstance(predecessors[0], Target_EncArray_Pbs)
                and _can_merge(graph, predecessors[0], node)
            ):
                pbs = predecessors[0]
                old_func = pbs.func
                func = lambda x, func=old_func: -func(x)
                outer_prop = [
                    FuncPropAdditive(),
                    FuncPropAffine(-1, 0),
                    FuncPropInvertible(lambda x: -x),
                ]
                func_prop = find_composite_properties(pbs.func_properties, outer_prop)
                pbs.update_func(func, func_prop)
                # replicate edges
                for s in graph.successors(node):
                    edge_data = graph.get_edge_data(node, s, default={})
                    graph.add_edge(pbs, s, **edge_data)
                if is_output_node(graph, node):
                    replace_output(graph, node, pbs)
                # delete mul scalar node
                graph.remove_node(node)
                return True
            elif (
                len(successors) == 1
                and isinstance(successors[0], Target_EncArray_Pbs)
                and _can_merge(graph, node, successors[0])
            ):
                pbs = successors[0]
                old_func = pbs.func
                func = lambda x, func=old_func: func(-x)
                inner_prop = [
                    FuncPropAdditive(),
                    FuncPropAffine(-1, 0),
                    FuncPropInvertible(lambda x: -x),
                ]
                func_prop = find_composite_properties(inner_prop, pbs.func_properties)
                pbs.update_func(func, func_prop)
                # replicate edges
                for p in graph.predecessors(node):
                    edge_data = graph.get_edge_data(p, node, default={})
                    graph.add_edge(p, pbs, **edge_data)
                # delete mul scalar node
                graph.remove_node(node)
                return True
    return False


def merge_add_or_sub_const_and_pbs(graph: nx.DiGraph):
    """A add or const followed by a single pbs can be reduced to a single
    PBS, by doing the const addition/subtraction inside it.
    """
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=(Target_EncArray_AddWithConst, Target_EncArray_SubWithConstant))
    old_pattern.add_node(1, op=Target_EncArray_Pbs)
    old_pattern.add_edge(0, 1)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0, attr=Target_EncArray_Pbs)

    def initializer_new_pbs(matching_nodes):
        add_or_sub = matching_nodes[0]
        pbs = matching_nodes[1]
        if isinstance(add_or_sub, Target_EncArray_AddWithConst):
            new_func = lambda x, f=pbs.func, cst=add_or_sub.constant: f(x + cst)
            add_properties = [
                FuncPropAffine(1, add_or_sub.constant),
                FuncPropInvertible(lambda x, cst=add_or_sub.constant: x - cst),
            ]
            func_properties = find_composite_properties(add_properties, pbs.func_properties)

        else:
            new_func = lambda x, f=pbs.func, cst=add_or_sub.constant: f(x - cst)
            add_properties = [
                FuncPropAffine(1, -add_or_sub.constant),
                FuncPropInvertible(lambda x, cst=add_or_sub.constant: x + cst),
            ]
            func_properties = find_composite_properties(add_properties, pbs.func_properties)
        return Target_EncArray_Pbs(
            new_func,
            func_properties,
            add_or_sub.input_shapes,
            pbs.output_shape,
            pbs.ir_source,
            pbs.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: initializer_new_pbs})


def merge_pbs_and_add_or_sub_const(graph: nx.DiGraph):
    """A PBS followed by a single const addition/subtraction can be reduced to a single
    PBS, by doing the const addition/subtraction inside it.
    """
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=Target_EncArray_Pbs)
    old_pattern.add_node(1, op=(Target_EncArray_AddWithConst, Target_EncArray_SubWithConstant))
    old_pattern.add_edge(0, 1)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0, attr=Target_EncArray_Pbs)

    def initializer_new_pbs(matching_nodes):
        pbs = matching_nodes[0]
        add_or_sub = matching_nodes[1]
        if isinstance(add_or_sub, Target_EncArray_AddWithConst):
            new_func = lambda x, f=pbs.func, cst=add_or_sub.constant: f(x) + cst
            add_properties = [
                FuncPropAffine(1, add_or_sub.constant),
                FuncPropInvertible(lambda x, cst=add_or_sub.constant: x - cst),
            ]
            func_properties = find_composite_properties(pbs.func_properties, add_properties)
        else:
            new_func = lambda x, f=pbs.func, cst=add_or_sub.constant: f(x) - cst
            add_properties = [
                FuncPropAffine(1, -add_or_sub.constant),
                FuncPropInvertible(lambda x, cst=add_or_sub.constant: x + cst),
            ]
            func_properties = find_composite_properties(pbs.func_properties, add_properties)
        return Target_EncArray_Pbs(
            new_func,
            func_properties,
            add_or_sub.input_shapes,
            pbs.output_shape,
            pbs.ir_source,
            pbs.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: initializer_new_pbs})


def merge_reshape_reshape(graph: nx.DiGraph):
    """Merge a sequence of two reshape nodes into a single reshape"""
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_Reshape):
            predecessors = [p for p in graph.predecessors(node)]
            if (
                len(predecessors) == 1
                and isinstance(predecessors[0], Target_EncArray_Reshape)
                and _can_merge(graph, predecessors[0], node)
            ):
                predecessor = predecessors[0]
                # check that predecessors is not an output node, and doesn't have other successors
                if (
                    is_output_node(graph, predecessor)
                    or len(list(graph.successors(predecessor))) > 1
                ):
                    return False
                # connect predecessor's predecessors to node
                pred_predecessors = [p for p in graph.predecessors(predecessor)]
                weights = [graph.get_edge_data(p, predecessor)["weight"] for p in pred_predecessors]
                for p, w in zip(pred_predecessors, weights):
                    graph.add_edge(p, node, weight=w)
                    graph.remove_edge(p, predecessor)
                graph.remove_edge(predecessor, node)
                graph.remove_node(predecessor)
                return True
    return False


def merge_pbs_pbs(graph: nx.DiGraph):
    """Merge the sequence of two PBS nodes as a single PBS"""
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=Target_EncArray_Pbs)
    old_pattern.add_node(1, op=Target_EncArray_Pbs)
    old_pattern.add_edge(0, 1)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0, attr=Target_EncArray_Pbs)

    def initializer_new_pbs(matching_nodes):
        inner_pbs = matching_nodes[0]
        outer_pbs = matching_nodes[1]
        func_properties = find_composite_properties(
            inner_pbs.func_properties, outer_pbs.func_properties
        )
        new_func = lambda x, f=outer_pbs.func, g=inner_pbs.func: f(g(x))
        return Target_EncArray_Pbs(
            new_func,
            func_properties,
            outer_pbs.input_shapes,
            inner_pbs.output_shape,
            outer_pbs.ir_source,
            outer_pbs.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: initializer_new_pbs})


def merge_broadcast_broadcast(graph: nx.DiGraph):
    """Merge the sequence of two broadcasts into a single one"""

    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=Target_EncArray_Broadcast)
    old_pattern.add_node(1, op=Target_EncArray_Broadcast)
    old_pattern.add_edge(0, 1)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0, attr=Target_EncArray_Broadcast)

    def initializer_new_broadcast(matching_nodes):
        first_broadcast = matching_nodes[0]
        second_broadcast = matching_nodes[1]
        return Target_EncArray_Broadcast(
            first_broadcast.input_shapes,
            second_broadcast.output_shape,
            first_broadcast.ir_source,
            first_broadcast.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: initializer_new_broadcast})


def optim_pbs_sum_pbs(graph: nx.DiGraph):
    """
    Convert a pbs->sum->pbs to pbs->pbs->sum or sum->pbs->pbs (pbs can later be merged),
    when the one of the pbs is additive
    """
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_Sum):
            successors = [s for s in graph.successors(node)]
            predecessors = [p for p in graph.predecessors(node)]
            if (
                len(successors) == 1
                and len(predecessors) == 1
                and isinstance(successors[0], Target_EncArray_Pbs)
                and isinstance(predecessors[0], Target_EncArray_Pbs)
                and not is_output_node(graph, node)
            ):
                first_pbs = predecessors[0]
                second_pbs = successors[0]
                # two cases: first pbs is additive, in which case we turn
                # first_pbs -> sum -> second_pbs
                # into
                # sum -> first_pbs -> second_pbs
                # (this is better because there are less items in array after sum)
                # if not, then second pbs can be additive, and we do
                # first_pbs -> second_pbs -> sum
                # where first_pbs and second_pbs will be merged
                if is_additive(first_pbs.func_properties):
                    switch_nodes(graph, first_pbs, node)
                    first_pbs.input_shapes = [node.output_shape]
                    first_pbs.output_shape = node.output_shape
                    return True
                elif is_additive(second_pbs.func_properties):
                    switch_nodes(graph, node, second_pbs)
                    second_pbs.input_shapes = [first_pbs.output_shape]
                    second_pbs.output_shape = first_pbs.output_shape
                    return True
    return False


def optim_pbs_noop_pbs(graph: nx.DiGraph):
    """
    Convert a pbs->no-op->pbs into a no-op->pbs->pbs (pbs can later be merged),
    when no-op is an operation that doesn't change the contents of the array,
    such as array manipulation
    """
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_Pbs):
            successor = find_closest_successor_condition(
                graph, node, lambda x: isinstance(x, Target_EncArray_Pbs)
            )
            if successor is not None:
                # found at least one following pbs
                # now, we need to check that every intermediate between this
                # pbs and the next is a noop
                if check_chain_satisfies_condition(
                    graph,
                    node,
                    successor,
                    lambda x: not x.changes_content() and not is_output_node(graph, x),
                ):
                    # then we have fist_pbs -> ... -> second_pbs,
                    # which can be transformed to ... -> first_pbs-> second_pbs
                    # allowing them to be merged
                    # send first_pbs to the end, instead of the opposite, to allow this
                    # optimization to happen even if second_pbs is an output node
                    first_pbs = node
                    second_pbs = successor
                    move_node_before_node(graph, first_pbs, second_pbs)
                    pred = list(graph.predecessors(first_pbs))[0]
                    first_pbs.input_shapes = [pred.output_shape]
                    first_pbs.output_shape = pred.output_shape
                    return True
    return False


def optim_pbs_add_pbs(graph: nx.DiGraph):
    """
    Convert a pbs->add->pbs to add->pbs->pbs (pbs can later be merged) where the content of add
    is inverted using the first pbs func
    """
    for node in nx.topological_sort(graph):
        if isinstance(node, (Target_EncArray_AddWithConstArray, Target_EncArray_AddWithConst)):
            successors = [s for s in graph.successors(node)]
            predecessors = [p for p in graph.predecessors(node)]
            if (
                len(successors) == 1
                and len(predecessors) == 1
                and isinstance(successors[0], Target_EncArray_Pbs)
                and isinstance(predecessors[0], Target_EncArray_Pbs)
                and is_additive(predecessors[0].func_properties)
                and is_invertible(predecessors[0].func_properties)
                and not is_output_node(graph, predecessors[0])
                and not is_output_node(graph, node)
            ):
                first_pbs = predecessors[0]
                second_pbs = successors[0]
                inv_func = get_inv_func(predecessors[0].func_properties)
                if isinstance(node, Target_EncArray_AddWithConstArray):
                    node.constant_array = inv_func(node.constant_array)
                else:  # AddWithConstant
                    node.constant = inv_func(node.constant)
                # switch add and first pbs
                for p in graph.predecessors(first_pbs):
                    edge_data = graph.get_edge_data(p, first_pbs, default={})
                    graph.add_edge(p, node, **edge_data)
                graph.remove_node(first_pbs)
                add_between_nodes(graph, node, second_pbs, first_pbs)
                return True
    return False


def merge_cst_add_add(graph: nx.DiGraph):
    """Merge the sequence of two constant add nodes as a single one"""

    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=Target_EncArray_AddWithConst)
    old_pattern.add_node(1, op=Target_EncArray_AddWithConst)
    old_pattern.add_edge(0, 1)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0, attr=Target_EncArray_AddWithConst)

    def initializer_new_add(matching_nodes):
        const_1 = matching_nodes[0]
        const_2 = matching_nodes[1]
        return Target_EncArray_AddWithConst(
            const_1.constant + const_2.constant,
            const_1.input_shapes,
            const_2.output_shape,
            const_1.ir_source,
            const_1.dtype,
        )

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: initializer_new_add})


def merge_scalar_mul_mul(graph: nx.DiGraph):
    """Merge the sequence of two scalar mul nodes as a single one"""
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_MultByScalar):
            successors = [s for s in graph.successors(node)]
            if (
                len(successors) == 1
                and isinstance(successors[0], Target_EncArray_MultByScalar)
                and _can_merge(graph, node, successors[0])
            ):
                next_mul = successors[0]
                node.scalar *= next_mul.scalar
                # replicate edges
                for s in graph.successors(next_mul):
                    edge_data = graph.get_edge_data(next_mul, s, default={})
                    graph.add_edge(node, s, **edge_data)
                if is_output_node(graph, next_mul):
                    replace_output(graph, next_mul, node)
                # delete mul scalar node
                graph.remove_node(next_mul)
                return True
    return False


def special_cst_value_bypass_add_sub(graph):
    optimized = False
    to_remove = []
    for node in nx.topological_sort(graph):
        if isinstance(node, (Target_EncArray_AddWithConst, Target_EncArray_SubWithConstant)):
            if node.constant == 0:
                predecessors = [p for p in graph.predecessors(node)]
                assert len(predecessors) == 1
                # replicate edges
                for s in graph.successors(node):
                    edge_data = graph.get_edge_data(node, s, default={})
                    graph.add_edge(predecessors[0], s, **edge_data)
                # delete constant (add/sub) node
                to_remove.append(node)
                optimized = True
                if is_output_node(graph, node):
                    replace_output(graph, node, predecessors[0])
    for r in to_remove:
        graph.remove_node(r)
    return optimized


def substitute_addition_with_itself(graph: nx.DiGraph):
    """Changes x + x for 2 * x, which can be merged more easily to other nodes"""
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArrayEncArray_Add):
            pred = list(graph.predecessors(node))
            if len(pred) == 1:
                unique_pred = pred[0]
                new_mul_by_2 = Target_EncArray_MultByScalar(
                    2,
                    [node.output_shape],
                    node.output_shape,
                    node.ir_source,
                    node.dtype,
                )
                graph.add_node(new_mul_by_2)
                graph.add_edge(unique_pred, new_mul_by_2, weight=0)
                suc = [s for s in graph.successors(node)]
                w_suc = [graph.get_edge_data(node, s)["weight"] for s in suc]
                for w, s in zip(w_suc, suc):
                    graph.add_edge(new_mul_by_2, s, weight=w)
                if is_output_node(graph, node):
                    replace_output(graph, node, new_mul_by_2)
                graph.remove_node(node)
                return True
    return False


def substitute_subtraction_with_itself(graph: nx.DiGraph):
    """Changes x - x for 0 * x, which can be merged more easily to other nodes"""
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArrayEncArray_Sub):
            pred = list(graph.predecessors(node))
            if len(pred) == 1:
                new_init_zero = Target_EncArray_InitConstArray(
                    np.zeros(node.output_shape),
                    [node.output_shape],
                    node.output_shape,
                    node.ir_source,
                    node.dtype,
                )
                graph.add_node(new_init_zero)
                suc = [s for s in graph.successors(node)]
                w_suc = [graph.get_edge_data(node, s)["weight"] for s in suc]
                for w, s in zip(w_suc, suc):
                    graph.add_edge(new_init_zero, s, weight=w)
                if is_output_node(graph, node):
                    replace_output(graph, node, new_init_zero)
                graph.remove_node(node)
                return True
    return False


def special_cst_value_bypass_mul(graph: nx.DiGraph):
    optimized = False
    to_remove = []
    for node in nx.topological_sort(graph):
        if isinstance(node, Target_EncArray_MultByScalar):
            if node.scalar == -1:
                # TODO: negate instead of mul (when RTE support it)
                pass
            elif node.scalar == 0:
                # replace with a plaintext of 0 (same shape)
                const_zero = Target_EncArray_InitConstArray(
                    np.zeros(node.output_shape),
                    node.input_shapes,
                    node.output_shape,
                    node.ir_source,
                    node.dtype,
                )
                substitute_node(graph, node, const_zero)
                pred = list(graph.predecessors(const_zero))
                # disconnect from predecessors (need to call remove_dead_nodes after)
                for p in pred:
                    graph.remove_edge(p, const_zero)
                optimized = True
            elif node.scalar == 1:
                predecessors = [p for p in graph.predecessors(node)]
                assert len(predecessors) == 1
                # replicate edges
                for s in graph.successors(node):
                    edge_data = graph.get_edge_data(node, s, default={})
                    graph.add_edge(predecessors[0], s, **edge_data)
                # delete constant mul node
                to_remove.append(node)
                optimized = True
                if is_output_node(graph, node):
                    replace_output(graph, node, predecessors[0])
    for r in to_remove:
        graph.remove_node(r)
    return optimized


def move_affine_pbs_to_encoding(graph: nx.DiGraph) -> bool:
    """
    If the PBS holds an affine transformation, we move that to the encoding of the previous node
    :param graph: graph to optimize
    :return: true if applied optimization
    """
    # list all outputs
    outputs = filter(
        lambda node: is_output_node(graph, node),
        graph.nodes(),
    )
    outputs = list(
        filter(
            lambda node: len(list(graph.successors(node))) == 0,
            outputs,
        )
    )

    for node in outputs:
        if isinstance(node, Target_EncArray_Pbs) and is_affine(node.func_properties):
            a, b = get_affine_parameters(node.func_properties)
            predecessors = list(graph.predecessors(node))
            assert len(predecessors) == 1
            predecessor = predecessors[0]
            delta = predecessor.output_encoding.delta
            offset = predecessor.output_encoding.offset
            new_offset = offset * a + b
            new_delta = delta * a
            predecessor.output_encoding = predecessor.output_encoding.copy_new_offset_delta(
                new_offset, new_delta
            )
            replace_output(graph, node, predecessor)
            graph.remove_edge(predecessor, node)
            return True

    return False


def move_correction_after_sum(graph: nx.DiGraph) -> bool:
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=TargetCorrectEncodingMulByArray)
    old_pattern.add_node(1, op=Target_EncArray_Sum)
    old_pattern.add_edge(0, 1)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0, op=Target_EncArray_Sum)
    new_pattern.add_node(1, op=TargetCorrectEncodingMulByArray)
    new_pattern.add_edge(0, 1, weight=0)

    def init_sum(matching_nodes):
        from copy import deepcopy

        old_sum = matching_nodes[1]
        new_sum = deepcopy(old_sum)
        return new_sum

    def init_correction(matching_nodes):
        from copy import deepcopy

        old_correction = matching_nodes[0]
        old_sum = matching_nodes[1]
        new_correction = deepcopy(old_correction)
        new_correction.encoded_correction = np.sum(
            old_correction.encoded_correction, axis=old_sum.axis
        )
        new_correction.input_shapes = [old_sum.output_shape]
        new_correction.output_shape = old_sum.output_shape
        return new_correction

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: init_sum, 1: init_correction})


def optimize_concretized_topology(graph: nx.DiGraph, artifacts: CompilationArtifacts):
    """
    Sometimes the graph will have corrections which can be simplified, so we apply those optimizations here
    :param target_graph:
    """
    optim_methods = [
        move_correction_after_sum,
        move_affine_pbs_to_encoding,
    ]

    apply_optimizations(graph, optim_methods, artifacts)

    remove_dead_nodes(graph)


def switch_sum_pbs(graph: nx.DiGraph) -> bool:
    """
    Switch pbs->sum for sum->pbs, which is faster since sum has less elements
    :param graph: graph to optimize
    :return: true if optimization was applied
    """
    old_pattern = nx.DiGraph()
    old_pattern.add_node(0, op=Target_EncArray_Pbs, cond=lambda x: is_additive(x.func_properties))
    old_pattern.add_node(1, op=Target_EncArray_Sum)
    old_pattern.add_edge(0, 1)

    new_pattern = nx.DiGraph()
    new_pattern.add_node(0)
    new_pattern.add_node(1)
    new_pattern.add_edge(0, 1, weight=0)

    def init_sum(matching_nodes):
        from copy import deepcopy

        return deepcopy(matching_nodes[1])

    def init_pbs(matching_nodes):
        pbs = matching_nodes[0]
        old_sum = matching_nodes[1]
        func = pbs.func
        properties = pbs.func_properties
        new_pbs = Target_EncArray_Pbs(
            func,
            properties,
            [old_sum.output_shape],
            old_sum.output_shape,
            pbs.ir_source,
            pbs.dtype,
        )
        return new_pbs

    return pattern_rewrite(graph, old_pattern, new_pattern, {0: init_sum, 1: init_pbs})


def optimize_topology(graph: nx.DiGraph, artifacts: CompilationArtifacts):

    optim_methods = [
        # merge functions return after doing a single merge due to graph update issues
        # so it's a necessity to call them as many time as they are still updating the graph
        # which is the work of the apply_optimizations functions
        merge_pbs_pbs,
        merge_pbs_and_neg,
        merge_pbs_and_mul_scalar,
        merge_pbs_and_add_or_sub_const,
        merge_add_or_sub_const_and_pbs,
        merge_addition_of_pbs_with_single_predecessor,
        merge_addition_of_x_add_fx,
        merge_reshape_reshape,
        merge_cst_add_add,
        merge_scalar_mul_mul,
        merge_broadcast_broadcast,
        merge_addition_linx_and_fx,
        merge_addition_addconst_add_pbs,
        merge_mul_by_scalar_add_with_itself,
        special_cst_value_bypass_add_sub,
        special_cst_value_bypass_mul,
        optim_pbs_add_pbs,
        optim_pbs_sum_pbs,
        optim_pbs_noop_pbs,
        remove_useless_broadcast,
        substitute_addition_with_itself,
        substitute_subtraction_with_itself,
        switch_sum_pbs,
    ]

    apply_optimizations(graph, optim_methods, artifacts)

    # if any optimizations left dead nodes
    remove_dead_nodes(graph)

    # this is one last optimization, which we know always improves running time: if we add a keyswitch
    # before each pbs, when the predecessors has not been through a pbs, we can reduce the ciphertext size
    # and therefore the complexity of the pbs
    add_keyswitch_before_pbs(graph)
