import math
from abc import ABC, abstractmethod

from .encoding import Encoder


class Bounds:
    def __init__(self):
        self.lower_bound = None
        self.upper_bound = None

    def update_lower_bound(self, lower):
        """
        Update lower bound with `min(previous_lower, lower)`
        :param lower: lower bound to update with if smaller than previous
        """
        if self.lower_bound is None:
            self.lower_bound = lower
        else:
            self.lower_bound = min(self.lower_bound, lower)

    def update_upper_bound(self, upper):
        """
        Update upper bound with `max(previous_upper, upper)`
        :param upper: upper bound to update with if greater than previous
        """
        if self.upper_bound is None:
            self.upper_bound = upper
        else:
            self.upper_bound = max(self.upper_bound, upper)

    def sync_with_graph(self, graph):
        """
        Compute the bounds of a graph of target nodes
        :param graph: the graph to sync with
        """
        # init global bounds
        self.lower_bound = None
        self.upper_bound = None
        for node in graph.nodes():
            self.update_lower_bound(node.output_lower_bound)
            self.update_upper_bound(node.output_upper_bound)

    def create_encoder(self, precision, padding):
        """
        Create encoder out of the computed bounds.

        :param precision: number of bits of precision to be used
        :param padding: number of bits of padding to be used
        :returns: encoder
        """
        self.margin = (self.upper_bound - self.lower_bound) / (2 ** precision - 1)
        offset = self.lower_bound
        delta = self.upper_bound - self.lower_bound + self.margin
        return Encoder(offset, delta, precision, padding)


class EncodingParameters:
    def __init__(self, offset, delta):
        self.offset = offset
        self.delta = delta


class NoiseParameters:
    def __init__(self, ctx, bsk, ksk):
        self.ctx = ctx
        self.bsk = bsk
        self.ksk = ksk
