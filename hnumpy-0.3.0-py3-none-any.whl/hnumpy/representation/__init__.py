"""Computation in hnumpy is represented using graphs. This computation graphs go through different
layers of representations to build an efficient graph, capable of processing encrypted data. The
difference between layers are the nodes composing the graph.

These are the different layers:
- Intermediate representation: Represent the input computation (that process plain data) to be
    compiled later to process encrypted data.
- Target representation: Represent the computation graph that will process the encrypted data.
- RTE representation: This will just translate the target representation to a format that the RTE
    can execute.
"""
from .target import Target_ClearArray_Input, Target_EncArray_Input

OUTPUT_NUM = "output_num"


def set_outputs(graph, *outputs):
    """
    Tag output nodes with the order they came in
    :param graph: graph to use
    :param outputs: list of output nodes to tag as output
    """
    for num, o in enumerate(outputs):
        graph.nodes[o][OUTPUT_NUM] = num


def replace_output(graph, old_out, new_out):
    """
    Move the output tag from old_out to new_out
    :param graph: graph to use
    :param old_out: old node tagged as output
    :param new_out: new node to tag as output
    """
    if not is_output_node(graph, old_out):
        raise ValueError("can't replace output from a node that isn't already an output")
    graph.nodes[new_out][OUTPUT_NUM] = graph.nodes[old_out][OUTPUT_NUM]
    graph.nodes[old_out][OUTPUT_NUM] = None


def get_ordered_inputs(graph):
    """
    Get output nodes based on nodes' data
    :param graph: the graph to get output from
    :return: list of output nodes
    """
    inputs = []
    order = {}
    for node in graph.nodes():
        if is_input_node(node):
            inputs.append(node)
            order[node] = node.input_num
    inputs = sorted(inputs, key=lambda x: order[x])
    return inputs


def get_ordered_outputs(graph):
    """
    Get output nodes based on nodes' data
    :param graph: the graph to get output from
    :return: list of output nodes
    """
    outputs = []
    order = {}
    for node in graph.nodes():
        if is_output_node(graph, node):
            outputs.append(node)
            order[node] = graph.nodes[node][OUTPUT_NUM]
    outputs = sorted(outputs, key=lambda x: order[x])
    return outputs


def is_output_node(graph, node):
    """
    Check if a node is an output node
    :param graph: graph to use
    :param node: node to check
    :return: True if the node is an output, False if it's not
    """
    if graph.nodes[node].get(OUTPUT_NUM, None) is None:
        return False
    return True


def is_input_node(node):
    """
    Check if a node is an input node
    :param node: node to check
    :return: True if the node is an output, False if it's not
    """
    return isinstance(node, (Target_ClearArray_Input, Target_EncArray_Input))
