"""Intermediate representation layer."""

import uuid
from abc import ABC


class IntermediateNode(ABC):
    def __init__(self, dtypes):
        self.unique_id = str(uuid.uuid4())
        self.dtypes = dtypes


class ClearArray_Input(IntermediateNode):
    """
    Cleartext array input
    """

    def __init__(self, input_num, dtypes, input_bounds=None):
        IntermediateNode.__init__(self, dtypes)
        self.input_num = input_num
        self.input_bounds = input_bounds

    def __str__(self):
        return "Input"


class EncArray_Input(IntermediateNode):
    """
    Encrypted array input
    """

    def __init__(self, input_num, dtypes, input_bounds=None):
        IntermediateNode.__init__(self, dtypes)
        self.input_num = input_num
        self.input_bounds = input_bounds

    def __str__(self):
        return "Input"


class EncArrayEncArray_SetItemWithConstExprIndex(IntermediateNode):
    """
    Sets an item of the array to the value of another array
    """

    def __init__(self, obj, py_obj, dtype):
        IntermediateNode.__init__(self, dtype)
        self.obj = obj
        self.py_obj = py_obj

    def __str__(self):
        return "SetItem"


class EncArray_InitConstArray(IntermediateNode):
    """
    Initializes an encrypted array with some constant values
    """

    def __init__(self, arr, dtype):
        IntermediateNode.__init__(self, dtype)
        self.arr = arr

    def __str__(self):
        return "InitConstArray"


class EncArray_Sum(IntermediateNode):
    """
    Sum elements of encrypted array
    """

    def __init__(self, axis, dtype):
        IntermediateNode.__init__(self, dtype)
        self.axis = axis

    def __str__(self):
        return "Sum"


class EncArray_Mean(IntermediateNode):
    """
    Mean (average) of encrypted array
    """

    def __init__(self, axis, dtype):
        IntermediateNode.__init__(self, dtype)
        self.axis = axis

    def __str__(self):
        return "Mean"


class EncArrayConstExprScalar_Maximum(IntermediateNode):
    def __init__(self, constexpr_scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.constexpr_scalar = constexpr_scalar

    def __str__(self):
        return "Maximum"


class EncArrayClearConstExprScalar_Mul(IntermediateNode):
    def __init__(self, constexpr_scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.constexpr_scalar = constexpr_scalar

    def __str__(self):
        return "Mul"


class EncArrayClearConstExprScalar_Add(IntermediateNode):
    def __init__(self, constexpr_scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.constexpr_scalar = constexpr_scalar

    def __str__(self):
        return "Add"


class EncArrayClearConstExprScalar_Sub(IntermediateNode):
    def __init__(self, constexpr_scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.constexpr_scalar = constexpr_scalar

    def __str__(self):
        return "Sub"


class EncArrayClearConstExprScalar_Pow(IntermediateNode):
    def __init__(self, power, dtype):
        IntermediateNode.__init__(self, dtype)
        self.power = power

    def __str__(self):
        return "Pow"


class EncArrayClearConstExprScalar_Mod(IntermediateNode):
    def __init__(self, modulo, dtype):
        IntermediateNode.__init__(self, dtype)
        self.modulo = modulo

    def __str__(self):
        return "Mod"


class EncArray_Copy(IntermediateNode):
    """
    Simply copies the input to the output
    """

    def __str__(self):
        return "Copy"


class EncArray_Flatten(IntermediateNode):
    """
    Flattens the array into a 1-D array with same number of elements
    """

    def __str__(self):
        return "Flatten"


class EncArray_Abs(IntermediateNode):
    """
    Computes the absolute values of an array X
    """

    def __str__(self):
        return "Abs"


class EncArrayClearArray_Matmul(IntermediateNode):
    """
    Matrix multiplication between an encrypted array and a cleartext array
    """

    def __str__(self):
        return "Matmul"


class EncArrayEncArray_Matmul(IntermediateNode):
    """
    Matrix multiplication between two encrypted arrays
    """

    def __str__(self):
        return "Matmul"


class ClearConstArrayEncArray_Matmul(IntermediateNode):
    def __init__(self, content, dtype):
        IntermediateNode.__init__(self, dtype)
        self.content = content

    def __str__(self):
        return "Matmul"


class EncArrayClearConstArray_Matmul(IntermediateNode):
    def __init__(self, content, dtype):
        IntermediateNode.__init__(self, dtype)
        self.content = content

    def __str__(self):
        return "Matmul"


class EncArray_Round(IntermediateNode):
    """
    Round operations on elements of an array
    """

    def __str__(self):
        return "Round"


class EncArray_Clip(IntermediateNode):
    """
    Clip values of array to stay between a_min, a_max
    """

    def __init__(self, a_min, a_max, dtype):
        IntermediateNode.__init__(self, dtype)
        self.a_min = a_min
        self.a_max = a_max

    def __str__(self):
        return "Clip"


class EncArray_Apply(IntermediateNode):
    """
    Applies some arbitrary function element-wise
    """

    def __init__(self, func, dtype):
        IntermediateNode.__init__(self, dtype)
        self.func = func

    def __str__(self):
        return "Apply"


class EncArray_Reshape(IntermediateNode):
    """
    Reshapes the array into new shape
    """

    def __str__(self):
        return "Reshape"


class EncArray_Slice(IntermediateNode):
    """
    Creates a copy of the slice
    """

    def __init__(self, orig_slice, pyslice, dtype):
        IntermediateNode.__init__(self, dtype)
        self.orig_slice = orig_slice
        self.pyslice = pyslice

    def __str__(self):
        return "Slice"


class EncArray_FancyIndex(IntermediateNode):
    """
    Creates a copy of the slice
    """

    def __init__(self, original, processed, dtype):
        IntermediateNode.__init__(self, dtype)
        self.original = original
        self.processed = processed

    def __str__(self):
        return "FancyIndex"


class EncArray_Resize(IntermediateNode):
    """
    Resizes array into new shape
    """

    def __str__(self):
        return "Resize"


class EncArray_Concatenate(IntermediateNode):
    """
    Concatenates arbitrary number of arrays
    """

    def __init__(self, axis, dtype):
        IntermediateNode.__init__(self, dtype)
        self.axis = axis

    def __str__(self):
        return "Concatenate"


class EncArray_BroadcastTo(IntermediateNode):
    """
    Broadcasts an array into a new shape
    """

    def __str__(self):
        return "BroadcastTo"


class ClearConstArrayEncArray_Cross(IntermediateNode):
    """
    Cross product
    """

    def __init__(self, content, dtype):
        IntermediateNode.__init__(self, dtype)
        self.content = content

    def __str__(self):
        return "Cross"


class EncArrayClearConstArray_Cross(IntermediateNode):
    """
    Cross product
    """

    def __init__(self, content, dtype):
        IntermediateNode.__init__(self, dtype)
        self.content = content

    def __str__(self):
        return "Cross"


class EncArrayClearConstArray_Dot1d(IntermediateNode):
    """
    Dot product between 1-D arrays
    """

    def __init__(self, content, dtype):
        IntermediateNode.__init__(self, dtype)
        self.content = content

    def __str__(self):
        return "Dot1d"


class ClearConstArrayEncArray_Dot2d(IntermediateNode):
    """
    Dot product between plaintext 2-D matrix and 1-D plaintext array
    """

    def __init__(self, content, dtype):
        IntermediateNode.__init__(self, dtype)
        self.content = content

    def __str__(self):
        return "Dot2d"


class EncArrayClearConstArray_Dot2d(IntermediateNode):
    """
    Dot product between encrypted 1-D array and plaintext 2-D matrix
    """

    def __init__(self, content, dtype):
        IntermediateNode.__init__(self, dtype)
        self.content = content

    def __str__(self):
        return "Dot2d"


class EncArrayEncArray_Add(IntermediateNode):
    """
    Addition of two encrypted arrays
    """

    def __str__(self):
        return "Add"


class ClearConstExprScalarEncArray_Pow(IntermediateNode):
    def __init__(self, base, dtype):
        IntermediateNode.__init__(self, dtype)
        self.base = base

    def __str__(self):
        return "Pow"


class EncArrayEncArray_Sub(IntermediateNode):
    """
    Subtraction between encrypted arrays
    """

    def __str__(self):
        return "Sub"


class ConstScalarEncArray_TrueDiv(IntermediateNode):
    """
    True division of a constant (literal) scalar by an encrypted array
    Equivalent to Python's / operator
    """

    def __init__(self, scalar, dtypes):
        IntermediateNode.__init__(self, dtypes)
        self.scalar = scalar

    def __str__(self):
        return "Div"

    pass


class EncArrayConstScalar_TrueDiv(IntermediateNode):
    """
    True division of an encrypted array by a constant (literal) scalar
    Equivalent to Python's / operator
    """

    def __init__(self, scalar, dtypes):
        IntermediateNode.__init__(self, dtypes)
        self.scalar = scalar

    def __str__(self):
        return "Div"

    pass


class EncArrayClearArray_Add(IntermediateNode):
    """
    Addition between encrypted and cleartext array
    """

    pass


class EncArrayClearArray_Sub(IntermediateNode):
    """
    Subtraction between encrypted and cleartext array
    """

    pass


class EncArrayConstClearArray_Add(IntermediateNode):
    """
    Addition between encrypted and constant array
    """

    def __init__(self, const_array, dtypes):
        IntermediateNode.__init__(self, dtypes)
        self.const_array = const_array

    def __str__(self):
        return "Add"


class EncArrayConstClearArray_Sub(IntermediateNode):
    """
    Subtraction between encrypted and constant array
    """

    def __init__(self, const_array, dtype):
        IntermediateNode.__init__(self, dtype)
        self.const_array = const_array

    def __str__(self):
        return "Sub"


class EncArrayEncArray_Mul(IntermediateNode):
    """
    Element-wise multiplication between encrypted arrays
    """

    def __str__(self):
        return "Mul"


class EncArrayClearConstArray_Mul(IntermediateNode):
    """
    Element-wise multiplication between encrypted and cleartext arrays
    """

    def __init__(self, const_array, dtype):
        IntermediateNode.__init__(self, dtype)
        self.const_array = const_array

    def __str__(self):
        return "MulByArray"


class EncArrayEncArray_Div(IntermediateNode):
    """Divides array elements element-wise"""

    pass


class EncArrayClearArray_Div(IntermediateNode):
    """Divides array elements element-wise"""

    pass


class EncArrayEncArray_LogAddExp(IntermediateNode):
    pass


class EncArrayClearArray_LogAddExp(IntermediateNode):
    pass


class EncArrayEncArray_LogAddExp2(IntermediateNode):
    pass


class EncArrayClearArray_LogAddExp2(IntermediateNode):
    pass


class EncArrayEncArray_TrueDiv(IntermediateNode):
    pass


class EncArrayClearArray_TrueDiv(IntermediateNode):
    pass


class EncArrayEncArray_FloorDiv(IntermediateNode):
    pass


class EncArrayClearArray_FloorDiv(IntermediateNode):
    pass


class EncArray_Transpose(IntermediateNode):
    """
    Transposes an array
    """

    def __init__(self, axes, dtype):
        IntermediateNode.__init__(self, dtype)
        self.axes = axes

    def __str__(self):
        return "Transpose"


class EncArray_Negative(IntermediateNode):
    """
    Negates the contents of an array
    """

    def __str__(self):
        return "Negative"


class ClearArray_Negative(IntermediateNode):
    pass


class EncArrayClearArray_Power(IntermediateNode):
    pass


class EncArrayEncArray_Power(IntermediateNode):
    pass


class EncArrayClearArray_FloatPower(IntermediateNode):
    pass


class EncArrayEncArray_FloatPower(IntermediateNode):
    pass


class EncArrayClearArray_Reminder(IntermediateNode):
    pass


class EncArrayEncArray_Reminder(IntermediateNode):
    pass


class EncArray_Mod(IntermediateNode):
    pass


class ClearArray_Mod(IntermediateNode):
    pass


class EncArray_Fmod(IntermediateNode):
    pass


class ClearArray_Fmod(IntermediateNode):
    pass


class EncArray_DivMod(IntermediateNode):
    pass


class ClearArray_DivMod(IntermediateNode):
    pass


class EncArray_Rint(IntermediateNode):
    pass


class ClearArray_Rint(IntermediateNode):
    pass


class EncArray_Sign(IntermediateNode):
    pass


class EncArray_i0(IntermediateNode):
    """
    Modified Bessel function of the first kind, order 0, applied element-wise
    """

    def __str__(self):
        return "i0"


class ClearArray_Sign(IntermediateNode):
    pass


class EncArray_Heaviside(IntermediateNode):
    pass


class ClearArray_Heaviside(IntermediateNode):
    pass


class EncArray_Conj(IntermediateNode):
    pass


class ClearArray_Conj(IntermediateNode):
    pass


class EncArray_Exp(IntermediateNode):
    """
    Exponential of encrypted array
    """

    def __str__(self):
        return "Exp"


class ClearArray_Exp(IntermediateNode):
    pass


class EncArray_Exp2(IntermediateNode):
    pass


class ClearArray_Exp2(IntermediateNode):
    pass


class EncArray_Log(IntermediateNode):
    pass


class ClearArray_Log(IntermediateNode):
    pass


class EncArray_Log2(IntermediateNode):
    def __str__(self):
        return "Log2"


class ClearArray_Log2(IntermediateNode):
    pass


class EncArray_Log10(IntermediateNode):
    pass


class ClearArray_Log10(IntermediateNode):
    pass


class EncArray_Expm1(IntermediateNode):
    pass


class ClearArray_Expm1(IntermediateNode):
    pass


class EncArray_Sqrt(IntermediateNode):
    pass


class ClearArray_Sqrt(IntermediateNode):
    pass


class EncArray_Cbrt(IntermediateNode):
    """Cubic root"""


class ClearArray_Cbrt(IntermediateNode):
    pass


class EncArray_Reciprocal(IntermediateNode):
    pass


class ClearArray_Reciprocal(IntermediateNode):
    pass


class EncArray_Gcd(IntermediateNode):
    pass


class ClearArray_Gcd(IntermediateNode):
    pass


class EncArray_Lcm(IntermediateNode):
    pass


class ClearArray_Lcm(IntermediateNode):
    pass


###============Trigonometric function=======================


class EncArraySin(IntermediateNode):
    def __str__(self):
        return "sin"


class EncArrayCos(IntermediateNode):
    def __str__(self):
        return "cos"


class EncArrayTan(IntermediateNode):
    def __str__(self):
        return "tan"


class EncArrayArcSin(IntermediateNode):
    def __str__(self):
        return "arcsin"


class EncArrayArcCos(IntermediateNode):
    def __str__(self):
        return "arccos"


class EncArrayArcTan(IntermediateNode):
    def __str__(self):
        return "arctan"


class EncArrayArcTan2(IntermediateNode):
    def __str__(self):
        return "arctan2"


class EncArrayHypot(IntermediateNode):
    def __str__(self):
        return "hypot"


class EncArraySinh(IntermediateNode):
    def __str__(self):
        return "sinh"


class EncArrayCosh(IntermediateNode):
    def __str__(self):
        return "cosh"


class EncArrayTanh(IntermediateNode):
    def __str__(self):
        return "tanh"


class EncArrayArcSinh(IntermediateNode):
    def __str__(self):
        return "arcsinh"


class EncArrayArcCosh(IntermediateNode):
    def __str__(self):
        return "arccosh"


class EncArrayArcTanh(IntermediateNode):
    def __str__(self):
        return "arctanh"


class EncArrayDegrees(IntermediateNode):
    def __str__(self):
        return "degrees"


class EncArrayRadians(IntermediateNode):
    def __str__(self):
        return "radians"


class EncArrayDeg2Rad(IntermediateNode):
    def __str__(self):
        return "deg2rad"


class EncArrayRad2Deg(IntermediateNode):
    def __str__(self):
        return "rad2deg"


###============Bit-twiddling functions=======================


class EncArrayEncArray_BitwiseAnd(IntermediateNode):
    pass


class EncArrayEncArray_BitwiseOr(IntermediateNode):
    pass


class EncArrayEncArray_BitwiseXor(IntermediateNode):
    pass


class EncArrayEncArray_BitwiseNot(IntermediateNode):
    pass


class EncArrayEncArray_LeftShift(IntermediateNode):
    pass


class EncArrayEncArray_RightShift(IntermediateNode):
    pass


class EncArrayEncArray_Equal(IntermediateNode):
    """x == y where both x and y are encrypted arrays"""


class EncArrayEncArray_IsClose(IntermediateNode):
    """whether x is close to y where both x and y are encrypted arrays"""

    def __init__(self, atol, dtype):
        IntermediateNode.__init__(self, dtype)
        self.atol = atol


class EncArrayEncArray_Greater(IntermediateNode):
    """x > y where both x and y are encrypted arrays"""


class EncArrayEncArray_Less(IntermediateNode):
    """x < y where both x and y are encrypted arrays"""


class EncArrayEncArray_GreaterEqual(IntermediateNode):
    """x >= y where both x and y are encrypted arrays"""


class EncArrayEncArray_LessEqual(IntermediateNode):
    """x <= y where both x and y are encrypted arrays"""


class EncArrayConstExprScalar_Greater(IntermediateNode):
    """x > c, where x is an encrypted array and c is a plaintext scalar"""

    def __init__(self, scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.scalar = scalar


class EncArrayConstExprScalar_IsClose(IntermediateNode):
    """whether x is close to c, where x is an encrypted array and c is a plaintext scalar"""

    def __init__(self, scalar, atol, dtype):
        IntermediateNode.__init__(self, dtype)
        self.atol = atol
        self.scalar = scalar


class EncArrayConstExprScalar_GreaterEqual(IntermediateNode):
    """x >= c, where x is an encrypted array and c is a plaintext scalar"""

    def __init__(self, scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.scalar = scalar


class EncArrayConstExprScalar_LessEqual(IntermediateNode):
    """x <= c, where x is an encrypted array and c is a plaintext scalar"""

    def __init__(self, scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.scalar = scalar


class EncArrayConstExprScalar_Equal(IntermediateNode):
    """x == c, where x is an encrypted array and c is a plaintext scalar"""

    def __init__(self, scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.scalar = scalar


class EncArrayConstExprScalar_NotEqual(IntermediateNode):
    """x != c, where x is an encrypted array and c is a plaintext scalar"""

    def __init__(self, scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.scalar = scalar


class EncArrayConstExprScalar_Less(IntermediateNode):
    """x < c, where x is an encrypted array and c is a plaintext scalar"""

    def __init__(self, scalar, dtype):
        IntermediateNode.__init__(self, dtype)
        self.scalar = scalar


class EncArray_Not(IntermediateNode):
    """Inverse of boolean array"""


class EncArrayEncArray_NotEqual(IntermediateNode):
    pass


class EncArrayEncArray_LogicalAnd(IntermediateNode):
    pass


class EncArrayEncArray_LogicalOr(IntermediateNode):
    pass


class EncArrayEncArray_LogicalXor(IntermediateNode):
    pass


class EncArrayEncArray_LogicalNot(IntermediateNode):
    pass


class EncArrayEncArray_Maximum(IntermediateNode):
    pass


class EncArrayEncArray_Minimum(IntermediateNode):
    pass


class EncArrayEncArray_Fmax(IntermediateNode):
    pass


class EncArrayEncArray_Fmin(IntermediateNode):
    pass


### ========== floating functions ==============


class EncArray_IsFinite(IntermediateNode):
    pass


class EncArray_IsInf(IntermediateNode):
    pass


class EncArray_IsNan(IntermediateNode):
    pass


class EncArray_IsNat(IntermediateNode):
    pass


class EncArray_Fabs(IntermediateNode):
    pass


class EncArray_Signbit(IntermediateNode):
    pass


class EncArrayEncArray_Copysign(IntermediateNode):
    pass


class EncArrayEncArray_NextAfter(IntermediateNode):
    pass


class EncArray_Spacing(IntermediateNode):
    pass


class EncArray_Modf(IntermediateNode):
    pass


class EncArray_IdExp(IntermediateNode):
    pass


class EncArray_Frexp(IntermediateNode):
    pass


class EncArray_Floor(IntermediateNode):
    pass


class EncArray_Ceil(IntermediateNode):
    pass


class EncArray_Trunc(IntermediateNode):
    pass
