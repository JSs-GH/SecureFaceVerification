"""Translation from the intermediate to the target representation."""
from functools import reduce

import networkx as nx
import numpy as np

from ..arrays import EncryptedArray
from ..constants import NP_FLOAT_TYPES, NP_INT_TYPES
from ..encrypted_types import EncryptedBool, EncryptedUint2, mix_dtypes
from ..representation.target import *
from ..representation.target.pbs import (
    FuncPropAdditive,
    FuncPropAffine,
    FuncPropInvertible,
    FuncPropMonotonicDecreasing,
    FuncPropMonotonicIncreasing,
    FuncPropPeriodic,
)
from . import is_output_node, replace_output
from .intermediate import *
from .topology import add_after_node, substitute_node


def _predecessor_shapes(graph, node):
    """
    Returns a list of the shapes of the predecessors of `node`, in the correct order
    The ordering is necessary because some nodes (like concatenation) rely on a correct ordering of the inputs
    :param graph: graph in which node is inserted
    :param node: node for which predecessor shapes are wanted
    :return: list of predecessor shapes
    """
    predecessors = [p for p in graph.predecessors(node)]
    weights = [graph.get_edge_data(p, node)["weight"] for p in predecessors]
    sorted_predecessors = [predecessors[i] for i in weights]
    sorted_shapes = [numpy.array(p.output_shape, dtype=numpy.uint64) for p in sorted_predecessors]
    return sorted_shapes


def ea_cbrt(graph: nx.DiGraph, node: EncryptedArray):
    # todo(Joao): func properties
    func_properties = []
    pbs_with_lambda(graph, node, lambda x: np.cbrt(x))


def ea_cces_pow(graph, node):
    pbs_with_lambda(graph, node, lambda x: x ** node.computation.power)


def cces_ea_pow(graph, node):
    pbs_with_lambda(graph, node, lambda x: node.computation.base ** x)


def mod(graph, node):
    pbs_with_lambda(graph, node, lambda x: x % node.computation.modulo)


def enc_input(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    new_node = Target_EncArray_Input(
        node.computation.input_num,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    new_node.input_lower_bounds = [node.computation.input_bounds[0]]
    new_node.input_upper_bounds = [node.computation.input_bounds[1]]
    substitute_node(graph, node, new_node)


def enc_init(graph, node):
    new_init = Target_EncArray_InitConstArray(
        node.computation.arr, [], node.shape, node.computation.unique_id, node.dtype
    )
    substitute_node(graph, node, new_init)


def clear_input(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    new_node = Target_ClearArray_Input(
        node.computation.input_num,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    if node.computation.input_bounds is not None:
        new_node.input_lower_bounds = [node.computation.input_bounds[0]]
        new_node.input_upper_bounds = [node.computation.input_bounds[1]]
    substitute_node(graph, node, new_node)


def reshape(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    reshape_node = Target_EncArray_Reshape(
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, reshape_node)


def ea_concat(graph, node):
    concat_node = Target_EncArray_Concat(
        node.computation.axis,
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, concat_node)


def ea_broadcast_to(graph, node):
    broadcast_node = Target_EncArray_Broadcast(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, broadcast_node)


def ea_transpose(graph, node):
    transpose_node = Target_EncArray_Transpose(
        node.computation.axes,
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, transpose_node)


def ea_slice(graph, node):
    slice_node = Target_EncArray_Slice(
        node.computation.orig_slice,
        node.computation.pyslice,
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, slice_node)


def ea_fancy_index(graph, node):
    fancy_index_node = Target_EncArray_FancyIndex(
        node.computation.original,
        node.computation.processed,
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, fancy_index_node)


def add(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    if len(predecessor_shapes) == 1:
        # addition with itself, equivalent to multiplying by 2
        new_node = Target_EncArray_MultByScalar(
            2,
            predecessor_shapes,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        pred = list(graph.predecessors(node))[0]
        graph[pred][node]["weight"] = 0
        substitute_node(graph, node, new_node)
    elif len(predecessor_shapes) == 2:
        new_node = Target_EncArrayEncArray_Add(
            predecessor_shapes,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, new_node)
    else:
        raise ValueError(f"Invalid addition with {len(predecessor_shapes)} predecessors")


def add_with_const_array(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    new_node = Target_EncArray_AddWithConstArray(
        node.computation.const_array,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, new_node)


def sub_with_const_array(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    new_node = Target_EncArray_SubWithConstArray(
        node.computation.const_array,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, new_node)


def ea_ea_sub(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    if len(predecessor_shapes) == 1:
        # subtraction with itself, just need to add a zero node
        arr = np.zeros(node.shape)
        new_zeros = Target_EncArray_InitConstArray(
            arr, [], node.shape, node.computation.unique_id, node.dtype
        )
        # eliminate predecessor
        pred = list(graph.predecessors(node))[0]
        graph.remove_edge(pred, node)
        substitute_node(graph, node, new_zeros)
    else:
        new_sub = Target_EncArrayEncArray_Sub(
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, new_sub)


def ea_ea_mul(graph: nx.DiGraph, node: EncryptedArray):
    predecessors = list(graph.predecessors(node))
    if len(predecessors) == 1:
        # it means that predecessor is multiplied by itself, equivalent to squaring
        pred = list(graph.predecessors(node))[0]
        graph[pred][node]["weight"] = 0
        f_properties = [FuncPropMonotonicIncreasing(in_range=(0, np.inf))]
        pbs_with_lambda(graph, node, lambda x: x * x, f_properties=f_properties)
    elif len(predecessors) == 2:
        predecessor_shapes = _predecessor_shapes(graph, node)
        successors = list(graph.successors(node))
        weights = [graph.get_edge_data(node, successor)["weight"] for successor in successors]

        # here we're using 2 pbs to do
        # (a+b)** 2 / 4 - (a-b)**2 /4 == ab

        a_plus_b = Target_EncArrayEncArray_Add(
            predecessor_shapes,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        a_minus_b = Target_EncArrayEncArray_Sub(
            predecessor_shapes,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        pbs_plus = Target_EncArray_Pbs(
            lambda x: x ** 2 / 4,
            [],
            [node.shape],
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        pbs_minus = Target_EncArray_Pbs(
            lambda x: x ** 2 / 4,
            [],
            [node.shape],
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        final_sub = Target_EncArrayEncArray_Sub(
            [np.array(node.shape), np.array(node.shape)],
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        graph.add_node(a_plus_b)
        graph.add_node(a_minus_b)
        graph.add_node(pbs_plus)
        graph.add_node(pbs_minus)
        graph.add_node(final_sub)
        graph.add_edge(predecessors[0], a_plus_b, weight=0)
        graph.add_edge(predecessors[1], a_plus_b, weight=1)
        graph.add_edge(predecessors[0], a_minus_b, weight=0)
        graph.add_edge(predecessors[1], a_minus_b, weight=1)
        graph.add_edge(a_plus_b, pbs_plus, weight=0)
        graph.add_edge(a_minus_b, pbs_minus, weight=0)
        graph.add_edge(pbs_plus, final_sub, weight=0)
        graph.add_edge(pbs_minus, final_sub, weight=1)

        for successor, weight in zip(successors, weights):
            graph.add_edge(final_sub, successor, weight=weight)

        if is_output_node(graph, node):
            replace_output(graph, node, final_sub)

        graph.remove_node(node)
    else:
        raise ValueError(f"Multiplication has {len(predecessors)} predecessors")


def ea_abs(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.abs(x))


def mul_with_constexpr_array(graph: nx.DiGraph, node: EncryptedArray):
    arr_type = node.computation.const_array.dtype
    if arr_type in NP_INT_TYPES:
        mult_node = Target_EncArray_MultByArray(
            node.computation.const_array.astype(np.int64),
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, mult_node)
    elif arr_type in NP_FLOAT_TYPES:
        if node.dtype.is_exact():
            clear_array = node.dtype.cast_cleartext_tensor(node.computation.const_array)
            new_mul = Target_EncArray_MultByArray(
                clear_array,
                _predecessor_shapes(graph, node),
                node.shape,
                node.computation.unique_id,
                node.dtype,
            )
            substitute_node(graph, node, new_mul)
        else:
            new_delta = 2 ** node.dtype.bits_of_precision()
            old_delta = node.computation.const_array.max() - node.computation.const_array.min()
            if not math.isclose(old_delta, 0):
                rescale_by = new_delta / old_delta
            elif not math.isclose(node.computation.const_array.max(), 0):
                rescale_by = (
                    2 ** node.dtype.bits_of_precision() / node.computation.const_array.max()
                )
            else:
                rescale_by = 2 ** node.dtype.bits_of_precision()

            clear_array = np.rint(node.computation.const_array * rescale_by).astype(np.int64)

            new_mul = Target_EncArray_MultByArray(
                clear_array,
                _predecessor_shapes(graph, node),
                node.shape,
                node.computation.unique_id,
                node.dtype,
            )

            func = lambda x: (x / rescale_by)
            func_properties = [
                FuncPropAdditive(),
                FuncPropAffine(1 / rescale_by, 0),
                FuncPropInvertible(lambda x, rb=rescale_by: x * rb),
            ]

            pbs_predecessor_shape = [new_mul.output_shape]

            new_pbs = Target_EncArray_Pbs(
                func,
                func_properties,
                pbs_predecessor_shape,
                node.shape,
                node.computation.unique_id,
                node.dtype,
            )

            substitute_node(graph, node, new_mul)
            add_after_node(graph, new_mul, new_pbs)

            if is_output_node(graph, new_mul):
                replace_output(graph, new_mul, new_pbs)

    else:
        raise TypeError(f"Multiplication by array of unrecognized type ({arr_type})")


def mul_with_constexpr(graph, node):
    if isinstance(
        node.computation.constexpr_scalar,
        (int, NP_INT_TYPES),
    ):
        predecessor_shapes = _predecessor_shapes(graph, node)
        new_node = Target_EncArray_MultByScalar(
            node.computation.constexpr_scalar,
            predecessor_shapes,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, new_node)
    elif isinstance(node.computation.constexpr_scalar, (float, NP_FLOAT_TYPES)):
        func_prop = [
            FuncPropAdditive(),
            FuncPropAffine(node.computation.constexpr_scalar, 0),
            FuncPropInvertible(lambda x, c=node.computation.constexpr_scalar: x / c),
        ]
        if node.computation.constexpr_scalar > 0:
            func_prop += [
                FuncPropMonotonicIncreasing(in_range=(0, np.inf)),
                FuncPropMonotonicDecreasing(in_range=(-np.inf, 0)),
            ]
        elif node.computation.constexpr_scalar < 0:
            func_prop += [
                FuncPropMonotonicIncreasing(in_range=(-np.inf, 0)),
                FuncPropMonotonicDecreasing(in_range=(0, np.inf)),
            ]
        pbs_with_lambda(
            graph,
            node,
            lambda x: x * node.computation.constexpr_scalar,
            f_properties=func_prop,
        )
    else:
        raise TypeError(
            f"Multiplication by scalar of invalid type: {type(node.computation.constexpr_scalar)}"
        )


def setitem_with_constexpr(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    setitem = Target_EncArrayEncArray_SetItemWithConstExprIndex(
        node.computation.obj,
        node.computation.py_obj,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, setitem)


def add_with_constexpr(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)

    add = Target_EncArray_AddWithConst(
        node.computation.constexpr_scalar,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, add)


def sub_with_constexpr(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)

    sub = Target_EncArray_SubWithConstant(
        node.computation.constexpr_scalar,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, sub)


def matmul(graph, node):
    # first, let's discretize the clear array according to the expansion factor
    expansion_factor = 32  # todo(Joao): placeholder

    clear_nodes = list(
        filter(
            lambda n: not n.output_is_encrypted(),
            graph.predecessors(node),
        )
    )
    assert len(clear_nodes) == 1

    clear_node = clear_nodes[0]

    clear_node.expansion_factor = expansion_factor

    matmul_predecessor_shapes = _predecessor_shapes(graph, node)

    new_matmul = Target_EncArrayClearArray_Matmul(
        matmul_predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    func = lambda x: x / expansion_factor
    func_properties = [
        FuncPropAdditive(),
        FuncPropAffine(1 / expansion_factor, 0),
        FuncPropInvertible(lambda x, ef=expansion_factor: x * ef),
    ]

    pbs_predecessor_shape = [new_matmul.output_shape]

    new_pbs = Target_EncArray_Pbs(
        func,
        func_properties,
        pbs_predecessor_shape,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    substitute_node(graph, node, new_matmul)
    add_after_node(graph, new_matmul, new_pbs)
    if is_output_node(graph, new_matmul):
        replace_output(graph, new_matmul, new_pbs)


def cca_ea_cross(graph, node):
    ea_cca_cross(graph, node, side="left")


def ea_cca_cross(graph, node, side="right"):

    expansion_factor = 32  # todo(Joao): placeholder

    clear_array = numpy.rint(node.computation.content * expansion_factor).astype(numpy.int64)

    new_cross = Target_EncArrayClearConstArray_Cross(
        clear_array,
        side,
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    func = lambda x: x / expansion_factor
    func_properties = [
        FuncPropAdditive(),
        FuncPropAffine(1 / expansion_factor, 0),
        FuncPropInvertible(lambda x, ef=expansion_factor: x * ef),
    ]

    pbs_predecessor_shape = [new_cross.output_shape]

    new_pbs = Target_EncArray_Pbs(
        func,
        func_properties,
        pbs_predecessor_shape,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    substitute_node(graph, node, new_cross)
    add_after_node(graph, new_cross, new_pbs)

    if is_output_node(graph, new_cross):
        replace_output(graph, new_cross, new_pbs)


def ea_cca_dot1d(graph, node):

    if node.dtype.is_exact():
        content = node.dtype.cast_cleartext_tensor(node.computation.content)
        new_dot = Target_EncArrayClearConstArray_Dot1d(
            content,
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, new_dot)
    else:
        new_delta = 2 ** node.dtype.bits_of_precision()
        old_delta = node.computation.content.max() - node.computation.content.min()
        if not math.isclose(old_delta, 0):
            rescale_by = new_delta / old_delta
        elif not math.isclose(node.computation.content.max(), 0):
            rescale_by = 2 ** node.dtype.bits_of_precision() / node.computation.content.max()
        else:
            rescale_by = 2 ** node.dtype.bits_of_precision()

        clear_array = np.rint(node.computation.content * rescale_by).astype(np.int64)

        new_dot = Target_EncArrayClearConstArray_Dot1d(
            clear_array,
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        func = lambda x: (x / rescale_by)
        func_properties = [
            FuncPropAdditive(),
            FuncPropAffine(1 / rescale_by, 0),
            FuncPropInvertible(lambda x, rb=rescale_by: x * rb),
        ]

        pbs_predecessor_shape = [new_dot.output_shape]

        new_pbs = Target_EncArray_Pbs(
            func,
            func_properties,
            pbs_predecessor_shape,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        substitute_node(graph, node, new_dot)
        add_after_node(graph, new_dot, new_pbs)

        if is_output_node(graph, new_dot):
            replace_output(graph, new_dot, new_pbs)


def cca_ea_dot2d(graph, node):
    ea_cca_dot2d(graph, node, side="left")


def ea_cca_dot2d(graph, node, side="right"):
    if node.dtype.is_exact():
        content = node.dtype.cast_cleartext_tensor(node.computation.content)
        new_dot = Target_EncArrayClearConstArray_Dot2d(
            content,
            side,
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, new_dot)
    elif node.dtype.is_approximate():
        new_delta = 2 ** node.dtype.bits_of_precision()
        old_delta = node.computation.content.max() - node.computation.content.min()
        if not math.isclose(old_delta, 0):
            rescale_by = new_delta / old_delta
        elif not math.isclose(node.computation.content.max(), 0):
            rescale_by = 2 ** node.dtype.bits_of_precision() / node.computation.content.max()
        else:
            rescale_by = 2 ** node.dtype.bits_of_precision()

        clear_array = np.rint(node.computation.content * rescale_by).astype(np.int64)

        new_dot = Target_EncArrayClearConstArray_Dot2d(
            clear_array,
            side,
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, new_dot)

        func = lambda x: (x / rescale_by)
        func_properties = [
            FuncPropAdditive(),
            FuncPropAffine(1 / rescale_by, 0),
            FuncPropInvertible(lambda x, rb=rescale_by: x * rb),
        ]

        pbs_predecessor_shape = [new_dot.output_shape]

        new_pbs = Target_EncArray_Pbs(
            func,
            func_properties,
            pbs_predecessor_shape,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        add_after_node(graph, new_dot, new_pbs)

        if is_output_node(graph, new_dot):
            replace_output(graph, new_dot, new_pbs)
    else:
        raise TypeError(f"node dtype is neither exact nor approximate")


def ea_cca_matmul(graph, node):
    cca_ea_matmul(graph, node, clear_side="right")


def cca_ea_matmul(graph, node, clear_side="left"):

    if node.dtype.is_exact():
        content = node.dtype.cast_cleartext_tensor(node.computation.content)
        new_dot = Target_ClearConstArrayEncArray_Matmul(
            content,
            clear_side,
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )
        substitute_node(graph, node, new_dot)
    else:
        new_delta = 2 ** node.dtype.bits_of_precision()
        old_delta = node.computation.content.max() - node.computation.content.min()
        if not math.isclose(old_delta, 0):
            rescale_by = new_delta / old_delta
        elif not math.isclose(node.computation.content.max(), 0):
            rescale_by = 2 ** node.dtype.bits_of_precision() / node.computation.content.max()
        else:
            rescale_by = 2 ** node.dtype.bits_of_precision()

        clear_array = np.rint(node.computation.content * rescale_by).astype(np.int64)

        new_matmul = Target_ClearConstArrayEncArray_Matmul(
            clear_array,
            clear_side,
            _predecessor_shapes(graph, node),
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        func = lambda x: (x / rescale_by)
        func_properties = [
            FuncPropAdditive(),
            FuncPropAffine(1 / rescale_by, 0),
            FuncPropInvertible(lambda x, rb=rescale_by: x * rb),
        ]

        pbs_predecessor_shape = [new_matmul.output_shape]

        new_pbs = Target_EncArray_Pbs(
            func,
            func_properties,
            pbs_predecessor_shape,
            node.shape,
            node.computation.unique_id,
            node.dtype,
        )

        substitute_node(graph, node, new_matmul)
        add_after_node(graph, new_matmul, new_pbs)

        if is_output_node(graph, new_matmul):
            replace_output(graph, new_matmul, new_pbs)


def pbs_with_lambda(graph, node, f, f_properties=None):
    f_properties = [] if f_properties is None else f_properties
    predecessor_shapes = _predecessor_shapes(graph, node)
    pbs = Target_EncArray_Pbs(
        f,
        f_properties,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, pbs)


def negative(graph, node):
    negate = Target_EncArray_Negate(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, negate)


def exp(graph, node):
    f_properties = [
        FuncPropInvertible(lambda x: np.log(x)),
        FuncPropMonotonicIncreasing(in_range=(0, np.inf)),
    ]
    pbs_with_lambda(graph, node, lambda x: numpy.exp(x), f_properties=f_properties)


def sum(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    new_node = Target_EncArray_Sum(
        node.computation.axis,
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, new_node)


def mean(graph, node):
    new_sum = Target_EncArray_Sum(
        node.computation.axis,
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    pred_shape = list(graph.predecessors(node))[0].output_shape
    pred_size = reduce(lambda x, y: x * y, pred_shape)
    cur_size = reduce(lambda x, y: x * y, node.shape)

    scale = pred_size / cur_size

    func = lambda x: x / scale
    func_prop = [
        FuncPropAdditive(),
        FuncPropAffine(1 / scale, 0),
        FuncPropInvertible(lambda x, s=scale: s * x),
    ]

    new_pbs = Target_EncArray_Pbs(
        func,
        func_prop,
        numpy.array(node.shape).astype(numpy.uint64),
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    substitute_node(graph, node, new_sum)
    add_after_node(graph, new_sum, new_pbs)

    if is_output_node(graph, new_sum):
        replace_output(graph, new_sum, new_pbs)


def const_by_enc_true_div(graph, node):
    f_properties = [
        FuncPropMonotonicDecreasing(in_range=(-np.inf, 0)),
        FuncPropMonotonicDecreasing(in_range=(0, np.inf)),
    ]
    pbs_with_lambda(graph, node, lambda x: node.computation.scalar / x, f_properties=f_properties)


def enc_by_const_true_div(graph, node):
    func_prop = [
        FuncPropAdditive(),
        FuncPropAffine(1 / node.computation.scalar, 0),
        FuncPropInvertible(lambda x, c=node.computation.scalar: x * c),
    ]
    pbs_with_lambda(
        graph,
        node,
        lambda x: x / node.computation.scalar,
        f_properties=func_prop,
    )


def log(graph, node):
    # todo(Joao): need range in inverse
    func_prop = [
        FuncPropInvertible(lambda x: np.exp(x)),
        FuncPropMonotonicIncreasing(in_range=(0, np.inf)),
    ]
    pbs_with_lambda(graph, node, lambda x: numpy.log(x), f_properties=func_prop)


def log2(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.log2(x))


def log10(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.log10(x))


def i0(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.i0(x))


def enc_round(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.round(x))


def enc_floor(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.floor(x))


def enc_ceil(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.ceil(x))


def enc_trunc(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.trunc(x))


def max_with_constexpr(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.maximum(node.computation.constexpr_scalar, x))


###============Trigonometric function=======================


def sin(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.sin(x))


def cos(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.cos(x))


def tan(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.tan(x))


def arcsin(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.arcsin(x))


def arccos(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.arccos(x))


def arctan(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.arctan(x))


def arctan2(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.arctan2(x))


def hypot(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.hypot(x))


def sinh(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.sinh(x))


def cosh(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.cosh(x))


def tanh(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.tanh(x))


def arcsinh(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.arcsinh(x))


def arccosh(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.arccosh(x))


def arctanh(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.arctanh(x))


def deg2rad(graph, node):
    func_prop = [FuncPropAdditive(), FuncPropInvertible(lambda x: x / (numpy.pi / 180))]
    pbs_with_lambda(
        graph,
        node,
        lambda x: x * (numpy.pi / 180),
        f_properties=func_prop,
    )


def ea_ea_and(graph, node):
    assert isinstance(node.predecessors[0].dtype, EncryptedBool)
    assert isinstance(node.predecessors[1].dtype, EncryptedBool)

    new_add = Target_EncArrayEncArray_Add(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        EncryptedUint2(),
    )
    substitute_node(graph, node, new_add)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x >= 2).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_add, new_pbs)

    if is_output_node(graph, new_add):
        replace_output(graph, new_add, new_pbs)


def ea_ea_or(graph, node):
    assert isinstance(node.predecessors[0].dtype, EncryptedBool)
    assert isinstance(node.predecessors[1].dtype, EncryptedBool)

    new_add = Target_EncArrayEncArray_Add(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        EncryptedUint2(),
    )
    substitute_node(graph, node, new_add)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x >= 1).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_add, new_pbs)

    if is_output_node(graph, new_add):
        replace_output(graph, new_add, new_pbs)


def ea_ea_xor(graph, node):
    assert isinstance(node.predecessors[0].dtype, EncryptedBool)
    assert isinstance(node.predecessors[1].dtype, EncryptedBool)

    new_add = Target_EncArrayEncArray_Add(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        EncryptedUint2(),
    )
    substitute_node(graph, node, new_add)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x % 2),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_add, new_pbs)

    if is_output_node(graph, new_add):
        replace_output(graph, new_add, new_pbs)


def ea_ea_gt(graph, node):
    assert len(node.predecessors) == 2
    # a > b implemented as (a-b) > 0
    dtypes = (node.predecessors[0].dtype.as_signed(), node.predecessors[1].dtype.as_signed())
    new_sub = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        mix_dtypes(*dtypes),
    )
    substitute_node(graph, node, new_sub)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x > 0).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_sub, new_pbs)

    if is_output_node(graph, new_sub):
        replace_output(graph, new_sub, new_pbs)


def ea_ea_ge(graph, node):
    assert len(node.predecessors) == 2
    # a >= b implemented as (a-b) >= 0
    dtypes = (node.predecessors[0].dtype.as_signed(), node.predecessors[1].dtype.as_signed())
    new_sub = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        mix_dtypes(*dtypes),
    )
    substitute_node(graph, node, new_sub)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x.astype(np.int64) >= 0).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_sub, new_pbs)

    if is_output_node(graph, new_sub):
        replace_output(graph, new_sub, new_pbs)


def ea_ea_eq(graph, node):
    assert len(node.predecessors) == 2
    # a == b implemented as (a-b) == 0
    dtypes = (node.predecessors[0].dtype.as_signed(), node.predecessors[1].dtype.as_signed())
    new_sub = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        mix_dtypes(*dtypes),
    )
    substitute_node(graph, node, new_sub)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x.astype(np.int64) == 0).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_sub, new_pbs)

    if is_output_node(graph, new_sub):
        replace_output(graph, new_sub, new_pbs)


def ea_ea_ne(graph, node):
    assert len(node.predecessors) == 2
    # a == b implemented as (a-b) == 0
    dtypes = (node.predecessors[0].dtype.as_signed(), node.predecessors[1].dtype.as_signed())
    new_sub = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        mix_dtypes(*dtypes),
    )
    substitute_node(graph, node, new_sub)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x.astype(np.int64) != 0).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_sub, new_pbs)

    if is_output_node(graph, new_sub):
        replace_output(graph, new_sub, new_pbs)


def ea_ea_isclose(graph, node):
    assert len(node.predecessors) == 2
    # isclose(a, b) implemented as isclose((a-b), 0)
    dtypes = (node.predecessors[0].dtype.as_signed(), node.predecessors[1].dtype.as_signed())
    new_sub = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        mix_dtypes(*dtypes),
    )
    substitute_node(graph, node, new_sub)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (np.isclose(x.astype(np.int64), 0, atol=node.computation.atol)).astype(
            np.float64
        ),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_sub, new_pbs)

    if is_output_node(graph, new_sub):
        replace_output(graph, new_sub, new_pbs)


def ea_ea_lt(graph, node):
    assert len(node.predecessors) == 2
    # a < b implemented as (a-b) < 0
    dtypes = (node.predecessors[0].dtype.as_signed(), node.predecessors[1].dtype.as_signed())
    new_sub = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        mix_dtypes(*dtypes),
    )
    substitute_node(graph, node, new_sub)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x < 0).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_sub, new_pbs)

    if is_output_node(graph, new_sub):
        replace_output(graph, new_sub, new_pbs)


def ea_ea_le(graph, node):
    assert len(node.predecessors) == 2
    # a <= b implemented as (a-b) <= 0
    dtypes = (node.predecessors[0].dtype.as_signed(), node.predecessors[1].dtype.as_signed())
    new_sub = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        mix_dtypes(*dtypes),
    )
    substitute_node(graph, node, new_sub)

    new_pbs = Target_EncArray_Pbs(
        lambda x: (x.astype(np.int64) <= 0).astype(np.float64),
        [],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    add_after_node(graph, new_sub, new_pbs)

    if is_output_node(graph, new_sub):
        replace_output(graph, new_sub, new_pbs)


def ea_scalar_gt(graph, node):
    pbs_with_lambda(
        graph, node, lambda x, scalar=node.computation.scalar: (x > scalar).astype(np.float64), []
    )


def ea_scalar_ge(graph, node):
    pbs_with_lambda(
        graph,
        node,
        lambda x, scalar=node.computation.scalar: (x.astype(np.int64) >= scalar).astype(np.float64),
        [],
    )


def ea_scalar_lt(graph, node):
    pbs_with_lambda(
        graph, node, lambda x, scalar=node.computation.scalar: (x < scalar).astype(np.float64), []
    )


def ea_scalar_le(graph, node):
    pbs_with_lambda(
        graph,
        node,
        lambda x, scalar=node.computation.scalar: (x.astype(np.int64) <= scalar).astype(np.float64),
        [],
    )


def ea_scalar_eq(graph, node):
    pbs_with_lambda(
        graph,
        node,
        lambda x, scalar=node.computation.scalar: (x.astype(np.int64) == scalar).astype(np.float64),
        [],
    )


def ea_scalar_ne(graph, node):
    pbs_with_lambda(
        graph,
        node,
        lambda x, scalar=node.computation.scalar: (x.astype(np.int64) != scalar).astype(np.float64),
        [],
    )


def ea_scalar_isclose(graph, node):
    pbs_with_lambda(
        graph,
        node,
        lambda x, scalar=node.computation.scalar: (
            np.isclose(x.astype(np.int64), scalar, atol=node.computation.atol)
        ).astype(np.float64),
        [],
    )


def ea_ea_max(graph, node):
    if node.dtype.is_exact():
        intermediate_dtype = node.dtype.get_dtype_extra_bit()
        intermediate_dtype_signed = node.dtype.as_signed()
    else:
        intermediate_dtype = node.dtype
        intermediate_dtype_signed = node.dtype

    add_1 = Target_EncArrayEncArray_Add(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        intermediate_dtype,
    )

    sub_1 = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        intermediate_dtype_signed,
    )

    pbs_1 = Target_EncArray_Pbs(
        lambda x: abs(x),
        [
            FuncPropMonotonicIncreasing(in_range=(0, np.inf)),
            FuncPropMonotonicDecreasing(in_range=(-np.inf, 0)),
        ],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        intermediate_dtype,
    )

    add_2 = Target_EncArrayEncArray_Add(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        intermediate_dtype,
    )

    pbs_2 = Target_EncArray_Pbs(
        lambda x: x / 2,
        [
            FuncPropAffine(0.5, 0),
            FuncPropInvertible(lambda x: x * 2),
            FuncPropAdditive(),
            FuncPropMonotonicIncreasing(in_range=(-np.inf, np.inf)),
        ],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    predecessors = list(graph.predecessors(node))
    successors = list(graph.successors(node))
    weights = [graph.get_edge_data(node, successor)["weight"] for successor in successors]

    graph.add_node(add_1)
    graph.add_node(sub_1)
    graph.add_node(pbs_1)
    graph.add_node(add_2)
    graph.add_node(pbs_2)

    graph.add_edge(predecessors[0], add_1, weight=0)
    graph.add_edge(predecessors[1], add_1, weight=1)
    graph.add_edge(predecessors[0], sub_1, weight=0)
    graph.add_edge(predecessors[1], sub_1, weight=1)
    graph.add_edge(sub_1, pbs_1, weight=0)
    graph.add_edge(pbs_1, add_2, weight=0)
    graph.add_edge(add_1, add_2, weight=1)
    graph.add_edge(add_2, pbs_2, weight=0)

    for successor, weight in zip(successors, weights):
        graph.add_edge(pbs_2, successor, weight=weight)

    if is_output_node(graph, node):
        replace_output(graph, node, pbs_2)

    graph.remove_node(node)


def ea_ea_min(graph, node):
    if node.dtype.is_exact():
        intermediate_dtype = node.dtype.get_dtype_extra_bit()
        intermediate_dtype_signed = node.dtype.as_signed()
    else:
        intermediate_dtype = node.dtype
        intermediate_dtype_signed = node.dtype

    add_1 = Target_EncArrayEncArray_Add(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        intermediate_dtype,
    )

    sub_1 = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        intermediate_dtype_signed,
    )

    pbs_1 = Target_EncArray_Pbs(
        lambda x: abs(x),
        [
            FuncPropMonotonicIncreasing(in_range=(0, np.inf)),
            FuncPropMonotonicDecreasing(in_range=(-np.inf, 0)),
        ],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        intermediate_dtype,
    )

    sub_2 = Target_EncArrayEncArray_Sub(
        _predecessor_shapes(graph, node),
        node.shape,
        node.computation.unique_id,
        intermediate_dtype_signed,
    )

    pbs_2 = Target_EncArray_Pbs(
        lambda x: x / 2,
        [
            FuncPropAffine(0.5, 0),
            FuncPropInvertible(lambda x: x * 2),
            FuncPropAdditive(),
            FuncPropMonotonicIncreasing(in_range=(-np.inf, np.inf)),
        ],
        [node.shape],
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )

    predecessors = list(graph.predecessors(node))
    successors = list(graph.successors(node))
    weights = [graph.get_edge_data(node, successor)["weight"] for successor in successors]

    graph.add_node(add_1)
    graph.add_node(sub_1)
    graph.add_node(pbs_1)
    graph.add_node(sub_2)
    graph.add_node(pbs_2)

    graph.add_edge(predecessors[0], add_1, weight=0)
    graph.add_edge(predecessors[1], add_1, weight=1)
    graph.add_edge(predecessors[0], sub_1, weight=0)
    graph.add_edge(predecessors[1], sub_1, weight=1)
    graph.add_edge(sub_1, pbs_1, weight=0)
    graph.add_edge(add_1, sub_2, weight=0)
    graph.add_edge(pbs_1, sub_2, weight=1)
    graph.add_edge(sub_2, pbs_2, weight=0)

    for successor, weight in zip(successors, weights):
        graph.add_edge(pbs_2, successor, weight=weight)

    if is_output_node(graph, node):
        replace_output(graph, node, pbs_2)

    graph.remove_node(node)


def rad2deg(graph, node):
    func_prop = [FuncPropAdditive(), FuncPropInvertible(lambda x: x / (180 / numpy.pi))]
    pbs_with_lambda(
        graph,
        node,
        lambda x: x * (180 / numpy.pi),
        f_properties=func_prop,
    )


def radians(graph, node):
    deg2rad(graph, node)


def degrees(graph, node):
    rad2deg(graph, node)


def encarray_flatten(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    flatten_node = Target_EncArray_Flatten(
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, flatten_node)


def resize(graph, node):
    predecessor_shapes = _predecessor_shapes(graph, node)
    resize_node = Target_EncArray_Resize(
        predecessor_shapes,
        node.shape,
        node.computation.unique_id,
        node.dtype,
    )
    substitute_node(graph, node, resize_node)


def ea_clip(graph, node):
    pbs_with_lambda(
        graph,
        node,
        lambda x: numpy.minimum(node.computation.a_max, numpy.maximum(x, node.computation.a_min)),
    )


def ea_sign(graph, node):
    pbs_with_lambda(graph, node, lambda x: numpy.sign(x))


def ea_apply(graph, node):
    pbs_with_lambda(graph, node, lambda x: node.computation.func(x))


def ea_not(graph, node):
    pbs_with_lambda(graph, node, lambda x: ((~x.astype(np.bool)).astype(np.float64)), [])


INTERMEDIATE_TO_TARGET_MAPPING = {
    EncArray_Input: enc_input,
    EncArray_InitConstArray: enc_init,
    ClearArray_Input: clear_input,
    EncArray_Apply: ea_apply,
    # Math
    EncArrayEncArray_Add: add,
    EncArray_Abs: ea_abs,
    EncArray_Sum: sum,
    EncArray_Cbrt: ea_cbrt,
    EncArray_Mean: mean,
    EncArray_Negative: negative,
    EncArray_Exp: exp,
    EncArray_Log: log,
    EncArray_Log2: log2,
    EncArray_Log10: log10,
    EncArray_i0: i0,
    EncArray_Clip: ea_clip,
    EncArray_Sign: ea_sign,
    EncArrayClearConstExprScalar_Pow: ea_cces_pow,
    ClearConstExprScalarEncArray_Pow: cces_ea_pow,
    EncArrayClearConstExprScalar_Mod: mod,
    EncArrayEncArray_Sub: ea_ea_sub,
    ConstScalarEncArray_TrueDiv: const_by_enc_true_div,
    EncArrayConstScalar_TrueDiv: enc_by_const_true_div,
    EncArray_Round: enc_round,
    EncArray_Floor: enc_floor,
    EncArray_Ceil: enc_ceil,
    EncArray_Trunc: enc_trunc,
    EncArrayConstExprScalar_Maximum: max_with_constexpr,
    EncArrayClearConstExprScalar_Add: add_with_constexpr,
    EncArrayClearConstExprScalar_Sub: sub_with_constexpr,
    EncArrayClearConstExprScalar_Mul: mul_with_constexpr,
    EncArrayClearConstArray_Mul: mul_with_constexpr_array,
    EncArrayEncArray_Mul: ea_ea_mul,
    EncArrayConstClearArray_Add: add_with_const_array,
    EncArrayConstClearArray_Sub: sub_with_const_array,
    # Array manipulation
    EncArray_Reshape: reshape,
    EncArray_Resize: resize,
    EncArray_Flatten: encarray_flatten,
    EncArray_Transpose: ea_transpose,
    EncArray_Slice: ea_slice,
    EncArray_FancyIndex: ea_fancy_index,
    EncArray_Concatenate: ea_concat,
    EncArray_BroadcastTo: ea_broadcast_to,
    # Linear algebra
    EncArrayClearArray_Matmul: matmul,
    ClearConstArrayEncArray_Matmul: cca_ea_matmul,
    EncArrayClearConstArray_Matmul: ea_cca_matmul,
    ClearConstArrayEncArray_Cross: cca_ea_cross,
    EncArrayClearConstArray_Cross: ea_cca_cross,
    EncArrayClearConstArray_Dot1d: ea_cca_dot1d,
    ClearConstArrayEncArray_Dot2d: cca_ea_dot2d,
    EncArrayClearConstArray_Dot2d: ea_cca_dot2d,
    # Trigonometric functions
    EncArraySin: sin,
    EncArrayCos: cos,
    EncArrayTan: tan,
    EncArrayArcSin: arcsin,
    EncArrayArcCos: arccos,
    EncArrayArcTan: arctan,
    EncArrayArcTan2: arctan2,
    EncArrayHypot: hypot,
    EncArraySinh: sinh,
    EncArrayCosh: cosh,
    EncArrayTanh: tanh,
    EncArrayArcSinh: arcsinh,
    EncArrayArcCosh: arccosh,
    EncArrayArcTanh: arctanh,
    EncArrayDegrees: degrees,
    EncArrayRadians: radians,
    EncArrayDeg2Rad: deg2rad,
    EncArrayRad2Deg: rad2deg,
    EncArrayEncArray_SetItemWithConstExprIndex: setitem_with_constexpr,
    # Comparison
    EncArrayEncArray_IsClose: ea_ea_isclose,
    EncArrayEncArray_Equal: ea_ea_eq,
    EncArrayEncArray_NotEqual: ea_ea_ne,
    EncArrayEncArray_Greater: ea_ea_gt,
    EncArrayEncArray_GreaterEqual: ea_ea_ge,
    EncArrayEncArray_Less: ea_ea_lt,
    EncArrayEncArray_LessEqual: ea_ea_le,
    EncArrayConstExprScalar_Equal: ea_scalar_eq,
    EncArrayConstExprScalar_NotEqual: ea_scalar_ne,
    EncArrayConstExprScalar_IsClose: ea_scalar_isclose,
    EncArrayConstExprScalar_Greater: ea_scalar_gt,
    EncArrayConstExprScalar_GreaterEqual: ea_scalar_ge,
    EncArrayConstExprScalar_Less: ea_scalar_lt,
    EncArrayConstExprScalar_LessEqual: ea_scalar_le,
    EncArrayEncArray_Maximum: ea_ea_max,
    EncArrayEncArray_Minimum: ea_ea_min,
    # Bitwise operations
    EncArrayEncArray_BitwiseAnd: ea_ea_and,
    EncArrayEncArray_BitwiseOr: ea_ea_or,
    EncArrayEncArray_BitwiseXor: ea_ea_xor,
    EncArray_Not: ea_not,
}


def intermediate_to_target(graph, node):
    if type(node.computation) not in INTERMEDIATE_TO_TARGET_MAPPING:
        raise TypeError(f"Intermediate node {node.computation} doesn't have a target handler")
    fn = INTERMEDIATE_TO_TARGET_MAPPING[type(node.computation)]
    fn(graph, node)
