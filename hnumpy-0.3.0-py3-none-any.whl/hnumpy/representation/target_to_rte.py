"""Translation from the target to the RTE representation."""
import numpy as np
from zamavm import PyOperator

from ..representation.target import *


def generic_input(node):
    return PyOperator.input(node.output_shape, node.output_encryption_key.unique_id, node.unique_id)


def init_const_array(node):
    return PyOperator.init_const_array(
        node.encoded_arr,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def level_add(node):
    return PyOperator.level_add(
        node.output_shape, node.output_encryption_key.unique_id, node.unique_id
    )


def level_sub(node):
    return PyOperator.level_sub(
        node.output_shape, node.output_encryption_key.unique_id, node.unique_id
    )


def reshape(node: Target_EncArray_Reshape):
    return PyOperator.reshape(
        node.output_shape, node.output_encryption_key.unique_id, node.unique_id
    )


def broadcast(node: Target_EncArray_Broadcast):
    return PyOperator.broadcast(
        node.output_shape, node.output_encryption_key.unique_id, node.unique_id
    )


def concat(node):
    return PyOperator.concat(
        node.axis,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def transpose(node):
    return PyOperator.transpose(
        node.axes,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def ea_slice(node):
    return PyOperator.slice(
        node.pyslice,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def ea_fancy_index(node):
    return PyOperator.fancy_index(
        node.processed,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def flatten(node):
    return PyOperator.flatten(
        node.output_shape, node.output_encryption_key.unique_id, node.unique_id
    )


def negate(node):
    return PyOperator.negate(
        node.output_shape, node.output_encryption_key.unique_id, node.unique_id
    )


def resize(node):
    return PyOperator.resize(
        node.output_shape, node.output_encryption_key.unique_id, node.unique_id
    )


def matmul(node):
    # todo(Joao): fix keys, add matmul with non-const
    # return PyOperator.matmul("", node.output_shape, "encryption_key", "")
    pass


def cca_ea_matmul(node):
    if node.side == "left":
        return PyOperator.const_left_matmul(
            np.ascontiguousarray(node.encoded_content),
            node.output_shape,
            node.output_encryption_key.unique_id,
            node.unique_id,
        )
    elif node.side == "right":
        return PyOperator.const_right_matmul(
            np.ascontiguousarray(node.encoded_content),
            node.output_shape,
            node.output_encryption_key.unique_id,
            node.unique_id,
        )
    else:
        raise RuntimeError(f"Matmul clear side is unrecognized: {node.side}")


def cca_ea_cross(node):
    if node.side == "left":
        return PyOperator.left_cross(
            np.ascontiguousarray(node.content),
            node.output_shape,
            node.output_encryption_key.unique_id,
            node.unique_id,
        )
    elif node.side == "right":
        return PyOperator.right_cross(
            np.ascontiguousarray(node.content),
            node.output_shape,
            node.output_encryption_key.unique_id,
            node.unique_id,
        )
    else:
        raise RuntimeError(f"Cross clear side is unrecognized: {node.side}")


def cca_ea_dot2d(node):
    if node.side == "left":
        return PyOperator.dot2d_left_clear_matrix(
            np.ascontiguousarray(node.content),
            node.output_shape,
            node.output_encryption_key.unique_id,
            node.unique_id,
        )
    elif node.side == "right":
        return PyOperator.dot2d_right_clear_matrix(
            np.ascontiguousarray(node.content),
            node.output_shape,
            node.output_encryption_key.unique_id,
            node.unique_id,
        )
    else:
        raise RuntimeError(f"Dot2d clear side is unrecognized: {node.side}")


def cca_ea_dot1d(node):
    return PyOperator.dot1d(
        np.ascontiguousarray(node.content),
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def ea_sum(node):
    return PyOperator.sum(
        node.axis,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def pbs(node):
    return PyOperator.pbs(
        node.pbs_key.unique_id,
        node.test_vector,
        node.indexes,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def mult_by_array(node: Target_EncArray_MultByArray):
    return PyOperator.mult_by_array(
        node.arr,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def mult_by_scalar(node: Target_EncArray_MultByScalar):
    return PyOperator.mult_by_scalar(
        node.encoded_scalar,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def keyswitch(node):
    return PyOperator.keyswitch(
        node.ks_key.unique_id,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def add_with_const(node):
    return PyOperator.add_with_const_scalar(
        node.encoded_constant,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def add_with_const_array(node):
    return PyOperator.add_with_const_array(
        np.ascontiguousarray(node.encoded_constant_array),
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def sub_with_const(node):
    return PyOperator.sub_with_const_scalar(
        node.encoded_constant,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def sub_with_const_array(node):
    return PyOperator.sub_with_const_array(
        np.ascontiguousarray(node.encoded_constant_array),
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def setitem_with_constexpr_idx(node):
    return PyOperator.set_item(
        node.py_obj,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def correct_encoding_add(node):
    return PyOperator.add_with_const_scalar(
        node.encoded_correction,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def correct_encoding_matadd(node):
    return PyOperator.add_with_const_array(
        np.ascontiguousarray(node.encoded_correction),
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def correct_encoding_sub(node):
    return PyOperator.sub_with_const_scalar(
        node.encoded_correction,
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def correct_encoding_matsub(node):
    return PyOperator.sub_with_const_array(
        np.ascontiguousarray(node.encoded_correction),
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def correct_encoding_vecadd(node):
    return PyOperator.add_with_const_array(
        np.ascontiguousarray(node.encoded_correction),
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


def correct_encoding_vecsub(node):
    return PyOperator.sub_with_const_array(
        np.ascontiguousarray(node.encoded_correction),
        node.output_shape,
        node.output_encryption_key.unique_id,
        node.unique_id,
    )


TARGET_RTE_MAPPING = {
    Target_EncArray_Input: generic_input,
    Target_ClearArray_Input: generic_input,
    Target_EncArray_InitConstArray: init_const_array,
    Target_EncArrayEncArray_Add: level_add,
    Target_EncArray_AddWithConstArray: add_with_const_array,
    Target_EncArray_SubWithConstArray: sub_with_const_array,
    Target_EncArrayEncArray_Sub: level_sub,
    Target_EncArrayClearArray_Matmul: matmul,
    Target_ClearConstArrayEncArray_Matmul: cca_ea_matmul,
    Target_EncArray_Reshape: reshape,
    Target_EncArray_Broadcast: broadcast,
    Target_EncArray_Slice: ea_slice,
    Target_EncArray_FancyIndex: ea_fancy_index,
    Target_EncArray_Flatten: flatten,
    Target_EncArray_Resize: resize,
    Target_EncArray_Concat: concat,
    Target_EncArray_Negate: negate,
    Target_EncArray_Transpose: transpose,
    Target_EncArrayClearConstArray_Dot1d: cca_ea_dot1d,
    Target_EncArrayClearConstArray_Dot2d: cca_ea_dot2d,
    Target_EncArrayClearConstArray_Cross: cca_ea_cross,
    Target_EncArray_Sum: ea_sum,
    TargetCorrectEncodingAdd: correct_encoding_sub,
    TargetCorrectEncodingAddVec: correct_encoding_add,
    TargetCorrectEncodingConcat: correct_encoding_vecadd,
    TargetCorrectEncodingSub: correct_encoding_add,
    TargetCorrectEncodingSubVec: correct_encoding_add,
    TargetCorrectEncodingSum: correct_encoding_vecadd,
    TargetCorrectEncodingMul: correct_encoding_sub,
    TargetCorrectEncodingNeg: correct_encoding_add,
    TargetCorrectEncodingMatmul: correct_encoding_matadd,
    TargetCorrectEncodingCross: correct_encoding_vecadd,
    TargetCorrectEncodingDot1D: correct_encoding_vecadd,
    TargetCorrectEncodingDot2D: correct_encoding_vecadd,
    TargetCorrectEncodingAddWithConstScalar: correct_encoding_add,
    TargetCorrectEncodingSetItem: correct_encoding_matadd,
    TargetCorrectEncodingSubWithConstScalar: correct_encoding_add,
    TargetCorrectEncodingMulByArray: correct_encoding_matadd,
    TargetCorrectEncodingMulByScalar: correct_encoding_add,
    # Target_ClearArray_Discretize: discretize,
    Target_EncArray_Pbs: pbs,
    Target_EncArray_Keyswitch: keyswitch,
    Target_EncArray_MultByArray: mult_by_array,
    Target_EncArray_MultByScalar: mult_by_scalar,
    Target_EncArray_AddWithConst: add_with_const,
    Target_EncArray_SubWithConstant: sub_with_const,
    Target_EncArrayEncArray_SetItemWithConstExprIndex: setitem_with_constexpr_idx,
}


def get_operator(node):
    if type(node) not in TARGET_RTE_MAPPING:
        raise TypeError(f"Target node of type {type(node)} does not have an RTE conversion")
    fn = TARGET_RTE_MAPPING[type(node)]
    return fn(node)
