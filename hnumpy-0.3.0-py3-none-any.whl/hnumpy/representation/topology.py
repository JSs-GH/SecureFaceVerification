from collections import defaultdict
from typing import Any, Callable, Hashable, Iterable, List, Tuple

import networkx as nx

from ..representation.target import TargetNode
from . import is_output_node, replace_output


def trace_successors_into_subgraph(
    graph: nx.DiGraph,
    subgraph: nx.DiGraph,
    node: TargetNode,
    border_condition: Callable,
):
    """
    Adds all successors of `node` into sub-graph, as well as its edges, until one of them is a PBS
    :param graph: original graph
    :param subgraph: subgraph into which to add successors
    :param node: node whose successors we want to put into sub-graph
    :param border_condition: condition at which to stop including successors
    """
    for successor in graph.successors(node):
        if not border_condition(successor):
            subgraph.add_node(successor)
            subgraph.add_edge(node, successor)
            trace_successors_into_subgraph(graph, subgraph, successor, border_condition)


def connected_comp(lists: List[Iterable[Hashable]]):
    """
    from https://www.geeksforgeeks.org/python-merge-list-with-common-elements-in-a-list-of-lists/
    Generator function to get a list of lists, each element representing a connected component
    :param lists: the list holding the iterables for which to determine the connected components
    """
    neighbours = defaultdict(set)
    visited = set()
    for current_list in lists:
        for item in current_list:
            neighbours[item].update(current_list)

    def component(start_node, neighbours=neighbours, visited=visited, visit=visited.add):
        nodes = set([start_node])
        next_node = nodes.pop
        while nodes:
            node = next_node()
            visit(node)
            nodes |= neighbours[node] - visited
            yield node

    for node in neighbours:
        if node not in visited:
            yield sorted(component(node))


def unify_merges(to_merge: List[Tuple[Hashable, Hashable]]):
    """
    Takes a list of tuples containing pairs of indexes, and merges tuples until there is no index in
    more than one pair. For instance, [(2,3),(3,5),(4,7)] becomes [(2,3,5),(4,7)]
    :param to_merge: original list of tuples
    :return: list of merged tuples
    """

    return list(connected_comp(to_merge))


def merge_subgraphs(subgraphs: List[nx.DiGraph], to_merge: List[Tuple[int, int]]):
    """
    Takes a list of subgraphs and a list of pairs of indexes, and merges the sub-graphs at each pair,
    e.g., [(1,2), (3,4), (4,5)] will merge sub-graphs 1 and 2 into a single sub-graph, and sub-graphs
    3, 4, and 5 also into a single sub-graph, and return a list of them
    :param subgraphs: original sub-graphs to merge
    :param to_merge: list of indexes to merge
    :return: list of merged sub-graphs
    """
    # to_merge contains pairs, which can be like (2,3), (2,4), (3,4),
    # which, in this case, is more accurately expressed as (2,3,4), so we call
    # unify_merge() which does exactly that
    to_merge = unify_merges(to_merge)
    merged_subgraphs = []
    for sgs in to_merge:
        new_subgraph = nx.DiGraph()
        for sg in sgs:
            sg = subgraphs[sg]
            for node in sg.nodes():
                new_subgraph.add_node(node)
            for src, dst in sg.edges():
                new_subgraph.add_edge(src, dst)
        merged_subgraphs.append(new_subgraph)
    return merged_subgraphs


def divide_into_subgraphs(graph: nx.DiGraph, border_condition: Callable):
    """
    Finds independent subgraphs in graph bordered by `border_condition`, which should return True at nodes
    that must be at the beginning of the sub-graph and before the end of the sub-graph
    :param graph: target graph to divide
    :param border_condition: a function that returns True when the border condition is satisfied, i.e.,
                             when a subgraph should be delimited
    """

    subgraphs = []

    # find all nodes that can satisfy the border condition
    subgraph_starting_nodes = list(
        filter(
            border_condition,
            graph.nodes(),
        )
    )

    # for each node in graph that satisfies the condition, let's create a sub-graph that ends just before
    # another node satisfying the condition
    for node in subgraph_starting_nodes:
        subgraph = nx.DiGraph()
        subgraph.add_node(node)
        trace_successors_into_subgraph(graph, subgraph, node, border_condition)
        subgraphs.append(subgraph)

    # we want sub-graphs to be independent, that is, there is no node which is a part of more than one sub-graph;
    # to guarantee that, we take sub-graphs that share at least one node and fuse them together

    # create a set of nodes in each sub-graph just so we can check if a node is in the sub-graph in O(1)
    subgraph_nodes_sets = []
    for subgraph in subgraphs:
        subgraph_set = set()
        for node in subgraph.nodes():
            subgraph_set.add(node)
        subgraph_nodes_sets.append(subgraph_set)

    # create a list of tuples, where each tuple contains the index of the sub-graphs that need to be merged
    subgraphs_to_merge = []
    # isolated sub-graphs are ones that don't share any nodes with another sub-graph, this means that they
    # can be kept separately and added later
    isolated_subgraphs = []
    for sub_num, subgraph in enumerate(subgraphs):
        # keep track if the sub-graph was merged somewhere; if not, then it's an isolated sub-graph
        sub_didnt_merge = True
        for node in subgraph.nodes():
            for set_num, nodes_set in enumerate(subgraph_nodes_sets):
                if set_num == sub_num:
                    continue
                if node in nodes_set:
                    to_merge = (set_num, sub_num) if sub_num > set_num else (sub_num, set_num)
                    if to_merge not in subgraphs_to_merge:
                        # avoid adding it twice
                        subgraphs_to_merge.append(to_merge)
                    sub_didnt_merge = False
        if sub_didnt_merge:
            isolated_subgraphs.append(subgraph)

    # merge all sub-graphs that shared one or more nodes
    merged_sg = merge_subgraphs(subgraphs, subgraphs_to_merge)

    # we can finally put together all the sub-graphs that can be processed independently
    independent_subgraphs = merged_sg + isolated_subgraphs

    return independent_subgraphs


def replace_node_with_subgraph(graph: nx.DiGraph, old_node: Any, subgraph: nx.DiGraph):
    """Replaces a node by a subgraph, connecting all predecessors of node to all
    nodes in subgraph without predecessors, and all successors of old_node to all
    nodes in subgraph without successors"""
    predecessors = list(graph.predecessors(old_node))
    pred_weight = [graph.get_edge_data(p, old_node)["weight"] for p in predecessors]
    successors = list(graph.successors(old_node))
    succ_weight = [graph.get_edge_data(old_node, s)["weight"] for s in successors]

    initial_nodes_sg = list(
        filter(lambda x: len(list(subgraph.predecessors(x))) == 0, subgraph.nodes())
    )
    terminal_nodes_sg = list(
        filter(lambda x: len(list(subgraph.successors(x))) == 0, subgraph.nodes())
    )

    # add nodes in subgraph to graph
    for node in subgraph.nodes():
        graph.add_node(node)

    # connect old_node's predecessors to nodes in subgraph which don't have predecessors
    for p, w in zip(predecessors, pred_weight):
        for sg_n in initial_nodes_sg:
            graph.add_edge(p, sg_n, weight=w)

    # add all edges of subgraph to graph
    for start, end in subgraph.edges():
        weight = subgraph.get_edge_data(start, end)["weight"]
        graph.add_edge(start, end, weight=weight)

    # connect last node in subgraph to old_node's successors
    for s, w in zip(successors, succ_weight):
        for sg_n in terminal_nodes_sg:
            graph.add_edge(sg_n, s, weight=w)

    if is_output_node(graph, old_node):
        for sg_n in terminal_nodes_sg:
            replace_output(graph, old_node, sg_n)
    # delete old node
    graph.remove_node(old_node)


def theres_predecessor_cond(graph: nx.DiGraph, node: Any, cond: Callable) -> bool:
    """Finds whether `node` has predecessor (or predecessor of predecessor, etc) that satisfied condition"""
    state = False
    for p in graph.predecessors(node):
        if cond(p):
            return True
        state = state or theres_predecessor_cond(graph, p, cond)
    return state


def substitute_node(graph: nx.DiGraph, old_node: Any, new_node: Any, copy_out_info=True):
    """
    Removes old_node from the graph, adding new_node in its place
    :param graph: graph in which to make the substitution
    :param old_node: node to substitute
    :param new_node: node with which to replace
    :param copy_out_info: whether to copy node information (such as whether it's an output node)
    """
    predecessors = [p for p in graph.predecessors(old_node)]
    successors = [s for s in graph.successors(old_node)]
    graph.add_node(new_node)
    for p in predecessors:
        weight = graph.get_edge_data(p, old_node)["weight"]
        graph.add_edge(p, new_node, weight=weight)
    for s in successors:
        weight = graph.get_edge_data(old_node, s)["weight"]
        graph.add_edge(new_node, s, weight=weight)
    if copy_out_info and is_output_node(graph, old_node):
        replace_output(graph, old_node, new_node)
    graph.remove_node(old_node)


def switch_nodes(graph: nx.DiGraph, first_node: Any, second_node: Any):
    """
    Switch positions of nodes first_node and second_node
    :param graph: graph in which to make the change
    :param first_node: left-hand node, which will become right-hand node
    :param second_node: right-hand node, which will become left-hand node
    """
    assert len(list(graph.predecessors(second_node))) == 1
    assert len(list(graph.successors(first_node))) == 1
    assert first_node in list(graph.predecessors(second_node))
    assert second_node in list(graph.successors(first_node))

    pred_first = [p for p in graph.predecessors(first_node)]
    w_pred_first = [graph.get_edge_data(p, first_node)["weight"] for p in pred_first]
    suc_second = [s for s in graph.successors(second_node)]
    w_suc_second = [graph.get_edge_data(second_node, s)["weight"] for s in suc_second]

    graph.remove_edge(first_node, second_node)
    graph.add_edge(second_node, first_node, weight=0)
    for w, p in zip(w_pred_first, pred_first):
        graph.add_edge(p, second_node, weight=w)
        graph.remove_edge(p, first_node)
    for w, s in zip(w_suc_second, suc_second):
        graph.add_edge(first_node, s, weight=w)
        graph.remove_edge(second_node, s)

    if is_output_node(graph, second_node):
        replace_output(graph, second_node, first_node)


def move_node_before_node(graph: nx.DiGraph, first: Any, second: Any):
    """
    Change a graph that contains first -> ... -> second into
    The intermediate "..." must be a single chain
    ... -> first -> second
    :param graph: graph to change
    :param first: left-most node
    :param second: right-most node
    """
    successors = list(graph.successors(first))
    predecessors = list(graph.predecessors(first))
    w_pred = [graph.get_edge_data(p, first)["weight"] for p in predecessors]
    assert len(successors) == 1
    direct_successor = successors[0]
    graph.remove_edge(first, direct_successor)
    for w, p in zip(w_pred, predecessors):
        graph.add_edge(p, direct_successor, weight=w)
        graph.remove_edge(p, first)
    preds_second = [p for p in graph.predecessors(second)]
    assert len(preds_second) == 1
    pred_second = preds_second[0]
    w = graph.get_edge_data(pred_second, second)["weight"]
    graph.remove_edge(pred_second, second)
    graph.add_edge(first, second, weight=0)
    graph.add_edge(pred_second, first, weight=w)


def add_after_node(graph: nx.DiGraph, node: Any, new_node: Any):
    """
    Adds `new_node` after `node`
    :param graph: graph in which to add the node
    :param node: node after which to add
    :param new_node: node to add
    """
    successors = list(graph.successors(node))
    weights = [graph.get_edge_data(node, s)["weight"] for s in successors]
    for s in successors:
        graph.remove_edge(node, s)
    graph.add_node(new_node)
    graph.add_edge(node, new_node, weight=0)
    for s, w in zip(successors, weights):
        graph.add_edge(new_node, s, weight=w)


def add_between_nodes(graph: nx.DiGraph, left: Any, right: Any, node: Any):
    """
    Adds a node between left and right node
    :param graph: target graph
    :param left: left hand side node
    :param right: right hand side node
    :param node: new node to add
    """
    if right not in graph.successors(left):
        raise ValueError("left and right node aren't connected, can't add a node between them")
    weight = graph.get_edge_data(left, right)["weight"]
    graph.add_node(node)
    graph.remove_edge(left, right)
    graph.add_edge(left, node, weight=0)
    graph.add_edge(node, right, weight=weight)
